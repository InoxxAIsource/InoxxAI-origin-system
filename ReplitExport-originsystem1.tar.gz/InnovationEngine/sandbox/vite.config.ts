import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const isDev = mode === 'development';
  const isProd = mode === 'production';
  const isPreview = mode === 'preview';

  return {
    plugins: [
      // React with optimized configuration
      react(),
    ],

    // Path resolution for sandbox
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
        '@assets': path.resolve(__dirname, './src/assets'),
        '@components': path.resolve(__dirname, './src/components'),
      },
      extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json'],
    },

    server: {
      host: true,
      port: 5174,
      strictPort: true,
      open: false,
      proxy: {
        '/api': {
          target: env.VITE_API_URL || 'http://localhost:5000',
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api/, '/api'),
        },
        '/socket.io': {
          target: 'http://localhost:5000',
          changeOrigin: true,
          ws: true,
        },
      },
      cors: {
        origin: isDev ? '*' : ['http://localhost:5000', 'http://localhost:5173'],
        credentials: true,
      },
      hmr: {
        protocol: isDev ? 'ws' : 'ws',
        host: env.VITE_HMR_HOST || 'localhost',
        port: 5174,
      },
      watch: {
        usePolling: true,
        interval: 100,
        ignored: ['**/node_modules/**', '**/.git/**', '**/dist/**'],
      },
      fs: {
        strict: true,
        allow: ['..'],
      },
    },

    preview: {
      port: 8080,
      host: true,
      cors: {
        origin: ['http://localhost:5000', 'http://localhost:5173'],
        credentials: true,
      },
    },

    build: {
      sourcemap: !isProd,
      minify: isProd ? 'esbuild' : false,
      target: 'esnext',
      outDir: 'dist',
      emptyOutDir: true,
      rollupOptions: {
        output: {
          manualChunks: {
            react: ['react', 'react-dom'],
          },
        },
      },
    },

    define: {
      __DEV__: isDev,
      __PROD__: isProd,
    },
  };
});