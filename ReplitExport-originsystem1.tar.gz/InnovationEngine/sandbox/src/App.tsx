const injected = new InjectedConnector({ supportedChainIds: [1, 3, 4, 5, 42] });

const WalletConnection = () => {
  const { activate, deactivate, account, error } = useWeb3React();
  const [connecting, setConnecting] = useState(false);

  const connectWallet = async () => {
    setConnecting(true);
    try {
      await activate(injected);
    } catch (err) {
      console.error(err);
    } finally {
      setConnecting(false);
    }
  };

  const disconnectWallet = () => {
    deactivate();
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md text-center">
      <h1 className="text-2xl font-bold mb-4">Multi-Chain DApp</h1>
      {account ? (
        <div>
          <p className="mb-4">Connected Account: {account}</p>
          <button
            onClick={disconnectWallet}
            className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            Disconnect
          </button>
        </div>
      ) : (
        <button
          onClick={connectWallet}
          disabled={connecting}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          {connecting ? 'Connecting...' : 'Connect Wallet'}
        </button>
      )}
      {error && <p className="text-red-500 mt-4">{error.message}</p>}
    </div>
  );
};

export default WalletConnection;



const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <WalletConnection />
    </div>
  );
};

export default App;