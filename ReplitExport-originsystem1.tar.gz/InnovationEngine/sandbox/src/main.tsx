/**
 * InnoXAI Sandbox - Main Entry Point
 * 
 * This file initializes the React application with essential providers
 * and error boundaries for the isolated preview environment.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SandboxProvider } from './context/SandboxContext';
import './index.css';

// Error logging function for development and debugging
const logError = (error: Error, errorInfo: React.ErrorInfo) => {
  console.error('InnoXAI Sandbox Error:', error);
  console.error('Component Stack:', errorInfo.componentStack);
  
  // In a real environment, you might send this to your logging service
  if (import.meta.env.PROD) {
    // Send to logging service when available
    console.warn('Error logging service not configured');
  }
};

// Performance monitoring
const measurePerformance = () => {
  if (import.meta.env.DEV && 'performance' in window) {
    window.addEventListener('load', () => {
      const perfData = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      console.log('Sandbox Load Time:', perfData.loadEventEnd - perfData.fetchStart, 'ms');
    });
  }
};

// Initialize performance monitoring
measurePerformance();

// Create root with proper error handling
const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Failed to find the root element - DOM may not be ready');
}

// Remove loading overlay when React takes over
const loadingOverlay = rootElement.querySelector('.loading-overlay');
if (loadingOverlay) {
  setTimeout(() => {
    loadingOverlay.remove();
  }, 100);
}

const root = ReactDOM.createRoot(rootElement);

// Render the application with error boundaries and context providers
root.render(
  <React.StrictMode>
    <ErrorBoundary onError={logError}>
      <SandboxProvider>
        <App />
      </SandboxProvider>
    </ErrorBoundary>
  </React.StrictMode>
);

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  event.preventDefault();
});

// Development helpers
if (import.meta.env.DEV) {
  console.log('InnoXAI Sandbox Environment: Development');
  console.log('API Target:', import.meta.env.VITE_API_URL || 'http://localhost:5000');
}