import React, { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error);
    
    // Call the error handler if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Show error in error boundary container
    const errorContainer = document.getElementById('error-boundary');
    if (errorContainer) {
      errorContainer.hidden = false;
      errorContainer.innerHTML = `
        <div class="error-container">
          <h2>Preview Error</h2>
          <p>${error.message}</p>
          <details>
            <summary>Error Details</summary>
            <pre>${error.stack || 'No stack trace available'}</pre>
          </details>
          <button onclick="window.location.reload()">Reload Sandbox</button>
        </div>
      `;
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-fallback">
          <h2>Something went wrong in the sandbox</h2>
          <p>The preview encountered an error and needs to be reloaded.</p>
          <button 
            onClick={() => window.location.reload()}
            style={{
              padding: '8px 16px',
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Reload Sandbox
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}