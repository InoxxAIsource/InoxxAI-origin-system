import React, { createContext, useContext, useReducer, ReactNode } from 'react';

interface SandboxState {
  projectId: string | null;
  content: string | null;
  type: 'react' | 'html' | 'vue' | 'svelte' | null;
  isLoading: boolean;
  error: string | null;
  lastUpdated: number | null;
}

type SandboxAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_PROJECT'; payload: { id: string; content: string; type: 'react' | 'html' | 'vue' | 'svelte' } }
  | { type: 'SET_ERROR'; payload: string }
  | { type: 'CLEAR_ERROR' }
  | { type: 'UPDATE_CONTENT'; payload: string };

const initialState: SandboxState = {
  projectId: null,
  content: null,
  type: null,
  isLoading: false,
  error: null,
  lastUpdated: null,
};

const sandboxReducer = (state: SandboxState, action: SandboxAction): SandboxState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_PROJECT':
      return {
        ...state,
        projectId: action.payload.id,
        content: action.payload.content,
        type: action.payload.type,
        isLoading: false,
        error: null,
        lastUpdated: Date.now(),
      };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    case 'UPDATE_CONTENT':
      return {
        ...state,
        content: action.payload,
        lastUpdated: Date.now(),
      };
    default:
      return state;
  }
};

const SandboxContext = createContext<{
  state: SandboxState;
  dispatch: React.Dispatch<SandboxAction>;
} | null>(null);

export const SandboxProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(sandboxReducer, initialState);

  return (
    <SandboxContext.Provider value={{ state, dispatch }}>
      {children}
    </SandboxContext.Provider>
  );
};

export const useSandbox = () => {
  const context = useContext(SandboxContext);
  if (!context) {
    throw new Error('useSandbox must be used within a SandboxProvider');
  }
  return context;
};