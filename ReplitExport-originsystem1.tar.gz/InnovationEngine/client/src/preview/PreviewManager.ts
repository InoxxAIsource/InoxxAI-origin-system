export class PreviewManager {
  private iframe: HTMLIFrameElement | null = null;
  private partialCodeBuffer = '';
  private updateQueue = Promise.resolve();
  private debounceTimer: NodeJS.Timeout | null = null;
  private isReady = false;
  private messageQueue: Array<{ type: string; code: string; timestamp: number }> = [];

  constructor() {
    this.iframe = null;
    this.partialCodeBuffer = '';
    this.updateQueue = Promise.resolve();
    this.debounceTimer = null;
  }

  initialize(iframeElement: HTMLIFrameElement) {
    this.iframe = iframeElement;
    this.setupMessageChannel();
  }

  setupMessageChannel() {
    window.addEventListener('message', (event) => {
      if (event.data.type === 'PREVIEW_READY') {
        this.isReady = true;
        this.processBuffer();
      }
    });
  }

  async updatePreview(fullCode: string): Promise<void> {
    this.updateQueue = this.updateQueue.then(async () => {
      await this.sendCodeToPreview(fullCode);
    });
    return this.updateQueue;
  }

  updatePartial(codeChunk: string) {
    this.partialCodeBuffer += codeChunk;
    
    // Debounce rapid updates
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    
    this.debounceTimer = setTimeout(() => {
      this.updatePreview(this.partialCodeBuffer);
      this.partialCodeBuffer = '';
    }, 300);
  }

  async sendCodeToPreview(code: string): Promise<void> {
    if (!this.iframe) return;
    
    const message = {
      type: 'CODE_UPDATE',
      code: this.wrapCodeInHtml(code),
      timestamp: Date.now()
    };

    if (this.isReady) {
      this.iframe.contentWindow?.postMessage(message, '*');
    } else {
      this.messageQueue.push(message);
    }
  }

  private async processBuffer(): Promise<void> {
    // Process any queued messages
    while (this.messageQueue.length > 0) {
      const message = this.messageQueue.shift();
      if (message && this.iframe?.contentWindow) {
        this.iframe.contentWindow.postMessage(message, '*');
      }
    }
  }

  wrapCodeInHtml(code: string): string {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Preview</title>
          <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
          <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
          <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
          <script src="https://cdn.tailwindcss.com"></script>
          <style>
            body { 
              margin: 0; 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
              background: #ffffff;
            }
            * {
              box-sizing: border-box;
            }
            .preview-container {
              padding: 1rem;
              min-height: 100vh;
            }
          </style>
          <script>
            window.addEventListener('message', (event) => {
              if (event.data.type === 'CODE_UPDATE') {
                try {
                  const container = document.getElementById('root') || document.body;
                  container.innerHTML = event.data.code;
                  
                  // Execute any script tags in the new content
                  const scripts = container.querySelectorAll('script[type="text/babel"]');
                  scripts.forEach(script => {
                    try {
                      const transformedCode = Babel.transform(script.innerHTML, {
                        presets: ['react']
                      }).code;
                      eval(transformedCode);
                    } catch (error) {
                      console.error('Script execution error:', error);
                    }
                  });
                } catch (error) {
                  console.error('Preview error:', error);
                  document.body.innerHTML = \`
                    <div style="padding: 20px; color: red; font-family: monospace;">
                      <h3>Preview Error</h3>
                      <pre>\${error.message}</pre>
                    </div>
                  \`;
                }
              }
            });
            
            // Signal that the preview is ready
            window.addEventListener('load', () => {
              window.parent.postMessage({ type: 'PREVIEW_READY' }, '*');
            });
          </script>
        </head>
        <body>
          <div id="root" class="preview-container">
            ${this.transformCodeForPreview(code)}
          </div>
        </body>
      </html>
    `;
  }

  private transformCodeForPreview(code: string): string {
    // Remove import statements and transform for browser execution
    let transformedCode = code
      .replace(/import.*from.*['"`];?\n?/g, '')
      .replace(/export\s+default\s+/g, '');

    // If it's a React component, render it
    if (transformedCode.includes('function') || transformedCode.includes('const')) {
      transformedCode += `
        <script type="text/babel">
          ${transformedCode}
          const root = ReactDOM.createRoot(document.getElementById('root'));
          root.render(React.createElement(App || Component));
        </script>
      `;
      return '';
    }

    return transformedCode;
  }

  clearPreview(): void {
    if (this.iframe?.contentWindow) {
      this.iframe.contentWindow.postMessage({ 
        type: 'CODE_UPDATE', 
        code: '<div style="padding: 20px; text-align: center; color: #666;">Preview cleared</div>',
        timestamp: Date.now()
      }, '*');
    }
  }

  destroy(): void {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    this.iframe = null;
    this.messageQueue = [];
    this.isReady = false;
  }
}