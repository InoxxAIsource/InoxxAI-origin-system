import { EventEmitter } from 'events';

interface GenerationOptions {
  framework?: string;
  styling?: string;
  features?: string[];
}

export class GenerationService extends EventEmitter {
  private isGenerating = false;

  async generateFromPrompt(prompt: string, options: GenerationOptions = {}): Promise<void> {
    if (this.isGenerating) {
      throw new Error('Generation already in progress');
    }

    this.isGenerating = true;
    this.emit('generation-start');

    try {
      // Step 1: Generate code with OpenAI
      this.emit('status-update', 'Generating code...');
      const generatedCode = await this.callOpenAI(prompt, options);
      
      this.emit('code-generated', {
        code: generatedCode,
        stage: 'initial'
      });

      // Step 2: Analyze dependencies
      this.emit('status-update', 'Analyzing dependencies...');
      const dependencies = this.extractDependencies(generatedCode);
      
      if (dependencies.length > 0) {
        this.emit('dependencies-detected', dependencies);
        
        // Step 3: Simulate dependency installation
        this.emit('status-update', 'Installing dependencies...');
        await this.installDependencies(dependencies);
        
        this.emit('dependencies-installed', {
          installed: dependencies,
          failed: []
        });
      }

      // Step 4: Final optimization
      this.emit('status-update', 'Optimizing code...');
      const optimizedCode = await this.optimizeCode(generatedCode);
      
      this.emit('code-generated', {
        code: optimizedCode,
        stage: 'optimized'
      });

      this.emit('generation-complete', {
        code: optimizedCode,
        dependencies
      });

    } catch (error) {
      this.emit('generation-error', error);
    } finally {
      this.isGenerating = false;
    }
  }

  private async callOpenAI(prompt: string, options: GenerationOptions): Promise<string> {
    const { framework = 'react', styling = 'tailwind' } = options;
    
    const systemPrompt = `You are an expert frontend developer. Generate clean, modern, production-ready code.

Requirements:
- Framework: ${framework}
- Styling: ${styling}
- Write complete, functional components
- Include proper TypeScript types
- Use modern ES6+ syntax
- Make the code responsive and accessible
- Include error handling where appropriate

Generate ONLY the code, no explanations or markdown formatting.`;

    const response = await fetch('/api/ai/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: systemPrompt + '\n\nUser request: ' + prompt,
        framework,
        styling
      }),
    });

    if (!response.ok) {
      throw new Error(`AI generation failed: ${response.statusText}`);
    }

    const data = await response.json();
    return data.code;
  }

  private extractDependencies(code: string): string[] {
    const dependencies = new Set<string>();
    
    // Extract import statements
    const importRegex = /import\s+.*?\s+from\s+['"`]([^'"`]+)['"`]/g;
    let match;
    
    while ((match = importRegex.exec(code)) !== null) {
      const packageName = match[1];
      
      // Skip relative imports
      if (!packageName.startsWith('.') && !packageName.startsWith('/')) {
        // Extract package name (handle scoped packages)
        const cleanName = packageName.startsWith('@') 
          ? packageName.split('/').slice(0, 2).join('/')
          : packageName.split('/')[0];
        
        // Skip built-in modules
        if (!['react', 'react-dom'].includes(cleanName)) {
          dependencies.add(cleanName);
        }
      }
    }
    
    // Add common dependencies based on code patterns
    if (code.includes('useState') || code.includes('useEffect')) {
      // React hooks are built-in, no need to add
    }
    
    if (code.includes('className=') && code.includes('bg-') || code.includes('text-')) {
      // Tailwind classes detected, but Tailwind is usually a dev dependency
    }
    
    // Detect UI libraries
    if (code.includes('Button') || code.includes('Card') || code.includes('Modal')) {
      dependencies.add('@radix-ui/react-dialog');
      dependencies.add('lucide-react');
    }
    
    if (code.includes('motion.')) {
      dependencies.add('framer-motion');
    }
    
    if (code.includes('Chart') || code.includes('LineChart')) {
      dependencies.add('recharts');
    }
    
    return Array.from(dependencies);
  }

  private async installDependencies(dependencies: string[]): Promise<void> {
    // Simulate installation time
    for (const dep of dependencies) {
      await new Promise(resolve => setTimeout(resolve, 800));
      this.emit('dependency-installed', dep);
    }
  }

  private async optimizeCode(code: string): Promise<string> {
    // Simple optimization - remove extra whitespace and format
    return code
      .replace(/\n\s*\n\s*\n/g, '\n\n') // Remove excessive line breaks
      .replace(/\s+$/gm, '') // Remove trailing whitespace
      .trim();
  }

  public isCurrentlyGenerating(): boolean {
    return this.isGenerating;
  }

  public stopGeneration(): void {
    this.isGenerating = false;
    this.emit('generation-stopped');
  }
}