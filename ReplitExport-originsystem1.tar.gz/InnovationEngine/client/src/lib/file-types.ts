// File type definitions and utilities for the development environment

export interface FileTypeConfig {
  icon: string;
  color: string;
  language: string;
  template?: string;
  extensions: string[];
  category: 'code' | 'style' | 'markup' | 'data' | 'config' | 'documentation';
}

export const fileTypes: Record<string, FileTypeConfig> = {
  javascript: {
    icon: 'fab fa-js-square',
    color: '#F7DF1E',
    language: 'javascript',
    extensions: ['js', 'mjs'],
    category: 'code',
    template: `// JavaScript file
console.log('Hello, World!');

export default function example() {
  return 'Hello from JavaScript!';
}
`,
  },
  jsx: {
    icon: 'fab fa-react',
    color: '#61DAFB',
    language: 'javascript',
    extensions: ['jsx'],
    category: 'code',
    template: `import React from 'react';

export default function Component() {
  return (
    <div>
      <h1>Hello, React!</h1>
    </div>
  );
}
`,
  },
  typescript: {
    icon: 'fas fa-code',
    color: '#3178C6',
    language: 'typescript',
    extensions: ['ts'],
    category: 'code',
    template: `// TypeScript file
interface Example {
  message: string;
}

export default function example(): Example {
  return {
    message: 'Hello from TypeScript!'
  };
}
`,
  },
  tsx: {
    icon: 'fab fa-react',
    color: '#61DAFB',
    language: 'typescript',
    extensions: ['tsx'],
    category: 'code',
    template: `import React from 'react';

interface Props {
  title: string;
}

export default function Component({ title }: Props) {
  return (
    <div>
      <h1>{title}</h1>
    </div>
  );
}
`,
  },
  css: {
    icon: 'fab fa-css3-alt',
    color: '#1572B6',
    language: 'css',
    extensions: ['css'],
    category: 'style',
    template: `/* CSS Stylesheet */
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1rem;
}

.title {
  font-size: 2rem;
  color: #333;
  margin-bottom: 1rem;
}
`,
  },
  scss: {
    icon: 'fab fa-sass',
    color: '#CF649A',
    language: 'scss',
    extensions: ['scss', 'sass'],
    category: 'style',
    template: `// SCSS Stylesheet
$primary-color: #007acc;
$secondary-color: #f0f0f0;

.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1rem;
  
  .title {
    font-size: 2rem;
    color: $primary-color;
    margin-bottom: 1rem;
  }
}
`,
  },
  html: {
    icon: 'fab fa-html5',
    color: '#E34F26',
    language: 'html',
    extensions: ['html', 'htm'],
    category: 'markup',
    template: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <h1>Hello, World!</h1>
</body>
</html>
`,
  },
  json: {
    icon: 'fas fa-cube',
    color: '#85C1E9',
    language: 'json',
    extensions: ['json'],
    category: 'data',
    template: `{
  "name": "example",
  "version": "1.0.0",
  "description": "Example JSON file",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  }
}
`,
  },
  markdown: {
    icon: 'fab fa-markdown',
    color: '#000000',
    language: 'markdown',
    extensions: ['md', 'markdown'],
    category: 'documentation',
    template: `# Title

This is a **markdown** file.

## Subtitle

- List item 1
- List item 2
- List item 3

\`\`\`javascript
console.log('Code block');
\`\`\`
`,
  },
  vue: {
    icon: 'fab fa-vuejs',
    color: '#4FC08D',
    language: 'vue',
    extensions: ['vue'],
    category: 'code',
    template: `<template>
  <div>
    <h1>{{ message }}</h1>
  </div>
</template>

<script>
export default {
  name: 'Component',
  data() {
    return {
      message: 'Hello, Vue!'
    };
  }
};
</script>

<style scoped>
h1 {
  color: #4FC08D;
}
</style>
`,
  },
  python: {
    icon: 'fab fa-python',
    color: '#3776AB',
    language: 'python',
    extensions: ['py'],
    category: 'code',
    template: `#!/usr/bin/env python3
"""
Python script
"""

def main():
    print("Hello, Python!")

if __name__ == "__main__":
    main()
`,
  },
  java: {
    icon: 'fab fa-java',
    color: '#ED8B00',
    language: 'java',
    extensions: ['java'],
    category: 'code',
    template: `public class Example {
    public static void main(String[] args) {
        System.out.println("Hello, Java!");
    }
}
`,
  },
  php: {
    icon: 'fab fa-php',
    color: '#777BB4',
    language: 'php',
    extensions: ['php'],
    category: 'code',
    template: `<?php
echo "Hello, PHP!";
?>
`,
  },
  xml: {
    icon: 'fas fa-code',
    color: '#FF6600',
    language: 'xml',
    extensions: ['xml'],
    category: 'data',
    template: `<?xml version="1.0" encoding="UTF-8"?>
<root>
  <item>Example XML</item>
</root>
`,
  },
  yaml: {
    icon: 'fas fa-file-code',
    color: '#CB171E',
    language: 'yaml',
    extensions: ['yml', 'yaml'],
    category: 'config',
    template: `# YAML configuration
name: example
version: 1.0.0
dependencies:
  - package1
  - package2
`,
  },
  dockerfile: {
    icon: 'fab fa-docker',
    color: '#2496ED',
    language: 'dockerfile',
    extensions: ['dockerfile'],
    category: 'config',
    template: `FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
`,
  },
  gitignore: {
    icon: 'fab fa-git-alt',
    color: '#F05032',
    language: 'plaintext',
    extensions: ['gitignore'],
    category: 'config',
    template: `# Dependencies
node_modules/
*.log

# Build output
dist/
build/

# Environment
.env
.env.local

# IDE
.vscode/
.idea/
`,
  },
};

export function getFileTypeFromPath(filePath: string): FileTypeConfig {
  const extension = filePath.split('.').pop()?.toLowerCase() || '';
  
  // Handle special cases
  if (filePath.toLowerCase() === 'dockerfile') {
    return fileTypes.dockerfile;
  }
  if (filePath.toLowerCase() === '.gitignore') {
    return fileTypes.gitignore;
  }

  // Find by extension
  for (const [key, config] of Object.entries(fileTypes)) {
    if (config.extensions.includes(extension)) {
      return config;
    }
  }

  // Default fallback
  return {
    icon: 'fas fa-file-alt',
    color: '#6B7280',
    language: 'plaintext',
    extensions: [],
    category: 'documentation',
  };
}

export function getFileIcon(filePath: string): string {
  return getFileTypeFromPath(filePath).icon;
}

export function getFileColor(filePath: string): string {
  return getFileTypeFromPath(filePath).color;
}

export function getFileLanguage(filePath: string): string {
  return getFileTypeFromPath(filePath).language;
}

export function getFileTemplate(filePath: string): string {
  return getFileTypeFromPath(filePath).template || '';
}

export function getFileCategory(filePath: string): string {
  return getFileTypeFromPath(filePath).category;
}

export const fileCategories = {
  code: {
    label: 'Code Files',
    description: 'Source code files',
    icon: 'fas fa-code',
    color: '#10B981',
  },
  style: {
    label: 'Style Files',
    description: 'CSS and styling files',
    icon: 'fas fa-palette',
    color: '#3B82F6',
  },
  markup: {
    label: 'Markup Files',
    description: 'HTML and markup files',
    icon: 'fas fa-file-code',
    color: '#F59E0B',
  },
  data: {
    label: 'Data Files',
    description: 'JSON, XML, and data files',
    icon: 'fas fa-database',
    color: '#8B5CF6',
  },
  config: {
    label: 'Configuration',
    description: 'Configuration and settings files',
    icon: 'fas fa-cog',
    color: '#6B7280',
  },
  documentation: {
    label: 'Documentation',
    description: 'README, markdown, and docs',
    icon: 'fas fa-book',
    color: '#EF4444',
  },
};

export function categorizeFiles(files: Array<{ path: string }>): Record<string, Array<{ path: string }>> {
  const categorized: Record<string, Array<{ path: string }>> = {};
  
  files.forEach(file => {
    const category = getFileCategory(file.path);
    if (!categorized[category]) {
      categorized[category] = [];
    }
    categorized[category].push(file);
  });
  
  return categorized;
}

export function getSupportedLanguages(): string[] {
  return Array.from(new Set(Object.values(fileTypes).map(type => type.language)));
}

export function getFilesByCategory(category: string): FileTypeConfig[] {
  return Object.values(fileTypes).filter(type => type.category === category);
}

export function isCodeFile(filePath: string): boolean {
  const category = getFileCategory(filePath);
  return category === 'code';
}

export function isStyleFile(filePath: string): boolean {
  const category = getFileCategory(filePath);
  return category === 'style';
}

export function isConfigFile(filePath: string): boolean {
  const category = getFileCategory(filePath);
  return category === 'config';
}

export function canExecute(filePath: string): boolean {
  const language = getFileLanguage(filePath);
  const executableLanguages = ['javascript', 'typescript', 'python', 'java', 'php'];
  return executableLanguages.includes(language);
}

export function getExecuteCommand(filePath: string): string | null {
  const language = getFileLanguage(filePath);
  const extension = filePath.split('.').pop()?.toLowerCase();
  
  const commandMap: Record<string, string> = {
    'javascript': 'node',
    'typescript': 'ts-node',
    'python': 'python',
    'java': 'java',
    'php': 'php',
  };
  
  const command = commandMap[language];
  if (command) {
    return `${command} ${filePath}`;
  }
  
  return null;
}
