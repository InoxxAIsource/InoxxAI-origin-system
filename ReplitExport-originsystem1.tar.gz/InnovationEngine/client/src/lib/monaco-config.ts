// Monaco Editor configuration for syntax highlighting and IntelliSense
// This would typically be used if we integrate Monaco Editor instead of the basic textarea

export interface MonacoConfig {
  theme: 'vs-dark' | 'vs-light' | 'hc-black';
  fontSize: number;
  wordWrap: 'on' | 'off' | 'wordWrapColumn' | 'bounded';
  minimap: {
    enabled: boolean;
  };
  scrollbar: {
    vertical: 'auto' | 'visible' | 'hidden';
    horizontal: 'auto' | 'visible' | 'hidden';
  };
  lineNumbers: 'on' | 'off' | 'relative' | 'interval';
  folding: boolean;
  renderWhitespace: 'none' | 'boundary' | 'selection' | 'all';
  autoIndent: 'none' | 'keep' | 'brackets' | 'advanced' | 'full';
  formatOnPaste: boolean;
  formatOnType: boolean;
}

export const defaultMonacoConfig: MonacoConfig = {
  theme: 'vs-dark',
  fontSize: 14,
  wordWrap: 'on',
  minimap: {
    enabled: true,
  },
  scrollbar: {
    vertical: 'auto',
    horizontal: 'auto',
  },
  lineNumbers: 'on',
  folding: true,
  renderWhitespace: 'boundary',
  autoIndent: 'advanced',
  formatOnPaste: true,
  formatOnType: true,
};

export const languageConfigs = {
  javascript: {
    language: 'javascript',
    automaticLayout: true,
    scrollBeyondLastLine: false,
    readOnly: false,
    contextmenu: true,
    quickSuggestions: true,
    parameterHints: {
      enabled: true,
    },
    suggestOnTriggerCharacters: true,
    acceptSuggestionOnEnter: 'on' as const,
    tabCompletion: 'on' as const,
    wordBasedSuggestions: true,
  },
  typescript: {
    language: 'typescript',
    automaticLayout: true,
    scrollBeyondLastLine: false,
    readOnly: false,
    contextmenu: true,
    quickSuggestions: true,
    parameterHints: {
      enabled: true,
    },
    suggestOnTriggerCharacters: true,
    acceptSuggestionOnEnter: 'on' as const,
    tabCompletion: 'on' as const,
    wordBasedSuggestions: true,
  },
  css: {
    language: 'css',
    automaticLayout: true,
    scrollBeyondLastLine: false,
    readOnly: false,
    contextmenu: true,
    quickSuggestions: true,
    tabCompletion: 'on' as const,
    wordBasedSuggestions: true,
  },
  html: {
    language: 'html',
    automaticLayout: true,
    scrollBeyondLastLine: false,
    readOnly: false,
    contextmenu: true,
    quickSuggestions: true,
    tabCompletion: 'on' as const,
    wordBasedSuggestions: true,
  },
  json: {
    language: 'json',
    automaticLayout: true,
    scrollBeyondLastLine: false,
    readOnly: false,
    contextmenu: true,
    quickSuggestions: true,
    tabCompletion: 'on' as const,
    wordBasedSuggestions: true,
  },
};

export const syntaxHighlightingThemes = {
  'vs-dark': {
    keyword: '#569CD6',
    string: '#CE9178',
    comment: '#6A9955',
    function: '#DCDCAA',
    variable: '#9CDCFE',
    tag: '#4FC1FF',
    attribute: '#92C5F8',
    number: '#B5CEA8',
    operator: '#D4D4D4',
  },
  'vs-light': {
    keyword: '#0000FF',
    string: '#A31515',
    comment: '#008000',
    function: '#795E26',
    variable: '#001080',
    tag: '#800000',
    attribute: '#FF0000',
    number: '#098658',
    operator: '#000000',
  },
};

export interface EditorAction {
  id: string;
  label: string;
  keybindings?: number[];
  contextMenuGroupId?: string;
  run: (editor: any) => void;
}

export const defaultEditorActions: EditorAction[] = [
  {
    id: 'format-document',
    label: 'Format Document',
    keybindings: [2048 | 66], // Ctrl+Shift+F
    contextMenuGroupId: 'formatting',
    run: (editor) => {
      editor.getAction('editor.action.formatDocument').run();
    },
  },
  {
    id: 'toggle-comment',
    label: 'Toggle Line Comment',
    keybindings: [2048 | 85], // Ctrl+/
    contextMenuGroupId: 'modification',
    run: (editor) => {
      editor.getAction('editor.action.commentLine').run();
    },
  },
  {
    id: 'find-replace',
    label: 'Find and Replace',
    keybindings: [2048 | 72], // Ctrl+H
    contextMenuGroupId: 'navigation',
    run: (editor) => {
      editor.getAction('editor.action.startFindReplaceAction').run();
    },
  },
  {
    id: 'go-to-line',
    label: 'Go to Line',
    keybindings: [2048 | 71], // Ctrl+G
    contextMenuGroupId: 'navigation',
    run: (editor) => {
      editor.getAction('editor.action.gotoLine').run();
    },
  },
];

export const createMonacoConfig = (language: string, customConfig?: Partial<MonacoConfig>) => {
  const baseConfig = { ...defaultMonacoConfig, ...customConfig };
  const languageConfig = languageConfigs[language as keyof typeof languageConfigs] || languageConfigs.javascript;
  
  return {
    ...baseConfig,
    ...languageConfig,
  };
};

export const setupMonacoEditor = (editor: any, language: string) => {
  // Set up IntelliSense for JavaScript/TypeScript
  if (language === 'javascript' || language === 'typescript') {
    // Configure TypeScript compiler options
    const compilerOptions = {
      target: 'ES2020',
      module: 'ESNext',
      moduleResolution: 'node',
      allowJs: true,
      checkJs: false,
      jsx: 'react-jsx',
      declaration: true,
      outDir: './lib',
      strict: true,
      noImplicitAny: true,
      strictNullChecks: true,
      strictFunctionTypes: true,
      noImplicitReturns: true,
      noFallthroughCasesInSwitch: true,
      esModuleInterop: true,
      skipLibCheck: true,
      forceConsistentCasingInFileNames: true,
    };

    // Enable IntelliSense and error checking
    editor.updateOptions({
      semanticHighlighting: true,
      'bracketPairColorization.enabled': true,
    });
  }

  // Set up custom actions
  defaultEditorActions.forEach(action => {
    editor.addAction(action);
  });

  return editor;
};

export const getFileLanguageFromPath = (filePath: string): string => {
  const extension = filePath.split('.').pop()?.toLowerCase();
  
  const extensionToLanguage: Record<string, string> = {
    'js': 'javascript',
    'jsx': 'javascript',
    'ts': 'typescript',
    'tsx': 'typescript',
    'css': 'css',
    'scss': 'scss',
    'sass': 'scss',
    'html': 'html',
    'htm': 'html',
    'json': 'json',
    'md': 'markdown',
    'markdown': 'markdown',
    'xml': 'xml',
    'yml': 'yaml',
    'yaml': 'yaml',
    'py': 'python',
    'java': 'java',
    'cpp': 'cpp',
    'c': 'c',
    'php': 'php',
    'rb': 'ruby',
    'go': 'go',
    'rs': 'rust',
    'sql': 'sql',
    'sh': 'shell',
    'bash': 'shell',
  };

  return extensionToLanguage[extension || ''] || 'plaintext';
};
