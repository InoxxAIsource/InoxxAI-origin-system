export const sampleFileTree = [
  {
    id: '1',
    name: 'app',
    type: 'folder' as const,
    path: '/app',
    children: [
      {
        id: '2',
        name: 'api',
        type: 'folder' as const,
        path: '/app/api',
        children: [
          {
            id: '3',
            name: 'analyze',
            type: 'folder' as const,
            path: '/app/api/analyze',
            children: [
              {
                id: '4',
                name: 'route.ts',
                type: 'file' as const,
                path: '/app/api/analyze/route.ts',
                language: 'typescript',
                size: '2.1KB'
              }
            ]
          },
          {
            id: '5',
            name: 'chat',
            type: 'folder' as const,
            path: '/app/api/chat',
            children: [
              {
                id: '6',
                name: 'route.ts',
                type: 'file' as const,
                path: '/app/api/chat/route.ts',
                language: 'typescript',
                size: '3.4KB'
              }
            ]
          },
          {
            id: '7',
            name: 'deploy',
            type: 'folder' as const,
            path: '/app/api/deploy',
            children: [
              {
                id: '8',
                name: 'route.ts',
                type: 'file' as const,
                path: '/app/api/deploy/route.ts',
                language: 'typescript',
                size: '1.8KB'
              }
            ]
          },
          {
            id: '9',
            name: 'generate',
            type: 'folder' as const,
            path: '/app/api/generate',
            children: [
              {
                id: '10',
                name: 'route.ts',
                type: 'file' as const,
                path: '/app/api/generate/route.ts',
                language: 'typescript',
                size: '4.2KB'
              }
            ]
          }
        ]
      },
      {
        id: '11',
        name: 'ide',
        type: 'folder' as const,
        path: '/app/ide',
        children: [
          {
            id: '12',
            name: 'loading.tsx',
            type: 'file' as const,
            path: '/app/ide/loading.tsx',
            language: 'typescript',
            size: '0.8KB'
          },
          {
            id: '13',
            name: 'page.tsx',
            type: 'file' as const,
            path: '/app/ide/page.tsx',
            language: 'typescript',
            size: '5.2KB'
          }
        ]
      },
      {
        id: '14',
        name: 'globals.css',
        type: 'file' as const,
        path: '/app/globals.css',
        language: 'css',
        size: '1.2KB'
      },
      {
        id: '15',
        name: 'layout.tsx',
        type: 'file' as const,
        path: '/app/layout.tsx',
        language: 'typescript',
        size: '2.3KB'
      },
      {
        id: '16',
        name: 'page.tsx',
        type: 'file' as const,
        path: '/app/page.tsx',
        language: 'typescript',
        size: '3.1KB'
      }
    ]
  },
  {
    id: '17',
    name: 'components',
    type: 'folder' as const,
    path: '/components',
    children: [
      {
        id: '18',
        name: 'ide',
        type: 'folder' as const,
        path: '/components/ide',
        children: [
          {
            id: '19',
            name: 'agent-status.tsx',
            type: 'file' as const,
            path: '/components/ide/agent-status.tsx',
            language: 'typescript',
            size: '2.1KB'
          },
          {
            id: '20',
            name: 'api-status-banner.tsx',
            type: 'file' as const,
            path: '/components/ide/api-status-banner.tsx',
            language: 'typescript',
            size: '1.7KB'
          },
          {
            id: '21',
            name: 'chat-interface.tsx',
            type: 'file' as const,
            path: '/components/ide/chat-interface.tsx',
            language: 'typescript',
            size: '8.4KB'
          },
          {
            id: '22',
            name: 'code-editor.tsx',
            type: 'file' as const,
            path: '/components/ide/code-editor.tsx',
            language: 'typescript',
            size: '6.2KB'
          },
          {
            id: '23',
            name: 'file-tree.tsx',
            type: 'file' as const,
            path: '/components/ide/file-tree.tsx',
            language: 'typescript',
            size: '4.8KB'
          },
          {
            id: '24',
            name: 'preview-panel.tsx',
            type: 'file' as const,
            path: '/components/ide/preview-panel.tsx',
            language: 'typescript',
            size: '5.5KB'
          }
        ]
      },
      {
        id: '25',
        name: 'client-error-handler.tsx',
        type: 'file' as const,
        path: '/components/client-error-handler.tsx',
        language: 'typescript',
        size: '1.3KB'
      },
      {
        id: '26',
        name: 'error-boundary.tsx',
        type: 'file' as const,
        path: '/components/error-boundary.tsx',
        language: 'typescript',
        size: '2.1KB'
      }
    ]
  },
  {
    id: '27',
    name: 'contexts',
    type: 'folder' as const,
    path: '/contexts',
    children: [
      {
        id: '28',
        name: 'ide-context.tsx',
        type: 'file' as const,
        path: '/contexts/ide-context.tsx',
        language: 'typescript',
        size: '3.2KB'
      }
    ]
  },
  {
    id: '29',
    name: 'hooks',
    type: 'folder' as const,
    path: '/hooks',
    children: [
      {
        id: '30',
        name: 'use-ide.ts',
        type: 'file' as const,
        path: '/hooks/use-ide.ts',
        language: 'typescript',
        size: '1.5KB'
      }
    ]
  }
];