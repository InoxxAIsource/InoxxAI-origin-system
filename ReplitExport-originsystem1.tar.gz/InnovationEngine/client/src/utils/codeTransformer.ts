/**
 * Advanced code transformer for handling complex generated code
 * Converts TypeScript and multi-file structures to browser-compatible JavaScript
 */

export interface TransformOptions {
  removeTypeScript?: boolean;
  extractFrontendOnly?: boolean;
  handleMultiFile?: boolean;
  preserveJSX?: boolean;
}

export class CodeTransformer {
  private static extractFrontendCode(code: string): string {
    // Split by common separators and take only frontend part
    const frontendMarkers = [
      '// Frontend:',
      '// React Component:',
      '// Component:',
      '// Frontend Component:'
    ];
    
    const backendMarkers = [
      '// Backend:',
      '// Server:',
      '// API:',
      '// Express Server:',
      '// Node.js:'
    ];

    // Find frontend section
    for (const marker of frontendMarkers) {
      if (code.includes(marker)) {
        let frontendCode = code.split(marker)[1];
        
        // Remove backend sections that might follow
        for (const backendMarker of backendMarkers) {
          if (frontendCode.includes(backendMarker)) {
            frontendCode = frontendCode.split(backendMarker)[0];
          }
        }
        
        return frontendCode.trim();
      }
    }

    // If no explicit frontend marker, extract until backend marker
    for (const marker of backendMarkers) {
      if (code.includes(marker)) {
        return code.split(marker)[0].trim();
      }
    }

    // Remove package.json and other config files
    return code
      .replace(/```[\s\S]*?```/g, '') // Remove markdown code blocks
      .replace(/\{[\s\S]*?"name":\s*"[^"]*"[\s\S]*?\}/g, '') // Remove package.json
      .replace(/\/\/ package\.json[\s\S]*?(?=\/\/|\n\n|$)/g, '') // Remove package.json comments
      .trim();
  }

  private static removeTypeScriptSyntax(code: string): string {
    return code
      // Remove imports
      .replace(/import\s+.*?from\s+['"][^'"]*['"];?\s*/g, '')
      .replace(/import\s+['"][^'"]*['"];?\s*/g, '')
      
      // Remove type annotations
      .replace(/:\s*React\.FC<[^>]*>/g, '')
      .replace(/:\s*React\.FC/g, '')
      .replace(/:\s*FC<[^>]*>/g, '')
      .replace(/:\s*FC/g, '')
      .replace(/as\s+HTMLElement/g, '')
      .replace(/as\s+\w+/g, '')
      .replace(/:\s*(string|number|boolean|any|void|object|HTMLElement|React\.\w+|HTMLInputElement|HTMLFormElement)/g, '')
      .replace(/:\s*\([^)]*\)\s*=>\s*\w+/g, '')
      
      // Remove interfaces and types
      .replace(/interface\s+\w+\s*\{[^}]*\}/g, '')
      .replace(/type\s+\w+\s*=\s*[^;]+;/g, '')
      
      // Remove generic parameters
      .replace(/useState<[^>]*>/g, 'useState')
      .replace(/useEffect<[^>]*>/g, 'useEffect')
      .replace(/useRef<[^>]*>/g, 'useRef')
      .replace(/Array<[^>]*>/g, 'Array')
      
      // Handle function parameters with types
      .replace(/\(([^:)]+):\s*[^)]+\)/g, '($1)')
      
      // Remove export statements and convert to global assignments
      .replace(/export\s+default\s+/g, 'window.Component = ')
      .replace(/export\s+/g, 'window.');
  }

  private static handleSpecialLibraries(code: string): string {
    // Handle Chart.js
    code = code
      .replace(/import.*?Chart.*?from.*?['"`].*?['"`];?\s*/gi, '')
      .replace(/Chart\.register\([^)]*\);?\s*/g, '');

    // Handle wallet connections (remove for now as they need special setup)
    code = code
      .replace(/WalletConnectProvider/g, '(() => { console.warn("WalletConnectProvider not available in preview"); return null; })')
      .replace(/Web3Provider/g, '(() => { console.warn("Web3Provider not available in preview"); return null; })');

    return code;
  }

  private static wrapInvalidCode(code: string): string {
    // Check if code looks like a valid React component
    const hasValidComponent = 
      code.includes('React.createElement') || 
      code.includes('return') || 
      code.includes('window.Component') ||
      code.includes('function') ||
      code.includes('=>');

    if (!hasValidComponent) {
      return `window.Component = () => React.createElement('div', { 
        className: 'p-8 text-center bg-gray-50 rounded-lg' 
      }, 
        React.createElement('h2', { className: 'text-xl font-semibold mb-2' }, 'Generated Content'),
        React.createElement('p', { className: 'text-gray-600' }, 'Preview showing generated output')
      );`;
    }

    return code;
  }

  static transform(rawCode: string, options: TransformOptions = {}): string {
    try {
      const {
        removeTypeScript = true,
        extractFrontendOnly = true,
        handleMultiFile = true,
        preserveJSX = true
      } = options;

      let transformedCode = rawCode;

      // Step 1: Extract frontend code if multi-file
      if (handleMultiFile) {
        transformedCode = this.extractFrontendCode(transformedCode);
      }

      // Step 2: Remove TypeScript syntax
      if (removeTypeScript) {
        transformedCode = this.removeTypeScriptSyntax(transformedCode);
      }

      // Step 3: Handle special libraries
      transformedCode = this.handleSpecialLibraries(transformedCode);

      // Step 4: Clean up any remaining issues
      transformedCode = transformedCode
        .replace(/^\s*\n/gm, '') // Remove empty lines
        .replace(/\s+$/gm, '') // Remove trailing spaces
        .trim();

      // Step 5: Wrap invalid code
      transformedCode = this.wrapInvalidCode(transformedCode);

      return transformedCode;

    } catch (error) {
      console.error('Code transformation failed:', error);
      return `window.Component = () => React.createElement('div', { 
        className: 'p-4 text-red-500 bg-red-50 rounded border border-red-200' 
      }, 
        React.createElement('h3', { className: 'font-semibold mb-2' }, 'Preview Error'),
        React.createElement('p', { className: 'text-sm' }, 'Code transformation failed - check browser console')
      );`;
    }
  }

  static isMultiFileStructure(code: string): boolean {
    const multiFileIndicators = [
      '// Frontend:',
      '// Backend:',
      '// package.json',
      '```typescript',
      '```javascript',
      '```json'
    ];

    return multiFileIndicators.some(indicator => code.includes(indicator));
  }

  static extractBackendInfo(code: string): { routes: any[], hasBackend: boolean } {
    const hasBackend = code.includes('// Backend:') || 
                      code.includes('app.get') || 
                      code.includes('app.post') ||
                      code.includes('express()');

    if (!hasBackend) {
      return { routes: [], hasBackend: false };
    }

    // Extract basic route information for preview
    const routes = [];
    const routeMatches = code.match(/(app\.(get|post|put|delete)\(['"`]([^'"]+)['"`])/g) || [];
    
    routeMatches.forEach(match => {
      const [, , method, path] = match.match(/(get|post|put|delete)\(['"`]([^'"]+)['"`]/) || [];
      if (method && path) {
        routes.push({
          method: method.toUpperCase(),
          path,
          handler: `// Auto-generated handler for ${method.toUpperCase()} ${path}`,
          description: `Generated ${method} endpoint`
        });
      }
    });

    return { routes, hasBackend: true };
  }
}