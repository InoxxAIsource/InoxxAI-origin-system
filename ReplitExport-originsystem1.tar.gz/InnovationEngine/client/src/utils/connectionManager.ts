export class ConnectionManager {
  private static instances = new Map<string, ConnectionManager>();
  private connectionAttempts = 0;
  private isConnecting = false;
  private lastAttempt = 0;
  private backoffDelay = 1000;
  private maxDelay = 30000;
  private maxAttempts = 5;

  private constructor(private instanceId: string) {}

  static getInstance(instanceId: string): ConnectionManager {
    if (!this.instances.has(instanceId)) {
      this.instances.set(instanceId, new ConnectionManager(instanceId));
    }
    return this.instances.get(instanceId)!;
  }

  shouldAttemptConnection(): boolean {
    const now = Date.now();
    
    if (this.isConnecting) {
      return false;
    }

    if (this.connectionAttempts >= this.maxAttempts) {
      return false;
    }

    const timeSinceLastAttempt = now - this.lastAttempt;
    const requiredDelay = Math.min(
      this.backoffDelay * Math.pow(2, this.connectionAttempts),
      this.maxDelay
    );

    return timeSinceLastAttempt >= requiredDelay;
  }

  startConnection(): void {
    this.isConnecting = true;
    this.lastAttempt = Date.now();
    this.connectionAttempts++;
  }

  onConnectionSuccess(): void {
    this.isConnecting = false;
    this.connectionAttempts = 0;
    this.backoffDelay = 1000;
  }

  onConnectionFailure(): void {
    this.isConnecting = false;
  }

  reset(): void {
    this.isConnecting = false;
    this.connectionAttempts = 0;
    this.lastAttempt = 0;
    this.backoffDelay = 1000;
  }

  getStatus() {
    return {
      attempts: this.connectionAttempts,
      isConnecting: this.isConnecting,
      canRetry: this.shouldAttemptConnection(),
      nextRetryIn: this.isConnecting ? 0 : Math.max(0, 
        Math.min(this.backoffDelay * Math.pow(2, this.connectionAttempts), this.maxDelay) - 
        (Date.now() - this.lastAttempt)
      )
    };
  }
}