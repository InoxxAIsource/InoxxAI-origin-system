import { useState, useEffect, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { usePreviewSocket } from "@/hooks/usePreviewSocket";
import { PreviewIframe } from "./PreviewIframe";
import { 
  Monitor, 
  Tablet, 
  Smartphone, 
  RotateCcw, 
  ExternalLink, 
  Maximize2, 
  Minimize2,
  Terminal,
  AlertCircle,
  CheckCircle,
  Loader2,
  Zap
} from "lucide-react";

interface LivePreviewProps {
  projectId: number;
}

type ViewportSize = "desktop" | "tablet" | "mobile" | "fullscreen";

export default function LivePreview({ projectId }: LivePreviewProps) {
  const [viewMode, setViewMode] = useState<ViewportSize>('desktop');
  const [isLive, setIsLive] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [previewError, setPreviewError] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch preview URL
  const { data: previewData, isLoading } = useQuery({
    queryKey: [`/api/preview/${projectId}`],
    enabled: !!projectId,
  });

  // Manual refresh only - avoid excessive polling
  const handleManualRefresh = () => {
    setRefreshKey(prev => prev + 1);
    queryClient.invalidateQueries({ queryKey: [`/api/preview/${projectId}`] });
  };

  const refreshPreview = async () => {
    try {
      const response = await fetch(`/api/preview/${projectId}/refresh`, {
        method: 'POST',
        credentials: 'include',
      });
      
      if (response.ok) {
        setRefreshKey(prev => prev + 1);
        toast({
          title: "Preview refreshed",
          description: "The preview has been updated with your latest changes.",
        });
      }
    } catch (error) {
      toast({
        title: "Refresh failed",
        description: "Failed to refresh the preview.",
        variant: "destructive",
      });
    }
  };

  const openInNewTab = () => {
    if (previewData?.url) {
      window.open(previewData.url, '_blank');
    }
  };

  const getViewModeStyles = () => {
    switch (viewMode) {
      case 'mobile':
        return { width: '375px', height: '667px', margin: '0 auto' };
      case 'tablet':
        return { width: '768px', height: '1024px', margin: '0 auto' };
      default:
        return { width: '100%', height: '100%' };
    }
  };

  const getSandboxUrl = () => {
    // Use the isolated sandbox environment
    return `http://localhost:5174?project=${projectId}&key=${refreshKey}`;
  };

  const getPreviewContent = () => {
    if (previewError || !previewData) {
      return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Starting Preview...</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            margin: 0;
            padding: 20px;
            background: #1a1a1a;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .container {
            text-align: center;
            background: #2a2a2a;
            padding: 40px;
            border-radius: 12px;
            border: 1px solid #3a3a3a;
        }
        .spinner {
            width: 40px;
            height: 40px;
            border: 3px solid #333;
            border-top: 3px solid #3b82f6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        h2 { color: #3b82f6; margin-bottom: 10px; }
        p { color: #ccc; margin: 5px 0; }
        .status { color: #10b981; font-size: 14px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="spinner"></div>
        <h2>Setting up live preview...</h2>
        <p>Creating development environment</p>
        <p>Installing dependencies</p>
        <p>Starting development server</p>
        <div class="status">⚡ This may take a moment for the first time</div>
    </div>
</body>
</html>`;
    }
    return null;
  };

  return (
    <div className="h-full bg-white flex flex-col">
      {/* Preview Toolbar */}
      <div className="bg-gray-100 border-b border-gray-300 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshPreview}
            className="text-gray-600 hover:text-gray-900"
          >
            <i className="fas fa-sync-alt mr-1"></i>
            Refresh
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={openInNewTab}
            className="text-gray-600 hover:text-gray-900"
          >
            <i className="fas fa-external-link-alt mr-1"></i>
            Open
          </Button>
          <div className="text-sm text-gray-600">
            <span>localhost:5000</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'desktop' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('desktop')}
            className="text-sm"
          >
            <i className="fas fa-desktop mr-1"></i>Desktop
          </Button>
          <Button
            variant={viewMode === 'tablet' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('tablet')}
            className="text-sm"
          >
            <i className="fas fa-tablet-alt mr-1"></i>Tablet
          </Button>
          <Button
            variant={viewMode === 'mobile' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('mobile')}
            className="text-sm"
          >
            <i className="fas fa-mobile-alt mr-1"></i>Mobile
          </Button>
        </div>
      </div>

      {/* Enhanced Preview Content with Sandbox Integration */}
      <div className="flex-1 relative overflow-auto bg-gray-100">
        <div className="h-full flex items-center justify-center p-4">
          <div 
            className="bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300"
            style={getViewModeStyles()}
          >
            <PreviewIframe
              projectId={projectId}
              onProjectUpdate={(project) => {
                setIsLive(true);
                toast({
                  title: "Project Updated",
                  description: `${project.type?.toUpperCase()} project refreshed successfully`,
                });
              }}
              className="w-full h-full"
            />
          </div>
        </div>

        {/* Enhanced Live Indicator */}
        <div className="absolute top-4 left-4 flex items-center space-x-2">
          <Badge 
            variant={isLive ? "default" : "secondary"} 
            className={`${isLive ? 'bg-green-500 hover:bg-green-600' : ''} text-white shadow-md`}
          >
            <Zap className={`w-3 h-3 mr-1 ${isLive ? 'animate-pulse' : ''}`} />
            {isLive ? 'Live Preview' : 'Connecting...'}
          </Badge>
        </div>

        {/* Enhanced View Mode Indicator */}
        <div className="absolute top-4 right-4">
          <Badge variant="outline" className="bg-black/75 text-white border-white/20">
            {viewMode === 'desktop' && <Monitor className="w-3 h-3 mr-1" />}
            {viewMode === 'tablet' && <Tablet className="w-3 h-3 mr-1" />}
            {viewMode === 'mobile' && <Smartphone className="w-3 h-3 mr-1" />}
            {viewMode.charAt(0).toUpperCase() + viewMode.slice(1)} View
          </Badge>
        </div>

        {/* Sandbox Status Indicator */}
        <div className="absolute bottom-4 left-4">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 shadow-sm">
            <Terminal className="w-3 h-3 mr-1" />
            InnoXAI Sandbox
          </Badge>
        </div>
      </div>
    </div>
  );
}
