import { useEffect, useRef, useState } from 'react';
import { GenerationService } from '../services/GenerationService';
import { PreviewManager } from '../preview/PreviewManager';
import DependencyTracker from './dependency-tracker';
import FullStackPreview from './FullStackPreview';
import RobustPreview from './RobustPreview';

interface WorkspaceProps {
  prompt?: string;
  onStatusChange?: (status: string) => void;
}

export default function Workspace({ prompt, onStatusChange }: WorkspaceProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [generationService] = useState(() => new GenerationService());
  const [previewManager] = useState(() => new PreviewManager());
  const [dependencies, setDependencies] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('ready');
  const [generatedCode, setGeneratedCode] = useState('');
  const [isFullStack, setIsFullStack] = useState(false);
  const [backendRoutes, setBackendRoutes] = useState<Array<{path: string; method: string; handler: string; description?: string}>>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (iframeRef.current) {
      previewManager.initialize(iframeRef.current);
    }

    // Set up generation service event listeners
    generationService.on('generation-start', () => {
      setStatus('generating');
      setProgress(10);
      setIsGenerating(true);
      onStatusChange?.('generating');
    });

    generationService.on('code-generated', ({ code, stage }: { code: string; stage: string }) => {
      setGeneratedCode(code);
      setProgress(prev => prev + (stage === 'initial' ? 30 : 20));
      
      // Update preview with generated code
      previewManager.updatePreview(code);
    });

    generationService.on('fullstack-generated', ({ frontend, backend }: { frontend: string; backend: any }) => {
      setGeneratedCode(frontend);
      setIsFullStack(true);
      if (backend && backend.routes) {
        setBackendRoutes(backend.routes);
      }
      setProgress(80);
    });

    generationService.on('dependencies-detected', (deps: string[]) => {
      setDependencies(deps);
      setProgress(40);
    });

    generationService.on('dependency-installed', (dep: string) => {
      console.log(`Dependency installed: ${dep}`);
    });

    generationService.on('dependencies-installed', ({ installed, failed }: { installed: string[]; failed: string[] }) => {
      setProgress(80);
      console.log('Dependencies installed:', installed);
      if (failed.length > 0) {
        console.warn('Failed dependencies:', failed);
      }
    });

    generationService.on('generation-complete', ({ code }: { code: string }) => {
      setStatus('complete');
      setProgress(100);
      setGeneratedCode(code);
      setIsGenerating(false);
      onStatusChange?.('complete');
      
      // Final preview update
      previewManager.updatePreview(code);
    });

    generationService.on('generation-error', (error: Error) => {
      setStatus('error');
      setProgress(0);
      setIsGenerating(false);
      onStatusChange?.('error');
      console.error('Generation error:', error);
    });

    generationService.on('code-chunk', (chunk: string) => {
      // Handle streaming updates
      previewManager.updatePartial(chunk);
    });

    return () => {
      generationService.removeAllListeners();
      previewManager.destroy();
    };
  }, [generationService, previewManager, onStatusChange]);

  useEffect(() => {
    if (prompt && prompt.trim()) {
      setProgress(0);
      setDependencies([]);
      setGeneratedCode('');
      previewManager.clearPreview();
      generationService.generateFromPrompt(prompt);
    }
  }, [prompt, generationService, previewManager]);

  const getStatusMessage = () => {
    switch (status) {
      case 'generating':
        if (progress < 40) return 'Generating code...';
        if (progress < 80) return 'Installing dependencies...';
        return 'Finalizing project...';
      case 'complete':
        return 'Project ready!';
      case 'error':
        return 'Generation failed';
      default:
        return 'Ready to build';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'generating':
        return 'var(--warning)';
      case 'complete':
        return 'var(--success)';
      case 'error':
        return 'var(--error)';
      default:
        return 'var(--text-light)';
    }
  };

  return (
    <div className="workspace">
      <div className="workspace-header">
        <div className="workspace-controls">
          <div className="status-indicator">
            <div 
              className="status-dot" 
              style={{ backgroundColor: getStatusColor() }}
            />
            <span className="status-text">{getStatusMessage()}</span>
          </div>
          
          <div className="progress-container">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="progress-text">{progress}%</span>
          </div>
        </div>
      </div>

      <div className="workspace-content">
        <div className="preview-container">
          {isFullStack ? (
            <FullStackPreview
              frontendCode={generatedCode}
              backendRoutes={backendRoutes}
              isLoading={isGenerating}
              projectId={1}
            />
          ) : (
            <RobustPreview
              code={generatedCode}
              isGenerating={isGenerating}
              onDependenciesDetected={setDependencies}
            />
          )}
          
          {isGenerating && (
            <div className="preview-overlay">
              <div className="preview-loading">
                <div className="spinner" />
                <div className="message">Building preview...</div>
              </div>
            </div>
          )}

          {status !== 'ready' && (
            <div className="status-bar">
              <div 
                className="progress-bar" 
                style={{ width: `${progress}%` }}
              />
            </div>
          )}

          {isGenerating && (
            <div className="update-indicator active">
              <div className="pulse-dot" />
              <span>Live updates</span>
            </div>
          )}
        </div>

        <div className="workspace-sidebar">
          <DependencyTracker dependencies={dependencies} />
          
          {generatedCode && (
            <div className="code-summary">
              <h4>Generated Code</h4>
              <div className="code-stats">
                <span>{generatedCode.split('\n').length} lines</span>
                <span>{generatedCode.length} characters</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}