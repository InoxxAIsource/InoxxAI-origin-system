import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertFile } from "@shared/schema";

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: number;
}

interface GenerationHistory {
  id: string;
  prompt: string;
  code: string;
  framework: string;
  styling: string;
  timestamp: Date;
}

export default function AIAssistant({ isOpen, onClose, projectId }: AIAssistantProps) {
  const [prompt, setPrompt] = useState("");
  const [framework, setFramework] = useState("react");
  const [styling, setStyling] = useState("tailwind");
  const [fileName, setFileName] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [generationHistory, setGenerationHistory] = useState<GenerationHistory[]>([]);
  const [activeTab, setActiveTab] = useState("generate");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateCodeMutation = useMutation({
    mutationFn: async (data: { prompt: string; framework: string; styling: string; projectId: number }) => {
      const response = await apiRequest("POST", "/api/ai/generate", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedCode(data.code);
      
      // Add to history
      const historyItem: GenerationHistory = {
        id: Date.now().toString(),
        prompt,
        code: data.code,
        framework: data.framework,
        styling: data.styling,
        timestamp: new Date(),
      };
      setGenerationHistory(prev => [historyItem, ...prev]);
      
      // Suggest filename based on prompt
      if (!fileName) {
        const suggestedName = generateFileName(prompt, data.framework);
        setFileName(suggestedName);
      }
      
      toast({
        title: "Code generated successfully",
        description: "Review the generated code and save it as a file.",
      });
    },
    onError: () => {
      toast({
        title: "Generation failed",
        description: "Failed to generate code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createFileMutation = useMutation({
    mutationFn: async (fileData: InsertFile) => {
      return apiRequest("POST", "/api/files", fileData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/files`] });
      toast({
        title: "File created",
        description: `Created ${fileName} with generated code.`,
      });
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Failed to create file",
        description: "Could not save the generated code as a file.",
        variant: "destructive",
      });
    },
  });

  const analyzeCodeMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await apiRequest("POST", "/api/ai/analyze", { code });
      return response.json();
    },
  });

  const explainCodeMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await apiRequest("POST", "/api/ai/explain", { code });
      return response.json();
    },
  });

  const optimizeCodeMutation = useMutation({
    mutationFn: async (data: { code: string; language: string }) => {
      const response = await apiRequest("POST", "/api/ai/optimize", data);
      return response.json();
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a description of what you want to build.",
        variant: "destructive",
      });
      return;
    }

    generateCodeMutation.mutate({
      prompt: prompt.trim(),
      framework,
      styling,
      projectId,
    });
  };

  const handleSaveFile = () => {
    if (!fileName.trim() || !generatedCode.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a filename and generate code first.",
        variant: "destructive",
      });
      return;
    }

    const language = getLanguageFromFileName(fileName);
    
    createFileMutation.mutate({
      projectId,
      path: fileName.startsWith('src/') ? fileName : `src/${fileName}`,
      content: generatedCode,
      language,
      isOpen: true,
    });
  };

  const resetForm = () => {
    setPrompt("");
    setGeneratedCode("");
    setFileName("");
  };

  const generateFileName = (prompt: string, framework: string): string => {
    const words = prompt.toLowerCase().split(' ').filter(word => word.length > 2);
    const name = words.slice(0, 2).join('-') || 'component';
    
    const extensions: Record<string, string> = {
      react: '.jsx',
      vue: '.vue',
      angular: '.component.ts',
      vanilla: '.js',
    };
    
    return `${name}${extensions[framework] || '.jsx'}`;
  };

  const getLanguageFromFileName = (fileName: string): string => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const languageMap: Record<string, string> = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'vue': 'vue',
      'css': 'css',
      'scss': 'scss',
      'html': 'html',
    };
    return languageMap[ext || ''] || 'javascript';
  };

  const getFrameworkExamples = (framework: string): string[] => {
    const examples: Record<string, string[]> = {
      react: [
        "Create a responsive navigation bar with dropdown menus",
        "Build a data table with sorting and pagination",
        "Create a modal dialog with form validation",
        "Build a dashboard with charts and metrics",
      ],
      vue: [
        "Create a todo list with add/delete functionality",
        "Build a photo gallery with lightbox effect",
        "Create a contact form with validation",
        "Build a product card component",
      ],
      angular: [
        "Create a service for API calls",
        "Build a reactive form with validators",
        "Create a pipe for data transformation",
        "Build a lazy-loaded feature module",
      ],
      vanilla: [
        "Create a smooth scrolling navigation",
        "Build a image carousel with controls",
        "Create a drag and drop interface",
        "Build a progressive web app",
      ],
    };
    
    return examples[framework] || examples.react;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[80vh] bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2 text-xl">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-robot text-white text-sm"></i>
            </div>
            <span>AI Code Assistant</span>
            <Badge variant="secondary" className="bg-blue-600 text-white">
              GPT-4o
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="bg-gray-800 grid w-full grid-cols-4">
            <TabsTrigger value="generate" className="data-[state=active]:bg-gray-700">
              <i className="fas fa-magic mr-2"></i>Generate
            </TabsTrigger>
            <TabsTrigger value="analyze" className="data-[state=active]:bg-gray-700">
              <i className="fas fa-search mr-2"></i>Analyze
            </TabsTrigger>
            <TabsTrigger value="explain" className="data-[state=active]:bg-gray-700">
              <i className="fas fa-book mr-2"></i>Explain
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-gray-700">
              <i className="fas fa-history mr-2"></i>History
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 flex overflow-hidden">
            <TabsContent value="generate" className="flex-1 flex overflow-hidden m-0">
              <div className="flex w-full h-full">
                {/* Left Panel - Input */}
                <div className="w-1/2 p-6 border-r border-gray-700 overflow-y-auto">
                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="prompt" className="text-sm font-medium text-slate-300 mb-2 block">
                        Describe what you want to build
                      </Label>
                      <Textarea
                        id="prompt"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., Create a responsive navigation component with dropdown menus and mobile hamburger menu"
                        className="min-h-[120px] bg-gray-800 border-gray-600 text-white placeholder-gray-400 resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="framework" className="text-sm font-medium text-slate-300 mb-2 block">
                          Framework
                        </Label>
                        <Select value={framework} onValueChange={setFramework}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            <SelectItem value="react">React</SelectItem>
                            <SelectItem value="vue">Vue</SelectItem>
                            <SelectItem value="angular">Angular</SelectItem>
                            <SelectItem value="vanilla">Vanilla JS</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="styling" className="text-sm font-medium text-slate-300 mb-2 block">
                          Styling
                        </Label>
                        <Select value={styling} onValueChange={setStyling}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            <SelectItem value="tailwind">Tailwind CSS</SelectItem>
                            <SelectItem value="css-modules">CSS Modules</SelectItem>
                            <SelectItem value="styled-components">Styled Components</SelectItem>
                            <SelectItem value="scss">SCSS</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="filename" className="text-sm font-medium text-slate-300 mb-2 block">
                        File name (optional)
                      </Label>
                      <Input
                        id="filename"
                        value={fileName}
                        onChange={(e) => setFileName(e.target.value)}
                        placeholder="component.jsx"
                        className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
                      />
                    </div>

                    <Button
                      onClick={handleGenerate}
                      disabled={generateCodeMutation.isPending || !prompt.trim()}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    >
                      {generateCodeMutation.isPending ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Generating...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-magic mr-2"></i>
                          Generate Code
                        </>
                      )}
                    </Button>

                    {/* Example prompts */}
                    <div>
                      <Label className="text-sm font-medium text-slate-300 mb-2 block">
                        Example prompts for {framework}:
                      </Label>
                      <div className="space-y-2">
                        {getFrameworkExamples(framework).map((example, index) => (
                          <button
                            key={index}
                            onClick={() => setPrompt(example)}
                            className="w-full text-left p-2 text-sm text-slate-400 hover:text-white hover:bg-gray-800 rounded border border-gray-700 transition-colors"
                          >
                            {example}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Panel - Generated Code */}
                <div className="w-1/2 p-6 flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-white">Generated Code</h3>
                    {generatedCode && (
                      <Button
                        onClick={handleSaveFile}
                        disabled={createFileMutation.isPending}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {createFileMutation.isPending ? (
                          <>
                            <i className="fas fa-spinner fa-spin mr-2"></i>
                            Saving...
                          </>
                        ) : (
                          <>
                            <i className="fas fa-save mr-2"></i>
                            Save as File
                          </>
                        )}
                      </Button>
                    )}
                  </div>

                  <ScrollArea className="flex-1 bg-gray-800 rounded border border-gray-700">
                    {generatedCode ? (
                      <pre className="p-4 text-sm text-slate-300 font-mono">
                        <code>{generatedCode}</code>
                      </pre>
                    ) : (
                      <div className="p-8 text-center text-slate-500">
                        <i className="fas fa-code text-4xl mb-4"></i>
                        <p>Generated code will appear here</p>
                        <p className="text-sm">Enter a prompt and click "Generate Code" to begin</p>
                      </div>
                    )}
                  </ScrollArea>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="analyze" className="flex-1 m-0 p-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="analyze-code" className="text-sm font-medium text-slate-300 mb-2 block">
                    Paste code to analyze
                  </Label>
                  <Textarea
                    id="analyze-code"
                    placeholder="Paste your code here for analysis..."
                    className="min-h-[200px] bg-gray-800 border-gray-600 text-white placeholder-gray-400"
                  />
                </div>
                <Button
                  onClick={() => {/* Implement analyze */}}
                  disabled={analyzeCodeMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <i className="fas fa-search mr-2"></i>
                  Analyze Code
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="explain" className="flex-1 m-0 p-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="explain-code" className="text-sm font-medium text-slate-300 mb-2 block">
                    Paste code to explain
                  </Label>
                  <Textarea
                    id="explain-code"
                    placeholder="Paste your code here for explanation..."
                    className="min-h-[200px] bg-gray-800 border-gray-600 text-white placeholder-gray-400"
                  />
                </div>
                <Button
                  onClick={() => {/* Implement explain */}}
                  disabled={explainCodeMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <i className="fas fa-book mr-2"></i>
                  Explain Code
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="history" className="flex-1 m-0 p-6">
              <ScrollArea className="h-full">
                {generationHistory.length > 0 ? (
                  <div className="space-y-4">
                    {generationHistory.map((item) => (
                      <Card key={item.id} className="bg-gray-800 border-gray-700">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-white flex items-center justify-between">
                            <span className="truncate">{item.prompt}</span>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline" className="text-xs">
                                {item.framework}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {item.styling}
                              </Badge>
                            </div>
                          </CardTitle>
                          <p className="text-xs text-slate-400">
                            {item.timestamp.toLocaleString()}
                          </p>
                        </CardHeader>
                        <CardContent>
                          <pre className="text-xs text-slate-300 font-mono bg-gray-900 p-3 rounded overflow-x-auto">
                            <code>{item.code.substring(0, 200)}...</code>
                          </pre>
                          <div className="mt-2 flex space-x-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setPrompt(item.prompt);
                                setFramework(item.framework);
                                setStyling(item.styling);
                                setGeneratedCode(item.code);
                                setActiveTab("generate");
                              }}
                              className="text-slate-400 hover:text-white"
                            >
                              <i className="fas fa-redo mr-1"></i>
                              Reuse
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => navigator.clipboard.writeText(item.code)}
                              className="text-slate-400 hover:text-white"
                            >
                              <i className="fas fa-copy mr-1"></i>
                              Copy
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-slate-500 py-8">
                    <i className="fas fa-history text-4xl mb-4"></i>
                    <p>No generation history yet</p>
                    <p className="text-sm">Your AI code generations will appear here</p>
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
