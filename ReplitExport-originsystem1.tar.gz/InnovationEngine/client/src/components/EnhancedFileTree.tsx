import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  Plus,
  MoreHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  path: string;
  children?: FileNode[];
  size?: string;
  modified?: string;
  language?: string;
}

interface EnhancedFileTreeProps {
  files: FileNode[];
  onFileSelect?: (file: FileNode) => void;
  onFileCreate?: (parentPath: string) => void;
  onFolderCreate?: (parentPath: string) => void;
  selectedFile?: string;
}

const getFileIcon = (fileName: string, language?: string) => {
  const ext = fileName.split('.').pop()?.toLowerCase();
  
  // Language-specific colors and styles
  const iconStyles = {
    'tsx': 'text-blue-500',
    'ts': 'text-blue-600',
    'jsx': 'text-cyan-500',
    'js': 'text-yellow-500',
    'css': 'text-pink-500',
    'json': 'text-green-500',
    'md': 'text-gray-600',
    'html': 'text-orange-500',
    'scss': 'text-pink-600',
    'vue': 'text-green-600',
    'py': 'text-green-700',
    'default': 'text-gray-400'
  };

  return iconStyles[ext as keyof typeof iconStyles] || iconStyles.default;
};

const getFolderIcon = (isOpen: boolean, folderName: string) => {
  const baseClass = "w-4 h-4";
  
  // Special folder styling
  if (folderName === 'components') return `${baseClass} text-blue-500`;
  if (folderName === 'api') return `${baseClass} text-green-500`;
  if (folderName === 'app') return `${baseClass} text-purple-500`;
  if (folderName === 'public') return `${baseClass} text-orange-500`;
  if (folderName === 'src') return `${baseClass} text-cyan-500`;
  
  return `${baseClass} text-gray-500`;
};

const FileTreeNode = ({ 
  node, 
  level = 0, 
  onFileSelect, 
  onFileCreate,
  onFolderCreate,
  selectedFile,
  isRoot = false 
}: {
  node: FileNode;
  level?: number;
  onFileSelect?: (file: FileNode) => void;
  onFileCreate?: (parentPath: string) => void;
  onFolderCreate?: (parentPath: string) => void;
  selectedFile?: string;
  isRoot?: boolean;
}) => {
  const [isExpanded, setIsExpanded] = useState(level < 2); // Auto-expand first two levels
  const [isHovered, setIsHovered] = useState(false);
  
  const isSelected = selectedFile === node.path;
  const hasChildren = node.children && node.children.length > 0;
  
  const handleToggle = () => {
    if (node.type === 'folder') {
      setIsExpanded(!isExpanded);
    } else {
      onFileSelect?.(node);
    }
  };

  const handleAddFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFileCreate?.(node.path);
  };

  const handleAddFolder = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFolderCreate?.(node.path);
  };

  return (
    <div className="select-none">
      <div
        className={`
          flex items-center gap-1 py-1 px-2 rounded-md cursor-pointer group relative
          hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors
          ${isSelected ? 'bg-blue-50 dark:bg-blue-900/30 border-l-2 border-l-blue-500' : ''}
          ${level === 0 ? 'font-medium' : ''}
        `}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={handleToggle}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Chevron for folders */}
        {node.type === 'folder' && (
          <div className="w-4 h-4 flex items-center justify-center">
            {hasChildren && (
              <motion.div
                animate={{ rotate: isExpanded ? 90 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <ChevronRight className="w-3 h-3 text-gray-500" />
              </motion.div>
            )}
          </div>
        )}
        
        {/* Icon */}
        <div className="w-4 h-4 flex items-center justify-center ml-1">
          {node.type === 'folder' ? (
            isExpanded ? (
              <FolderOpen className={getFolderIcon(isExpanded, node.name)} />
            ) : (
              <Folder className={getFolderIcon(isExpanded, node.name)} />
            )
          ) : (
            <File className={`w-4 h-4 ${getFileIcon(node.name, node.language)}`} />
          )}
        </div>
        
        {/* File/Folder name */}
        <span 
          className={`
            flex-1 text-sm truncate
            ${isSelected ? 'text-blue-700 dark:text-blue-300 font-medium' : 'text-gray-700 dark:text-gray-300'}
            ${node.type === 'folder' ? 'font-medium' : ''}
          `}
        >
          {node.name}
        </span>
        
        {/* File size/changes indicator */}
        {node.size && (
          <span className="text-xs text-gray-400 ml-2">
            {node.size}
          </span>
        )}
        
        {/* Action buttons */}
        {node.type === 'folder' && isHovered && (
          <div className="flex items-center gap-1 ml-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-5 w-5 p-0 opacity-70 hover:opacity-100"
              onClick={handleAddFile}
              title="Add file"
            >
              <Plus className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-5 w-5 p-0 opacity-70 hover:opacity-100"
              onClick={handleAddFolder}
              title="Add folder"
            >
              <Folder className="w-3 h-3" />
            </Button>
          </div>
        )}
      </div>
      
      {/* Children */}
      <AnimatePresence>
        {node.type === 'folder' && isExpanded && hasChildren && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            {node.children!.map((child) => (
              <FileTreeNode
                key={child.id}
                node={child}
                level={level + 1}
                onFileSelect={onFileSelect}
                onFileCreate={onFileCreate}
                onFolderCreate={onFolderCreate}
                selectedFile={selectedFile}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function EnhancedFileTree({ 
  files, 
  onFileSelect, 
  onFileCreate,
  onFolderCreate,
  selectedFile 
}: EnhancedFileTreeProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filterFiles = (nodes: FileNode[], term: string): FileNode[] => {
    if (!term) return nodes;
    
    return nodes.filter(node => {
      if (node.name.toLowerCase().includes(term.toLowerCase())) {
        return true;
      }
      if (node.children) {
        const filteredChildren = filterFiles(node.children, term);
        return filteredChildren.length > 0;
      }
      return false;
    }).map(node => ({
      ...node,
      children: node.children ? filterFiles(node.children, term) : undefined
    }));
  };

  const filteredFiles = filterFiles(files, searchTerm);

  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
            Project Files
          </h3>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0"
            title="More options"
          >
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search files..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-1.5 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>
      
      {/* File Tree */}
      <div className="flex-1 overflow-auto p-2">
        <div className="space-y-0.5">
          {filteredFiles.map((file) => (
            <FileTreeNode
              key={file.id}
              node={file}
              onFileSelect={onFileSelect}
              onFileCreate={onFileCreate}
              onFolderCreate={onFolderCreate}
              selectedFile={selectedFile}
              isRoot={true}
            />
          ))}
        </div>
        
        {filteredFiles.length === 0 && searchTerm && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <File className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No files found</p>
          </div>
        )}
      </div>
      
      {/* Footer Stats */}
      <div className="p-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
          <span>{files.length} items</span>
          <span>Ready</span>
        </div>
      </div>
    </div>
  );
}