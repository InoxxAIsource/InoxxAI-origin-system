import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface BackendRoute {
  path: string;
  method: string;
  handler: string;
  description?: string;
}

interface FullStackPreviewProps {
  frontendCode?: string;
  backendRoutes?: BackendRoute[];
  isLoading?: boolean;
  projectId?: number;
}

interface BackendStatus {
  isReady: boolean;
  error: string | null;
  activeRoutes: string[];
  baseUrl: string;
}

export function FullStackPreview({ 
  frontendCode, 
  backendRoutes = [], 
  isLoading = false,
  projectId 
}: FullStackPreviewProps) {
  const [backendStatus, setBackendStatus] = useState<BackendStatus>({
    isReady: false,
    error: null,
    activeRoutes: [],
    baseUrl: 'http://localhost:3001'
  });
  const [activeTab, setActiveTab] = useState<'frontend' | 'api' | 'logs'>('frontend');
  const [apiResponses, setApiResponses] = useState<Record<string, any>>({});
  const [isTestingApi, setIsTestingApi] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (backendRoutes && backendRoutes.length > 0) {
      initializeBackend();
    }
  }, [backendRoutes]);

  const initializeBackend = async () => {
    try {
      setBackendStatus(prev => ({ ...prev, error: null }));
      
      // Simulate backend initialization
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setBackendStatus({
        isReady: true,
        error: null,
        activeRoutes: backendRoutes.map(route => `${route.method} ${route.path}`),
        baseUrl: 'http://localhost:3001'
      });
    } catch (error) {
      setBackendStatus(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Backend initialization failed'
      }));
    }
  };

  const testApiEndpoint = async (route: BackendRoute) => {
    setIsTestingApi(true);
    try {
      // Simulate API call for demo purposes
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const mockResponse = generateMockResponse(route);
      setApiResponses(prev => ({
        ...prev,
        [`${route.method} ${route.path}`]: {
          status: 200,
          data: mockResponse,
          timestamp: new Date().toISOString()
        }
      }));
    } catch (error) {
      setApiResponses(prev => ({
        ...prev,
        [`${route.method} ${route.path}`]: {
          status: 500,
          error: error instanceof Error ? error.message : 'API call failed',
          timestamp: new Date().toISOString()
        }
      }));
    } finally {
      setIsTestingApi(false);
    }
  };

  const generateMockResponse = (route: BackendRoute) => {
    const path = route.path.toLowerCase();
    
    if (path.includes('stats') || path.includes('dashboard')) {
      return {
        users: Math.floor(Math.random() * 10000) + 1000,
        revenue: Math.floor(Math.random() * 100000) + 50000,
        orders: Math.floor(Math.random() * 500) + 100,
        growth: (Math.random() * 20 + 5).toFixed(1) + '%'
      };
    }
    
    if (path.includes('chart') || path.includes('data')) {
      return {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Revenue',
          data: Array.from({length: 6}, () => Math.floor(Math.random() * 10000) + 5000)
        }]
      };
    }
    
    if (path.includes('product')) {
      return Array.from({length: 5}, (_, i) => ({
        id: i + 1,
        name: `Product ${i + 1}`,
        price: Math.floor(Math.random() * 200) + 20,
        category: ['Electronics', 'Clothing', 'Books'][Math.floor(Math.random() * 3)]
      }));
    }
    
    return {
      message: 'API endpoint working correctly',
      timestamp: new Date().toISOString(),
      status: 'success'
    };
  };

  const generateFrontendHtml = (code: string) => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>InnoXAI Preview</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <script src="https://unpkg.com/chart.js@4.4.0/dist/chart.umd.js"></script>
  <style>
    body { 
      margin: 0; 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
      line-height: 1.6;
    }
    .backend-status {
      position: fixed;
      top: 10px;
      right: 10px;
      z-index: 1000;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
    }
    .backend-ready {
      background: #10b981;
      color: white;
    }
    .backend-loading {
      background: #f59e0b;
      color: white;
    }
    .backend-error {
      background: #ef4444;
      color: white;
    }
  </style>
</head>
<body>
  <div id="root"></div>
  
  ${backendStatus.isReady ? `
    <div class="backend-status backend-ready">
      ✓ Backend Ready (${backendStatus.activeRoutes.length} routes)
    </div>
  ` : backendStatus.error ? `
    <div class="backend-status backend-error">
      ✗ Backend Error
    </div>
  ` : `
    <div class="backend-status backend-loading">
      ⟳ Starting Backend...
    </div>
  `}
  
  <script type="text/babel">
    const { useState, useEffect } = React;
    
    // Mock API service for frontend to use
    window.api = {
      get: async (endpoint) => {
        // Simulate API calls
        await new Promise(resolve => setTimeout(resolve, 200));
        return fetch(endpoint).then(r => r.json()).catch(() => ({ message: 'API endpoint test' }));
      },
      post: async (endpoint, data) => {
        await new Promise(resolve => setTimeout(resolve, 200));
        return { success: true, data };
      }
    };
    
    ${code
      .replace(/import.*?;/g, '')
      .replace(/export default /g, 'window.Component = ')
      .replace(/export /g, 'window.')
    }
    
    const root = ReactDOM.createRoot(document.getElementById('root'));
    const ComponentToRender = window.Component || window.App || (() => 
      React.createElement('div', { 
        className: 'flex items-center justify-center h-screen' 
      }, React.createElement('div', { 
        className: 'text-center' 
      }, 
        React.createElement('h1', { className: 'text-2xl font-bold text-gray-800' }, 'Component Preview'),
        React.createElement('p', { className: 'text-gray-600 mt-2' }, 'Your generated component will appear here')
      ))
    );
    
    root.render(React.createElement(ComponentToRender));
    
    // Notify parent when ready
    window.addEventListener('load', () => {
      window.parent.postMessage({ type: 'PREVIEW_READY' }, '*');
    });
  </script>
</body>
</html>`;
  };

  return (
    <div className="fullstack-preview h-full flex flex-col bg-background">
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="frontend" className="flex items-center gap-2">
            <span>Frontend</span>
            {frontendCode && <Badge variant="secondary" className="text-xs">Ready</Badge>}
          </TabsTrigger>
          <TabsTrigger value="api" className="flex items-center gap-2">
            <span>API</span>
            <Badge 
              variant={backendStatus.isReady ? "default" : backendStatus.error ? "destructive" : "secondary"}
              className="text-xs"
            >
              {backendStatus.isReady ? `${backendRoutes.length} routes` : 
               backendStatus.error ? "Error" : "Loading"}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <span>Console</span>
            {Object.keys(apiResponses).length > 0 && (
              <Badge variant="outline" className="text-xs">
                {Object.keys(apiResponses).length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="frontend" className="flex-1 mt-0 border-0 p-0">
          <div className="preview-container h-full">
            <AnimatePresence>
              {isLoading && (
                <motion.div
                  className="absolute inset-0 bg-background/80 backdrop-blur-sm z-10 flex items-center justify-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                    <p className="text-sm text-muted-foreground">Loading preview...</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            <iframe
              ref={iframeRef}
              srcDoc={frontendCode ? generateFrontendHtml(frontendCode) : undefined}
              sandbox="allow-scripts allow-same-origin"
              className="w-full h-full border-0 bg-white"
              title="Frontend Preview"
            />
          </div>
        </TabsContent>

        <TabsContent value="api" className="flex-1 mt-0 border-0 p-4 overflow-auto">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">API Endpoints</h3>
              <Badge variant={backendStatus.isReady ? "default" : "secondary"}>
                {backendStatus.isReady ? "Server Running" : "Initializing"}
              </Badge>
            </div>

            {backendStatus.error && (
              <Card className="border-destructive">
                <CardContent className="pt-4">
                  <p className="text-sm text-destructive">{backendStatus.error}</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={initializeBackend}
                  >
                    Retry
                  </Button>
                </CardContent>
              </Card>
            )}

            <div className="grid gap-4">
              {backendRoutes.map((route, index) => (
                <Card key={index}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Badge variant={route.method === 'GET' ? 'default' : 'secondary'}>
                          {route.method}
                        </Badge>
                        <code className="text-xs">{route.path}</code>
                      </CardTitle>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => testApiEndpoint(route)}
                        disabled={!backendStatus.isReady || isTestingApi}
                      >
                        {isTestingApi ? 'Testing...' : 'Test'}
                      </Button>
                    </div>
                    {route.description && (
                      <p className="text-xs text-muted-foreground">{route.description}</p>
                    )}
                  </CardHeader>
                  
                  {apiResponses[`${route.method} ${route.path}`] && (
                    <CardContent className="pt-0">
                      <div className="bg-muted rounded p-2">
                        <pre className="text-xs overflow-auto">
                          {JSON.stringify(apiResponses[`${route.method} ${route.path}`], null, 2)}
                        </pre>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>

            {backendRoutes.length === 0 && (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    No API endpoints available. Generate a full-stack project to see backend routes.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="logs" className="flex-1 mt-0 border-0 p-4">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Console & API Logs</h3>
            
            <div className="bg-black text-green-400 font-mono text-xs p-4 rounded-lg h-64 overflow-auto">
              {Object.entries(apiResponses).map(([endpoint, response], index) => (
                <div key={index} className="mb-2">
                  <span className="text-blue-400">[{new Date(response.timestamp).toLocaleTimeString()}]</span>
                  <span className="text-yellow-400"> {endpoint}</span>
                  <span className={response.status === 200 ? "text-green-400" : "text-red-400"}>
                    {" "}→ {response.status}
                  </span>
                  {response.error && (
                    <div className="text-red-400 ml-4">Error: {response.error}</div>
                  )}
                </div>
              ))}
              
              {Object.keys(apiResponses).length === 0 && (
                <div className="text-gray-500">
                  Console output will appear here when you test API endpoints...
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default FullStackPreview;