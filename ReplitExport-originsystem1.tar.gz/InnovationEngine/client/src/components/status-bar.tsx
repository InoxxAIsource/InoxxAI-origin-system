import { Button } from "@/components/ui/button";
import type { Project, File } from "@shared/schema";

interface StatusBarProps {
  project?: Project;
  activeFile?: File;
  showBottomPanel: boolean;
  onToggleBottomPanel: () => void;
}

export default function StatusBar({ 
  project, 
  activeFile, 
  showBottomPanel, 
  onToggleBottomPanel 
}: StatusBarProps) {
  const getFileLanguageDisplay = (language: string) => {
    const languageDisplayMap: Record<string, string> = {
      'javascript': 'JavaScript',
      'typescript': 'TypeScript',
      'css': 'CSS',
      'scss': 'SCSS',
      'html': 'HTML',
      'json': 'JSON',
      'markdown': 'Markdown',
      'python': 'Python',
      'java': 'Java',
      'cpp': 'C++',
      'c': 'C',
      'php': 'PHP',
      'ruby': 'Ruby',
      'go': 'Go',
      'rust': 'Rust',
    };
    
    return languageDisplayMap[language] || language.toUpperCase();
  };

  const getBranchStatus = () => {
    // Mock git status - in real implementation, this would come from git integration
    return {
      branch: 'main',
      changes: 2,
      status: 'clean', // 'clean', 'modified', 'staged'
    };
  };

  const gitStatus = getBranchStatus();

  return (
    <footer className="h-6 bg-primary text-primary-foreground px-4 flex items-center justify-between text-xs shrink-0">
      <div className="flex items-center space-x-4">
        {/* Connection Status */}
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Connected</span>
        </div>

        {/* Git Status */}
        <div className="flex items-center space-x-2">
          <i className="fab fa-git-alt"></i>
          <span>{gitStatus.branch}</span>
          {gitStatus.changes > 0 && (
            <>
              <i className="fas fa-circle text-xs text-yellow-300"></i>
              <span>{gitStatus.changes} changes</span>
            </>
          )}
          {gitStatus.status === 'clean' && (
            <i className="fas fa-check text-green-300"></i>
          )}
        </div>

        {/* Project Info */}
        {project && (
          <div className="flex items-center space-x-1">
            <i className="fas fa-project-diagram"></i>
            <span>{project.name}</span>
          </div>
        )}

        {/* Error/Warning Counts */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            <i className="fas fa-times-circle text-red-300"></i>
            <span>0 errors</span>
          </div>
          <div className="flex items-center space-x-1">
            <i className="fas fa-exclamation-triangle text-yellow-300"></i>
            <span>2 warnings</span>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* File Info */}
        {activeFile && (
          <>
            <div>
              <span>{getFileLanguageDisplay(activeFile.language)}</span>
            </div>
            <div>
              <span>Line 1, Column 1</span>
            </div>
          </>
        )}

        {/* Encoding */}
        <div>
          <span>UTF-8</span>
        </div>

        {/* Formatter */}
        <div>
          <span>Prettier</span>
        </div>

        {/* Live Status */}
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Live</span>
        </div>

        {/* Collaborators */}
        <div className="flex items-center space-x-1">
          <i className="fas fa-users text-blue-300"></i>
          <span>3 collaborators</span>
        </div>

        {/* Bottom Panel Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleBottomPanel}
          className="h-5 px-2 text-primary-foreground hover:bg-primary-foreground/20"
        >
          <i className={`fas fa-chevron-${showBottomPanel ? 'down' : 'up'} text-xs`}></i>
        </Button>
      </div>
    </footer>
  );
}
