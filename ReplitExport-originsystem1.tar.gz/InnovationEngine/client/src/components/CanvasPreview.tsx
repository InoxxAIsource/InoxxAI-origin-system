import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CodeTransformer } from '../utils/codeTransformer';

interface CanvasPreviewProps {
  code?: string;
  isGenerating?: boolean;
  onDependenciesDetected?: (deps: string[]) => void;
}

export default function CanvasPreview({ code, isGenerating = false, onDependenciesDetected }: CanvasPreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showPlaceholder, setShowPlaceholder] = useState(true);

  useEffect(() => {
    if (!code) return;

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'PREVIEW_READY') {
        setIsLoading(false);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    if (!isGenerating && !isLoading) {
      const timer = setTimeout(() => setShowPlaceholder(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isGenerating, isLoading]);

  useEffect(() => {
    if (!iframeRef.current || !code) return;
    setIsLoading(true);
    setShowPlaceholder(true);

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <script src="https://cdn.tailwindcss.com"></script>
          <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
          <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
          <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
          <script src="https://unpkg.com/chart.js@4.4.0/dist/chart.umd.js"></script>
          <style>
            body { 
              margin: 0; 
              font-family: Inter, sans-serif; 
              line-height: 1.6;
            }
            .loading { 
              display: flex; 
              justify-content: center; 
              align-items: center; 
              height: 100vh; 
              color: #4f46e5;
              font-size: 18px;
            }
          </style>
        </head>
        <body>
          ${code ? `
            <div id="root"></div>
            <script type="text/babel">
              const { useState, useEffect } = React;
              
              ${code
                // Remove imports and replace Chart.js specific ones
                .replace(/import.*?from\s+['"]react-chartjs-2['"];?/g, '')
                .replace(/import.*?from\s+['"]chart\.js['"];?/g, '')
                .replace(/import.*?;/g, '')
                // Add Chart.js globals setup
                .replace(/ChartJS\.register\([^)]*\);?/g, `
                  // Chart.js is available globally
                  const { Chart: ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, BarElement, ArcElement } = Chart;
                  ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend);
                  
                  // Simple chart components using Canvas API
                  const Line = ({ data, options }) => {
                    const canvasRef = React.useRef(null);
                    React.useEffect(() => {
                      if (canvasRef.current) {
                        const ctx = canvasRef.current.getContext('2d');
                        new ChartJS(ctx, { type: 'line', data, options });
                      }
                    }, [data, options]);
                    return React.createElement('canvas', { ref: canvasRef, width: 400, height: 200 });
                  };
                  
                  const Bar = ({ data, options }) => {
                    const canvasRef = React.useRef(null);
                    React.useEffect(() => {
                      if (canvasRef.current) {
                        const ctx = canvasRef.current.getContext('2d');
                        new ChartJS(ctx, { type: 'bar', data, options });
                      }
                    }, [data, options]);
                    return React.createElement('canvas', { ref: canvasRef, width: 400, height: 200 });
                  };
                `)
                // Remove TypeScript definitions
                .replace(/type\s+\w+\s*=\s*\{[^}]*\};?\s*/g, '')
                .replace(/interface\s+\w+\s*\{[^}]*\};?\s*/g, '')
                // Remove React.FC annotations
                .replace(/:\s*React\.FC<[^>]*>/g, '')
                .replace(/:\s*React\.FC/g, '')
                // Remove parameter and variable type annotations
                .replace(/:\s*\([^)]*\)\s*=>\s*\w+/g, '')
                .replace(/:\s*(string|number|boolean|any|void|React\.FormEvent)\b/g, '')
                // Remove generic parameters but preserve JSX
                .replace(/useState<[^>]*>/g, 'useState')
                // Convert export to window assignment
                .replace(/export default /g, 'window.Component = ')
                .replace(/export /g, 'window.')
              }
              
              const root = ReactDOM.createRoot(document.getElementById('root'));
              const ComponentToRender = window.Component || window.App || (() => React.createElement('div', { className: 'loading' }, 'Component rendered successfully!'));
              root.render(React.createElement(ComponentToRender));
              
              // Notify parent when ready
              window.addEventListener('load', () => {
                window.parent.postMessage({ type: 'PREVIEW_READY' }, '*');
              });
            </script>
          ` : '<div class="loading">Preview will appear here</div>'}
        </body>
      </html>
    `;

    iframeRef.current.srcdoc = html;
  }, [code]);

  return (
    <div className="preview-container">
      <AnimatePresence>
        {(isGenerating || showPlaceholder) && (
          <motion.div
            className="preview-placeholder"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="shimmer-loading">
              {/* Header placeholder */}
              <div className="shimmer-row" style={{ width: '60%', height: '2rem', marginBottom: '1.5rem' }} />
              
              {/* Content grid placeholder */}
              <div className="shimmer-grid">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="shimmer-card">
                    <div className="shimmer-row" style={{ width: '80%', height: '1.25rem' }} />
                    <div className="shimmer-row" style={{ width: '60%', height: '1rem', marginTop: '0.5rem' }} />
                    <div className="shimmer-row" style={{ width: '40%', height: '1rem', marginTop: '1rem' }} />
                  </div>
                ))}
              </div>
              
              {/* Loading indicator */}
              <div className="loading-dots">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="dot"
                    animate={{
                      y: [0, -10, 0],
                      opacity: [0.6, 1, 0.6]
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 1,
                      delay: i * 0.2
                    }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <iframe
        ref={iframeRef}
        sandbox="allow-scripts allow-same-origin"
        className={`preview-iframe ${showPlaceholder ? 'hidden' : ''}`}
        style={{ opacity: showPlaceholder ? 0 : 1 }}
        title="Component Preview"
      />
    </div>
  );
}