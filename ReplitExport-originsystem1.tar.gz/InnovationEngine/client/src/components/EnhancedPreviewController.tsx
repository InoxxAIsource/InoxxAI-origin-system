import { usePreviewSocket } from "@/hooks/usePreviewSocket";
import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { BuildStatus, PreviewError } from "@/hooks/usePreviewSocket";
import { 
  RefreshCw, 
  Monitor, 
  Smartphone, 
  Tablet, 
  ExternalLink, 
  Maximize2, 
  Minimize2, 
  AlertTriangle, 
  CheckCircle, 
  Zap, 
  Wifi, 
  WifiOff,
  Settings,
  Eye,
  Code,
  Activity,
  Timer,
  RotateCcw,
  Square
} from "lucide-react";

type PreviewStatus = "idle" | "building" | "success" | "error" | "offline" | "connecting";
type ViewportSize = "desktop" | "tablet" | "mobile" | "fullscreen";

interface PreviewMetrics {
  buildTime: number | null;
  lastUpdate: Date | null;
  buildCount: number;
  errorCount: number;
  connectionTime: number | null;
}

interface DevConsoleMessage {
  id: string;
  type: "log" | "warn" | "error" | "info";
  message: string;
  timestamp: Date;
  source?: string;
}

const VIEWPORT_SIZES = {
  desktop: { width: "100%", height: "100%", icon: Monitor, label: "Desktop" },
  tablet: { width: "768px", height: "1024px", icon: Tablet, label: "Tablet (768x1024)" },
  mobile: { width: "375px", height: "667px", icon: Smartphone, label: "Mobile (375x667)" },
  fullscreen: { width: "100vw", height: "100vh", icon: Maximize2, label: "Fullscreen" }
} as const;

export function EnhancedPreviewController() {
  const [key, setKey] = useState(0);
  const [status, setStatus] = useState<PreviewStatus>("idle");
  const [error, setError] = useState<PreviewError | null>(null);
  const [viewport, setViewport] = useState<ViewportSize>("desktop");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showDevConsole, setShowDevConsole] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [consoleMessages, setConsoleMessages] = useState<DevConsoleMessage[]>([]);
  const [metrics, setMetrics] = useState<PreviewMetrics>({
    buildTime: null,
    lastUpdate: null,
    buildCount: 0,
    errorCount: 0,
    connectionTime: null
  });
  
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const buildStartTime = useRef<number | null>(null);
  const connectionStartTime = useRef<number | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Enhanced socket connection with proper cleanup
  const socket = usePreviewSocket(
    (filePaths) => {
      if (filePaths && filePaths.length > 0) {
        addConsoleMessage("info", `Files updated: ${filePaths.join(", ")}`);
        setKey((prev) => prev + 1);
        setMetrics(prev => ({
          ...prev,
          lastUpdate: new Date()
        }));
      }
    },
    {
      autoConnect: true,
      enableMetrics: true,
      enableDebugMode: false, // Disable debug to reduce log spam
      reconnectAttempts: 3,
      reconnectDelay: 2000,
      maxReconnectDelay: 10000,
      userId: `preview-${Date.now()}`,
      
      onConnect: () => {
        const connectionDuration = connectionStartTime.current 
          ? Date.now() - connectionStartTime.current 
          : null;
        
        setStatus("success");
        setMetrics(prev => ({ ...prev, connectionTime: connectionDuration }));
        addConsoleMessage("info", "Preview socket connected");
        
        // Clear any pending reconnect timeouts
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      },

      onDisconnect: (reason) => {
        setStatus("offline");
        addConsoleMessage("warn", `Socket disconnected: ${reason}`);
        
        // Only attempt reconnection for unexpected disconnects
        if (reason !== "io client disconnect" && reason !== "transport close") {
          scheduleReconnection();
        }
      },

      onConnectionStateChange: (state) => {
        if (state === "connecting") {
          connectionStartTime.current = Date.now();
          setStatus("connecting");
        } else if (state === "error") {
          setStatus("error");
        }
      },

      onBuildStart: (buildId) => {
        setStatus("building");
        setBuildProgress(0);
        buildStartTime.current = Date.now();
        setError(null);
        
        addConsoleMessage("info", `Build started: ${buildId || "unknown"}`);
      },

      onBuildComplete: (payload: BuildStatus) => {
        const buildDuration = buildStartTime.current 
          ? Date.now() - buildStartTime.current 
          : null;
        
        setBuildProgress(payload.progress || 100);
        if (payload.status === "completed") {
          setTimeout(() => setBuildProgress(0), 500);
        }
        
        setMetrics(prev => ({
          ...prev,
          buildTime: buildDuration,
          buildCount: prev.buildCount + 1,
          errorCount: payload.success ? prev.errorCount : prev.errorCount + 1
        }));
        
        setStatus(payload.success ? "success" : "error");
        
        const message = payload.success
          ? `Build completed successfully in ${buildDuration}ms`
          : `Build failed: ${payload.errors?.join(", ") || "Unknown error"}`;
        
        addConsoleMessage(payload.success ? "info" : "error", message);
        
        toast({
          title: payload.success ? "Build Successful" : "Build Failed",
          description: message,
          variant: payload.success ? "default" : "destructive",
          duration: payload.success ? 3000 : 5000,
        });
      },

      onErrorEvent: (err: PreviewError) => {
        setError(err);
        setStatus("error");
        setMetrics(prev => ({ ...prev, errorCount: prev.errorCount + 1 }));
        
        addConsoleMessage("error", `${err.message} ${err.file ? `(${err.file}:${err.line})` : ""}`);
        
        toast({
          title: "Preview Error",
          description: err.message,
          variant: "destructive",
          duration: 5000,
        });
      },

      onError: (err: Error) => {
        setStatus("error");
        addConsoleMessage("error", `Connection error: ${err.message}`);
      },
    }
  );

  const addConsoleMessage = useCallback((type: DevConsoleMessage["type"], message: string, source?: string) => {
    const newMessage: DevConsoleMessage = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      message,
      timestamp: new Date(),
      source
    };
    
    setConsoleMessages(prev => [newMessage, ...prev].slice(0, 100)); // Keep last 100 messages
  }, []);

  const scheduleReconnection = useCallback(() => {
    if (reconnectTimeoutRef.current) return;
    
    reconnectTimeoutRef.current = setTimeout(() => {
      if (!socket.isConnected()) {
        addConsoleMessage("info", "Attempting to reconnect...");
        socket.forceReconnect();
      }
      reconnectTimeoutRef.current = null;
    }, 3000);
  }, [socket]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, []);

  // Enhanced iframe focus and interaction
  useEffect(() => {
    if (iframeRef.current && status === "success") {
      const timer = setTimeout(() => {
        iframeRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [key, status]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "r":
            e.preventDefault();
            handleReload();
            break;
          case "f":
            e.preventDefault();
            toggleFullscreen();
            break;
          case "`":
            e.preventDefault();
            setShowDevConsole(prev => !prev);
            break;
          case "1":
            e.preventDefault();
            setViewport("desktop");
            break;
          case "2":
            e.preventDefault();
            setViewport("tablet");
            break;
          case "3":
            e.preventDefault();
            setViewport("mobile");
            break;
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleReload = useCallback(() => {
    setKey((prev) => prev + 1);
    setStatus("building");
    setError(null);
    addConsoleMessage("info", "Manual reload triggered");
  }, [addConsoleMessage]);

  const handleForceReconnect = useCallback(() => {
    addConsoleMessage("info", "Force reconnection initiated");
    socket.forceReconnect();
  }, [socket, addConsoleMessage]);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement && containerRef.current) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
      setViewport("fullscreen");
    } else if (document.fullscreenElement) {
      document.exitFullscreen();
      setIsFullscreen(false);
      setViewport("desktop");
    }
  }, []);

  const openInNewTab = useCallback(() => {
    window.open("/", "_blank");
    addConsoleMessage("info", "Opened preview in new tab");
  }, [addConsoleMessage]);

  const clearConsole = useCallback(() => {
    setConsoleMessages([]);
  }, []);

  const getStatusIndicator = useMemo(() => {
    const indicators = {
      building: { color: "bg-yellow-500 animate-pulse", icon: Zap, label: "Building" },
      success: { color: "bg-green-500", icon: CheckCircle, label: "Ready" },
      error: { color: "bg-red-500 animate-pulse", icon: AlertTriangle, label: "Error" },
      offline: { color: "bg-gray-500", icon: WifiOff, label: "Offline" },
      connecting: { color: "bg-blue-500 animate-pulse", icon: Wifi, label: "Connecting" },
      idle: { color: "bg-blue-500", icon: Activity, label: "Idle" }
    };
    return indicators[status];
  }, [status]);

  const currentViewport = VIEWPORT_SIZES[viewport];
  const StatusIcon = getStatusIndicator.icon;

  return (
    <TooltipProvider>
      <div ref={containerRef} className="relative w-full h-full flex flex-col bg-background">
        {/* Enhanced Status Bar */}
        <div className="flex items-center justify-between p-3 bg-background border-b shadow-sm">
          <div className="flex items-center gap-4">
            {/* Connection Status */}
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${getStatusIndicator.color}`} />
              <StatusIcon className="w-4 h-4" />
              <Badge variant={status === "success" ? "default" : status === "error" ? "destructive" : "secondary"}>
                {getStatusIndicator.label}
              </Badge>
              {socket.metrics?.averageLatency && (
                <Badge variant="outline" className="text-xs">
                  {socket.metrics.averageLatency}ms
                </Badge>
              )}
            </div>

            {/* Build Progress */}
            {buildProgress > 0 && buildProgress < 100 && (
              <div className="flex items-center gap-2">
                <Progress value={buildProgress} className="w-24" />
                <span className="text-xs text-muted-foreground">{Math.round(buildProgress)}%</span>
              </div>
            )}

            {/* Metrics */}
            {metrics.buildCount > 0 && (
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Code className="w-3 h-3" />
                  {metrics.buildCount}
                </span>
                {metrics.errorCount > 0 && (
                  <span className="flex items-center gap-1 text-destructive">
                    <AlertTriangle className="w-3 h-3" />
                    {metrics.errorCount}
                  </span>
                )}
                {metrics.lastUpdate && (
                  <span className="flex items-center gap-1">
                    <Timer className="w-3 h-3" />
                    {metrics.lastUpdate.toLocaleTimeString()}
                  </span>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Viewport Controls */}
            <div className="flex items-center gap-1 bg-secondary/50 rounded-md p-1">
              {Object.entries(VIEWPORT_SIZES).map(([size, config]) => {
                const Icon = config.icon;
                return (
                  <Tooltip key={size}>
                    <TooltipTrigger asChild>
                      <Button
                        variant={viewport === size ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setViewport(size as ViewportSize)}
                        className="h-8 w-8 p-0"
                      >
                        <Icon className="w-4 h-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{config.label}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-1">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReload}
                    disabled={status === "building"}
                    className="h-8"
                  >
                    <RefreshCw className={cn("w-4 h-4", status === "building" && "animate-spin")} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Reload Preview (Ctrl+R)</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDevConsole(!showDevConsole)}
                    className={cn("h-8", showDevConsole && "bg-secondary")}
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Toggle Console (Ctrl+`)</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={openInNewTab}
                    className="h-8"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Open in New Tab</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleFullscreen}
                    className="h-8"
                  >
                    {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Fullscreen (Ctrl+F)</TooltipContent>
              </Tooltip>

              {!socket.isConnected() && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={handleForceReconnect}
                      className="h-8"
                    >
                      <Wifi className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Force Reconnect</TooltipContent>
                </Tooltip>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Main Preview Area */}
          <div className="flex-1 flex flex-col relative">
            {/* Error Overlay */}
            {error && (
              <div className="absolute inset-0 z-20 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4">
                <Alert variant="destructive" className="max-w-2xl">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle className="flex items-center justify-between">
                    Preview Error
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setError(null)}
                    >
                      <Square className="w-4 h-4" />
                    </Button>
                  </AlertTitle>
                  <AlertDescription className="space-y-3">
                    <div className="font-medium">{error.message}</div>
                    {error.file && (
                      <div className="text-sm text-muted-foreground font-mono">
                        {error.file}:{error.line}:{error.column}
                      </div>
                    )}
                    <div className="flex gap-2 pt-2">
                      <Button size="sm" onClick={handleReload}>
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Retry
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleForceReconnect}>
                        <Wifi className="w-4 h-4 mr-2" />
                        Reconnect
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Loading Overlay */}
            {status === "building" && (
              <div className="absolute inset-0 z-10 bg-background/90 backdrop-blur-sm flex items-center justify-center">
                <Card className="p-6">
                  <CardContent className="text-center space-y-4">
                    <div className="flex items-center justify-center">
                      <Zap className="w-8 h-8 animate-pulse text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Building preview...</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Processing your changes
                      </p>
                    </div>
                    {buildProgress > 0 && (
                      <Progress value={buildProgress} className="w-48" />
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Viewport Container */}
            <div className="flex-1 flex items-center justify-center p-4 bg-muted/30">
              <div 
                className={cn(
                  "relative bg-background border rounded-lg shadow-lg overflow-hidden transition-all duration-300",
                  viewport === "fullscreen" && "!w-full !h-full !rounded-none !border-0",
                  viewport === "desktop" && "w-full h-full",
                  viewport !== "desktop" && viewport !== "fullscreen" && "border-2"
                )}
                style={{
                  width: viewport !== "desktop" && viewport !== "fullscreen" ? currentViewport.width : "100%",
                  height: viewport !== "desktop" && viewport !== "fullscreen" ? currentViewport.height : "100%",
                  maxWidth: "100%",
                  maxHeight: "100%"
                }}
              >
                {/* Iframe */}
                <iframe
                  ref={iframeRef}
                  key={key}
                  src="/generate"
                  className={cn(
                    "w-full h-full border-none bg-white",
                    status === "building" && "opacity-50 pointer-events-none",
                    viewport !== "desktop" && viewport !== "fullscreen" && "rounded-lg"
                  )}
                  sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-downloads allow-modals"
                  allow="accelerometer; camera; encrypted-media; geolocation; gyroscope; microphone; midi; clipboard-write; display-capture"
                  title="InnoXAI Preview"
                  loading="eager"
                />

                {/* Viewport Label */}
                {viewport !== "desktop" && viewport !== "fullscreen" && (
                  <div className="absolute -top-6 left-0 text-xs text-muted-foreground bg-background px-2 py-1 rounded-t border-x border-t">
                    {currentViewport.label}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Developer Console */}
          {showDevConsole && (
            <div className="w-80 border-l bg-background flex flex-col">
              <div className="flex items-center justify-between p-3 border-b">
                <h3 className="font-medium flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Console
                </h3>
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearConsole}
                    className="h-7 text-xs"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDevConsole(false)}
                    className="h-7 text-xs"
                  >
                    <Square className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              <div className="flex-1 overflow-auto p-2 font-mono text-xs space-y-1">
                {consoleMessages.length === 0 ? (
                  <div className="text-muted-foreground text-center py-8">
                    No console messages
                  </div>
                ) : (
                  consoleMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={cn(
                        "p-2 rounded border-l-2 text-xs",
                        msg.type === "error" && "border-red-500 bg-red-50 dark:bg-red-950/20",
                        msg.type === "warn" && "border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20",
                        msg.type === "info" && "border-blue-500 bg-blue-50 dark:bg-blue-950/20",
                        msg.type === "log" && "border-gray-500 bg-gray-50 dark:bg-gray-950/20"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn(
                          "text-xs font-medium",
                          msg.type === "error" && "text-red-600",
                          msg.type === "warn" && "text-yellow-600",
                          msg.type === "info" && "text-blue-600",
                          msg.type === "log" && "text-gray-600"
                        )}>
                          {msg.type.toUpperCase()}
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {msg.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <div>{msg.message}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Status Footer */}
        <div className="flex items-center justify-between px-3 py-1 bg-muted/50 border-t text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>Socket: {socket.isConnected() ? "Connected" : "Disconnected"}</span>
            {socket.metrics && (
              <>
                <span>Latency: {socket.metrics.averageLatency || 0}ms</span>
                <span>Messages: {socket.metrics.totalMessages}</span>
              </>
            )}
          </div>
          <div className="text-xs">
            Ctrl+R: Reload • Ctrl+F: Fullscreen • Ctrl+`: Console • Ctrl+1/2/3: Viewports
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}