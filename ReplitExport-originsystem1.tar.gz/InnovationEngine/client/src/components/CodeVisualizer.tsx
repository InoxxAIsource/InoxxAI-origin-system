import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { nightOwl } from 'react-syntax-highlighter/dist/esm/styles/prism';
import '../styles/code-visualizer.css';

interface CodeVisualizerProps {
  code: string;
  language?: string;
  speed?: number;
}

export default function CodeVisualizer({ code, language = 'jsx', speed = 20 }: CodeVisualizerProps) {
  const [displayedCode, setDisplayedCode] = useState('');
  const [isAnimating, setIsAnimating] = useState(false);
  const animationRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!code) return;

    setIsAnimating(true);
    let currentIndex = 0;
    setDisplayedCode('');

    const animateTyping = () => {
      if (currentIndex < code.length) {
        setDisplayedCode(prev => prev + code[currentIndex]);
        currentIndex++;
        animationRef.current = setTimeout(animateTyping, speed);
      } else {
        setIsAnimating(false);
      }
    };

    animateTyping();

    return () => {
      if (animationRef.current) {
        clearTimeout(animationRef.current);
      }
    };
  }, [code, speed]);

  return (
    <div className="code-visualizer">
      <AnimatePresence>
        {isAnimating && (
          <motion.div 
            className="typing-cursor"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: 1,
              transition: { repeat: Infinity, duration: 0.8 }
            }}
            exit={{ opacity: 0 }}
          />
        )}
      </AnimatePresence>

      <SyntaxHighlighter
        language={language}
        style={nightOwl}
        showLineNumbers={true}
        customStyle={{
          margin: 0,
          padding: '1rem',
          background: '#011627',
          borderRadius: '0.375rem',
          fontSize: '14px',
          lineHeight: '1.6'
        }}
      >
        {displayedCode}
      </SyntaxHighlighter>
    </div>
  );
}