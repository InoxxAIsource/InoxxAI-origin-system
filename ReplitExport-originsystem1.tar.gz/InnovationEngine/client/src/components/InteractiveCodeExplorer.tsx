import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus, vs } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { 
  Info, 
  Search, 
  Layers, 
  Code, 
  Eye, 
  BookOpen, 
  Zap,
  ChevronRight,
  ChevronDown,
  Target,
  FileText,
  Lightbulb
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { cn } from '@/lib/utils';

interface CodeElement {
  type: 'component' | 'function' | 'variable' | 'import' | 'hook' | 'prop' | 'css';
  name: string;
  line: number;
  column: number;
  description: string;
  explanation: string;
  usage?: string;
  dependencies?: string[];
  category: string;
}

interface InteractiveCodeExplorerProps {
  code: string;
  language?: string;
  className?: string;
  onElementSelect?: (element: CodeElement) => void;
}

export function InteractiveCodeExplorer({
  code,
  language = 'typescript',
  className,
  onElementSelect
}: InteractiveCodeExplorerProps) {
  const [selectedElement, setSelectedElement] = useState<CodeElement | null>(null);
  const [hoveredElement, setHoveredElement] = useState<CodeElement | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [highlightedLines, setHighlightedLines] = useState<number[]>([]);
  const [explorationMode, setExplorationMode] = useState<'hover' | 'click'>('hover');
  const codeRef = useRef<HTMLDivElement>(null);

  const getHookExplanation = (hookName: string): string => {
    const explanations: Record<string, string> = {
      useState: 'useState manages component state. It returns the current state value and a setter function.',
      useEffect: 'useEffect performs side effects in functional components. It runs after render.',
      useRef: 'useRef creates a mutable ref object that persists across re-renders.',
      useMemo: 'useMemo memoizes expensive calculations and only recalculates when dependencies change.',
      useCallback: 'useCallback memoizes functions to prevent unnecessary re-renders of child components.'
    };
    return explanations[hookName] || 'React hook for managing component behavior.';
  };

  const getCSSExplanation = (className: string): string => {
    if (className.startsWith('bg-')) return 'Background color utility class';
    if (className.startsWith('text-')) return 'Text styling utility class';
    if (className.startsWith('p-') || className.startsWith('m-')) return 'Spacing utility class';
    if (className.startsWith('flex')) return 'Flexbox layout utility class';
    if (className.startsWith('grid')) return 'CSS Grid layout utility class';
    if (className.includes('hover:')) return 'Hover state styling class';
    return 'CSS utility class for styling';
  };

  // Parse code to extract interactive elements
  const codeElements = useMemo(() => {
    const elements: CodeElement[] = [];
    const lines = code.split('\n');

    lines.forEach((line, index) => {
      const lineNumber = index + 1;
      
      // React components
      const componentMatch = line.match(/(?:const|function)\s+([A-Z][a-zA-Z0-9]*)/);
      if (componentMatch) {
        elements.push({
          type: 'component',
          name: componentMatch[1],
          line: lineNumber,
          column: line.indexOf(componentMatch[1]),
          description: `React component ${componentMatch[1]}`,
          explanation: `This is a React functional component that renders UI elements. Components are reusable pieces of code that return JSX.`,
          usage: `<${componentMatch[1]} />`,
          category: 'Components'
        });
      }

      // React hooks
      const hookMatch = line.match(/const\s+\[([^,]+),\s*([^\]]+)\]\s*=\s*(useState|useEffect|useRef|useMemo|useCallback)/);
      if (hookMatch) {
        elements.push({
          type: 'hook',
          name: hookMatch[3],
          line: lineNumber,
          column: line.indexOf(hookMatch[3]),
          description: `React ${hookMatch[3]} hook`,
          explanation: getHookExplanation(hookMatch[3]),
          usage: `${hookMatch[3]}(initialValue)`,
          category: 'Hooks'
        });
      }

      // Props and destructuring
      const propsMatch = line.match(/\{\s*([^}]+)\s*\}/);
      if (propsMatch && line.includes('=>')) {
        const props = propsMatch[1].split(',').map(p => p.trim());
        props.forEach(prop => {
          if (prop && !prop.includes('...')) {
            elements.push({
              type: 'prop',
              name: prop,
              line: lineNumber,
              column: line.indexOf(prop),
              description: `Component prop: ${prop}`,
              explanation: `This is a prop (property) passed to the component. Props allow data to flow from parent to child components.`,
              category: 'Props'
            });
          }
        });
      }

      // Functions
      const functionMatch = line.match(/const\s+([a-z][a-zA-Z0-9]*)\s*=\s*(?:\([^)]*\))?\s*=>/);
      if (functionMatch) {
        elements.push({
          type: 'function',
          name: functionMatch[1],
          line: lineNumber,
          column: line.indexOf(functionMatch[1]),
          description: `Function: ${functionMatch[1]}`,
          explanation: `This is an arrow function that encapsulates logic and can be called to perform operations.`,
          category: 'Functions'
        });
      }

      // CSS classes
      const cssMatch = line.match(/className=["']([^"']+)["']/);
      if (cssMatch) {
        const classes = cssMatch[1].split(' ').filter(cls => cls.trim());
        classes.forEach(cls => {
          elements.push({
            type: 'css',
            name: cls,
            line: lineNumber,
            column: line.indexOf(cls),
            description: `CSS class: ${cls}`,
            explanation: getCSSExplanation(cls),
            category: 'Styling'
          });
        });
      }

      // Imports
      const importMatch = line.match(/import\s+(?:\{([^}]+)\}|\*\s+as\s+(\w+)|(\w+))\s+from\s+['"]([^'"]+)['"]/);
      if (importMatch) {
        const importName = importMatch[1] || importMatch[2] || importMatch[3];
        const source = importMatch[4];
        elements.push({
          type: 'import',
          name: importName,
          line: lineNumber,
          column: 0,
          description: `Import from ${source}`,
          explanation: `This imports functionality from an external module or library.`,
          dependencies: [source],
          category: 'Imports'
        });
      }
    });

    return elements;
  }, [code]);

  const filteredElements = useMemo(() => {
    if (!searchQuery) return codeElements;
    return codeElements.filter(element =>
      element.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      element.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      element.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [codeElements, searchQuery]);

  const categories = useMemo(() => {
    const cats = Array.from(new Set(codeElements.map(el => el.category)));
    return cats.map(category => ({
      name: category,
      count: codeElements.filter(el => el.category === category).length,
      elements: codeElements.filter(el => el.category === category)
    }));
  }, [codeElements]);

  const handleElementClick = (element: CodeElement) => {
    setSelectedElement(element);
    setHighlightedLines([element.line]);
    onElementSelect?.(element);
  };

  const handleElementHover = (element: CodeElement) => {
    if (explorationMode === 'hover') {
      setHoveredElement(element);
      setHighlightedLines([element.line]);
    }
  };

  const LineWrapper = ({ children, lineNumber }: { children: React.ReactNode; lineNumber: number }) => {
    const isHighlighted = highlightedLines.includes(lineNumber);
    const hasElements = codeElements.some(el => el.line === lineNumber);
    
    return (
      <div
        className={cn(
          'relative transition-all duration-200',
          isHighlighted && 'bg-blue-500/10 border-l-2 border-l-blue-500',
          hasElements && 'hover:bg-muted/50 cursor-pointer'
        )}
        onMouseEnter={() => {
          const lineElements = codeElements.filter(el => el.line === lineNumber);
          if (lineElements.length > 0) {
            handleElementHover(lineElements[0]);
          }
        }}
        onMouseLeave={() => setHoveredElement(null)}
        onClick={() => {
          const lineElements = codeElements.filter(el => el.line === lineNumber);
          if (lineElements.length > 0) {
            handleElementClick(lineElements[0]);
          }
        }}
      >
        {children}
      </div>
    );
  };

  return (
    <div className={cn('grid grid-cols-1 lg:grid-cols-3 gap-6', className)}>
      {/* Code Display */}
      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Code className="h-5 w-5" />
                Interactive Code Explorer
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant={explorationMode === 'hover' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setExplorationMode('hover')}
                >
                  Hover Mode
                </Button>
                <Button
                  variant={explorationMode === 'click' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setExplorationMode('click')}
                >
                  Click Mode
                </Button>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              {explorationMode === 'hover' ? 'Hover over code lines to explore' : 'Click on code lines to explore'}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div ref={codeRef} className="relative">
              <SyntaxHighlighter
                language={language}
                style={vscDarkPlus}
                showLineNumbers={true}
                wrapLines={true}
                lineProps={(lineNumber) => ({
                  style: { display: 'block', width: '100%' }
                })}
                customStyle={{
                  margin: 0,
                  fontSize: '14px',
                  fontFamily: 'var(--font-mono)',
                  lineHeight: '1.6',
                  padding: '16px',
                  background: 'transparent',
                  borderRadius: 0,
                  maxHeight: '600px',
                  overflow: 'auto',
                }}
              >
                {code}
              </SyntaxHighlighter>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Exploration Panel */}
      <div className="space-y-4">
        {/* Search */}
        <Card>
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search code elements..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Active Element Details */}
        {(selectedElement || hoveredElement) && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="h-4 w-4" />
                Element Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(() => {
                const element = selectedElement || hoveredElement;
                if (!element) return null;
                return (
                  <>
                    <div>
                      <Badge variant="secondary" className="mb-2">
                        {element.type}
                      </Badge>
                      <h4 className="font-semibold">{element.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        Line {element.line}
                      </p>
                    </div>
                    <div>
                      <h5 className="font-medium mb-1">Description</h5>
                      <p className="text-sm">{element.description}</p>
                    </div>
                    <div>
                      <h5 className="font-medium mb-1">Explanation</h5>
                      <p className="text-sm text-muted-foreground">
                        {element.explanation}
                      </p>
                    </div>
                    {element.usage && (
                      <div>
                        <h5 className="font-medium mb-1">Usage</h5>
                        <code className="text-sm bg-muted px-2 py-1 rounded">
                          {element.usage}
                        </code>
                      </div>
                    )}
                    {element.dependencies && (
                      <div>
                        <h5 className="font-medium mb-1">Dependencies</h5>
                        <div className="flex flex-wrap gap-1">
                          {element.dependencies.map((dep, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {dep}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}
            </CardContent>
          </Card>
        )}

        {/* Code Structure */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Code Structure
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="categories">Categories</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="mt-4">
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {filteredElements.map((element, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => handleElementClick(element)}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm">{element.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {element.type}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Line {element.line} • {element.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="categories" className="mt-4">
                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {categories.map((category, idx) => (
                      <div key={idx}>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-sm">{category.name}</h4>
                          <Badge variant="secondary" className="text-xs">
                            {category.count}
                          </Badge>
                        </div>
                        <div className="space-y-1 ml-4">
                          {category.elements.slice(0, 3).map((element, elemIdx) => (
                            <div
                              key={elemIdx}
                              className="text-sm text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
                              onClick={() => handleElementClick(element)}
                            >
                              {element.name}
                            </div>
                          ))}
                          {category.elements.length > 3 && (
                            <div className="text-xs text-muted-foreground">
                              +{category.elements.length - 3} more...
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Lightbulb className="h-4 w-4" />
              Learning Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-sm">
              <p className="font-medium mb-1">Pro Tips:</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Hover over elements to see instant explanations</li>
                <li>• Click elements to see detailed information</li>
                <li>• Use search to find specific components</li>
                <li>• Explore categories to understand code structure</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}