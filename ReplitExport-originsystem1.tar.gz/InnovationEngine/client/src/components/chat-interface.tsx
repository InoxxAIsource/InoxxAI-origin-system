import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Generation Progress Component
function GenerationProgress({ status, progress }: { status: string; progress: number }) {
  const statusMessages = {
    analyzing: "Analyzing requirements...",
    building: "Building components...",
    finalizing: "Finalizing project..."
  };
  
  return (
    <div className="generation-progress">
      <div className="progress-bar">
        <div 
          className="progress-fill" 
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="status-message">
        {statusMessages[status as keyof typeof statusMessages] || "Starting generation..."}
      </div>
    </div>
  );
}

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  projectId?: number;
  generatedCode?: string;
  framework?: string;
  styling?: string;
  metadata?: {
    architecture?: any;
    quality?: any;
    iterations?: number;
  };
}

interface ChatInterfaceProps {
  onProjectCreated?: (projectId: number) => void;
}

export default function ChatInterface({ onProjectCreated }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hi! I'm InnoXAI, your AI development assistant. I can help you create new projects, generate code, and build applications. What would you like to create today?",
      role: 'assistant',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [generationProgress, setGenerationProgress] = useState({
    status: 'idle' as 'idle' | 'analyzing' | 'building' | 'finalizing',
    progress: 0
  });
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // AI code generation mutation
  const generateCodeMutation = useMutation({
    mutationFn: async (prompt: string) => {
      // Start progress tracking
      setGenerationProgress({ status: 'analyzing', progress: 10 });
      
      // Simulate analysis phase
      await new Promise(resolve => setTimeout(resolve, 800));
      setGenerationProgress({ status: 'building', progress: 40 });
      
      const response = await apiRequest("POST", "/api/ai/generate", {
        prompt,
        framework: "react",
        styling: "tailwind"
      });
      
      setGenerationProgress({ status: 'finalizing', progress: 80 });
      const data = await response.json();
      
      // Complete progress
      setGenerationProgress({ status: 'idle', progress: 100 });
      
      return data;
    },
    onSuccess: (data: any) => {
      console.log('AI generation successful:', data);
      
      // Clean up the generated code (remove markdown formatting)
      let cleanCode = data.code || data.generatedCode || '';
      
      // Remove markdown code blocks
      cleanCode = cleanCode.replace(/```typescript\n?/g, '').replace(/```jsx?\n?/g, '').replace(/```\n?/g, '');
      
      // Remove extra comments and instructions
      cleanCode = cleanCode.replace(/### Additional Steps[\s\S]*$/, '').trim();
      
      console.log('Cleaned code:', cleanCode.substring(0, 100) + '...');
      
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: "I've generated some code for you! Here's what I created:",
        role: 'assistant',
        timestamp: new Date(),
        generatedCode: cleanCode,
        framework: data.framework || "react",
        styling: data.styling || "tailwind"
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    },
    onError: (error) => {
      console.error('Generation error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "I encountered an error generating the code. Please try again with a different prompt.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsLoading(false);
    }
  });

  // Multi-agent collaboration mutation
  const multiAgentMutation = useMutation({
    mutationFn: async (data: { prompt: string }) => {
      setGenerationProgress({ status: 'analyzing', progress: 10 });
      const response = await apiRequest("POST", "/api/ai/multi-agent", data);
      setGenerationProgress({ status: 'building', progress: 70 });
      await new Promise(resolve => setTimeout(resolve, 1000));
      setGenerationProgress({ status: 'finalizing', progress: 100 });
      return response;
    },
    onSuccess: (data: any) => {
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: `Multi-agent collaboration complete! Quality score: ${data.quality?.score || 'N/A'}/10. Generated in ${data.iterations} iterations.`,
        role: 'assistant',
        timestamp: new Date(),
        generatedCode: data.code,
        framework: "react",
        styling: "tailwind",
        metadata: {
          architecture: data.architecture,
          quality: data.quality,
          iterations: data.iterations
        }
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
      setGenerationProgress({ status: 'finalizing', progress: 100 });
    },
    onError: (error) => {
      console.error('Multi-agent generation error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "Multi-agent collaboration encountered an error. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsLoading(false);
    }
  });

  // Autonomous Orchestration mutation
  const autonomousAgentsMutation = useMutation({
    mutationFn: async (prompt: string) => {
      setGenerationProgress({ status: 'analyzing', progress: 10 });
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setGenerationProgress({ status: 'building', progress: 40 });
      const response = await fetch("/api/autonomous", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      
      if (!response.ok) {
        throw new Error(`Autonomous orchestration failed: ${response.status}`);
      }
      
      setGenerationProgress({ status: 'finalizing', progress: 90 });
      const data = await response.json();
      
      setGenerationProgress({ status: 'idle', progress: 100 });
      return data.output;
    },
    onSuccess: (data: any) => {
      console.log('Autonomous orchestration successful:', data);
      
      let content = `I've used autonomous orchestration with ${data.iterations} iterations to create your project! `;
      content += `Quality score: ${(data.qualityScore * 100).toFixed(0)}%. `;
      
      if (data.plan) {
        content += `The system identified this as ${data.plan.complexity} complexity. `;
      }
      
      if (data.tests) {
        content += `Generated comprehensive tests with ${(data.tests.coverage * 100).toFixed(0)}% coverage. `;
      }
      
      content += "The autonomous system performed self-correction and quality assessment to deliver optimal results.";

      const assistantMessage: Message = {
        id: Date.now().toString(),
        content,
        role: 'assistant',
        timestamp: new Date(),
        generatedCode: data.code?.code || '',
        framework: "react",
        styling: "tailwind",
        metadata: {
          architecture: data.plan?.architecture,
          quality: data.qualityScore,
          iterations: data.iterations
        }
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
      
      toast({
        title: "Autonomous orchestration completed!",
        description: `Generated high-quality code with ${data.iterations} self-improvement iterations`,
      });
    },
    onError: (error) => {
      console.error('Autonomous orchestration error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "The autonomous orchestration system encountered an issue. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsLoading(false);
      setGenerationProgress({ status: 'idle', progress: 0 });
    }
  });

  // Specialized Multi-Agent Generation mutation
  const specializedAgentsMutation = useMutation({
    mutationFn: async (prompt: string) => {
      setGenerationProgress({ status: 'analyzing', progress: 20 });
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      setGenerationProgress({ status: 'building', progress: 60 });
      const response = await fetch("/api/multi-agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      
      if (!response.ok) {
        throw new Error(`Multi-agent request failed: ${response.status}`);
      }
      
      setGenerationProgress({ status: 'finalizing', progress: 85 });
      const data = await response.json();
      
      setGenerationProgress({ status: 'idle', progress: 100 });
      return data.output;
    },
    onSuccess: (data: any) => {
      console.log('Specialized agents generation successful:', data);
      
      let content = "I've used my specialized development team to create your project! ";
      
      if (data.plan) {
        content += `The planning agent identified this as a ${data.plan.complexity} complexity project with ${data.plan.components?.length || 0} components needed. `;
      }
      
      if (data.dependencies?.required?.length > 0) {
        content += `Dependencies analyzed: ${data.dependencies.required.slice(0, 3).join(', ')}${data.dependencies.required.length > 3 ? '...' : ''}. `;
      }
      
      if (data.code?.code) {
        content += "The code writing agent has generated clean, production-ready code with proper TypeScript types and error handling.";
      }

      const assistantMessage: Message = {
        id: Date.now().toString(),
        content,
        role: 'assistant',
        timestamp: new Date(),
        generatedCode: data.code?.code || '',
        framework: data.framework || "react",
        styling: data.styling || "tailwind",
        metadata: {
          architecture: data.plan?.architecture,
          quality: data.dependencies?.suggestions,
          iterations: 1
        }
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
      
      toast({
        title: "Specialized agents completed!",
        description: `Generated ${data.plan?.complexity || 'custom'} complexity project with advanced planning`,
      });
    },
    onError: (error) => {
      console.error('Specialized agents generation error:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "The specialized development team encountered an issue. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsLoading(false);
      setGenerationProgress({ status: 'idle', progress: 0 });
    }
  });

  // Full-stack project generation mutation
  const generateProjectMutation = useMutation({
    mutationFn: async (data: { prompt: string; projectName: string }) => {
      setGenerationProgress({ status: 'analyzing', progress: 15 });
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setGenerationProgress({ status: 'building', progress: 50 });
      const response = await apiRequest("POST", "/api/ai/fullstack", data);
      
      setGenerationProgress({ status: 'finalizing', progress: 90 });
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setGenerationProgress({ status: 'idle', progress: 100 });
      return await response.json();
    },
    onSuccess: (data: any) => {
      let content = `I've created a complete full-stack project with ${data.files.length} files! This includes frontend components, backend API routes, and all necessary configuration files.`;
      
      // Add information about automatic fixes if any were applied
      if (data.fixes && data.fixes.length > 0) {
        content += `\n\nAutomatic fixes applied:\n${data.fixes.map((fix: string) => `• ${fix}`).join('\n')}`;
      }
      
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content,
        role: 'assistant',
        timestamp: new Date(),
        projectId: data.project.id,
        generatedCode: data.files.find((f: any) => f.path.includes('App.'))?.content || '',
        framework: "react",
        styling: "tailwind"
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
      
      toast({
        title: "Full-stack project created!",
        description: `Generated ${data.files.length} files with backend API${data.fixes?.length ? ` (${data.fixes.length} issues auto-fixed)` : ''}`,
      });
      
      onProjectCreated?.(data.project.id);
    },
    onError: (error) => {
      console.error('Project generation error:', error);
      setGenerationProgress({ status: 'idle', progress: 0 });
      setIsLoading(false);
      
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "I encountered an error generating the full-stack project. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  });

  // Create project mutation
  const createProjectMutation = useMutation({
    mutationFn: async (projectData: { name: string; description: string }) => {
      return apiRequest("POST", "/api/projects", projectData);
    },
    onSuccess: (project: any) => {
      toast({
        title: "Project created",
        description: `${project.name} has been created successfully.`,
      });
      onProjectCreated?.(project.id);
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Check if user specifically wants to create a new project (not generate code)
    if (inputValue.toLowerCase().includes('create new project') || 
        inputValue.toLowerCase().includes('new project called') ||
        inputValue.toLowerCase().includes('start a new project') ||
        inputValue.toLowerCase().includes('start new project')) {
      
      // Extract project name from the message
      const projectName = extractProjectName(inputValue);
      const description = `Generated project: ${inputValue}`;

      try {
        await createProjectMutation.mutateAsync({
          name: projectName,
          description: description
        });

        const assistantMessage: Message = {
          id: Date.now().toString(),
          content: `Great! I've created a new project called "${projectName}". You can now start building your application!`,
          role: 'assistant',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMessage]);
        setIsLoading(false);
      } catch (error) {
        const errorMessage: Message = {
          id: Date.now().toString(),
          content: "I had trouble creating the project. Please try again.",
          role: 'assistant',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, errorMessage]);
        setIsLoading(false);
      }
    } else {
      // Intelligent generation mode selection based on prompt complexity
      const lowerPrompt = inputValue.toLowerCase();
      
      const isComplexProject = lowerPrompt.includes('fullstack') || 
                              lowerPrompt.includes('full stack') ||
                              lowerPrompt.includes('backend') ||
                              lowerPrompt.includes('api') ||
                              lowerPrompt.includes('database');
      
      const needsAutonomousOrchestration = lowerPrompt.includes('autonomous') ||
                                      lowerPrompt.includes('self-improving') ||
                                      lowerPrompt.includes('iterative') ||
                                      lowerPrompt.includes('high-quality') ||
                                      inputValue.split(' ').length > 20;

      const needsSpecializedAgents = lowerPrompt.includes('advanced') ||
                                   lowerPrompt.includes('professional') ||
                                   lowerPrompt.includes('enterprise') ||
                                   lowerPrompt.includes('dashboard') ||
                                   lowerPrompt.includes('complex') ||
                                   inputValue.split(' ').length > 15;

      const needsCollaboration = lowerPrompt.includes('multi-agent') ||
                                lowerPrompt.includes('collaborative') ||
                                lowerPrompt.includes('team');

      // Debug logging to understand routing
      console.log('Routing analysis:', {
        prompt: inputValue,
        isComplexProject,
        needsAutonomousOrchestration,
        needsSpecializedAgents,
        needsCollaboration,
        wordCount: inputValue.split(' ').length
      });

      if (isComplexProject) {
        console.log('Using full-stack multi-agent generation');
        generateProjectMutation.mutate({ 
          prompt: inputValue, 
          projectName: 'Generated Project'
        });
      } else if (needsAutonomousOrchestration) {
        console.log('Using autonomous orchestration system');
        autonomousAgentsMutation.mutate(inputValue);
      } else if (needsSpecializedAgents) {
        console.log('Using specialized development team');
        specializedAgentsMutation.mutate(inputValue);
      } else if (needsCollaboration) {
        console.log('Using multi-agent collaboration');
        multiAgentMutation.mutate({ prompt: inputValue });
      } else {
        console.log('Using standard single-agent generation');
        generateCodeMutation.mutate(inputValue);
      }
    }
  };

  const extractProjectName = (prompt: string): string => {
    // Simple extraction - look for common patterns
    const patterns = [
      /create (?:a )?(?:new )?(?:project|app|website) (?:called |named )?["']?([^"']+)["']?/i,
      /(?:build|make) (?:a )?(?:new )?["']?([^"']+)["']? (?:project|app|website)/i,
      /["']([^"']+)["'] (?:project|app|website)/i
    ];

    for (const pattern of patterns) {
      const match = prompt.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }

    // Fallback - use first few words
    return prompt.split(' ').slice(1, 4).join(' ') || 'New Project';
  };

  const applyGeneratedCode = async (code: string, messageId: string) => {
    try {
      // Create a new file with the generated code
      const fileName = `generated-${Date.now()}.jsx`;
      
      await apiRequest("POST", "/api/files", {
        projectId: 1, // Default project for now
        path: `src/${fileName}`,
        content: code,
        language: "javascript",
        isOpen: true
      });

      toast({
        title: "Code applied",
        description: `Generated code has been added to ${fileName}`,
      });

      // Update the message to show it was applied
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? { ...msg, content: msg.content + "\n\n✅ Code has been applied to your project!" }
          : msg
      ));

    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to apply the generated code",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground">InnoXAI Assistant</h2>
        <p className="text-sm text-muted-foreground">Ask me to create projects or generate code</p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.role === 'user'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              <div className="whitespace-pre-wrap">{message.content}</div>
              
              {/* Show generated code if available */}
              {message.generatedCode && (
                <Card className="mt-3">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center justify-between">
                      Generated Code
                      <div className="flex gap-2">
                        <Badge variant="secondary">{message.framework}</Badge>
                        <Badge variant="secondary">{message.styling}</Badge>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs bg-secondary/50 p-3 rounded overflow-auto max-h-40">
                      <code>{message.generatedCode}</code>
                    </pre>
                    <Button
                      size="sm"
                      className="mt-2"
                      onClick={() => applyGeneratedCode(message.generatedCode!, message.id)}
                    >
                      Apply to Project
                    </Button>
                  </CardContent>
                </Card>
              )}
              
              <div className="text-xs opacity-70 mt-1">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {/* Show generation progress */}
        {generationProgress.status !== 'idle' && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-lg p-3 bg-muted text-muted-foreground">
              <GenerationProgress 
                status={generationProgress.status} 
                progress={generationProgress.progress} 
              />
            </div>
          </div>
        )}
        
        {isLoading && generationProgress.status === 'idle' && (
          <div className="flex justify-start">
            <div className="bg-muted text-muted-foreground rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                <span>Thinking...</span>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-border">
        <div className="flex space-x-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message... (e.g., 'Create a new React todo app')"
            disabled={isLoading}
            className="flex-1"
          />
          <Button type="submit" disabled={isLoading || !inputValue.trim()}>
            <i className="fas fa-paper-plane"></i>
          </Button>
        </div>
        
        {/* Advanced Options Toggle */}
        <div className="mt-2 flex items-center justify-between">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
            className="text-xs"
          >
            {showAdvancedOptions ? 'Hide' : 'Show'} Advanced Options
          </Button>
        </div>

        {showAdvancedOptions && (
          <div className="mt-3 p-3 bg-muted rounded-lg">
            <div className="flex gap-2 mb-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  if (inputValue.trim()) {
                    const projectName = `Generated Project ${Date.now()}`;
                    setIsLoading(true);
                    generateProjectMutation.mutate({ prompt: inputValue, projectName });
                    setInputValue('');
                  }
                }}
                disabled={isLoading || !inputValue.trim()}
                className="text-xs"
              >
                Generate Full-Stack Project
              </Button>
              <Button
                type="button"
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (inputValue.trim()) {
                    setIsLoading(true);
                    generateCodeMutation.mutate(inputValue);
                    setInputValue('');
                  }
                }}
                disabled={isLoading || !inputValue.trim()}
                className="text-xs"
              >
                Generate Component Only
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Full-stack projects include frontend, backend API, and database models. 
              Component generation creates single React components.
            </p>
          </div>
        )}
        
        <div className="mt-2 flex flex-wrap gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Create a dashboard with charts and data visualization")}
            disabled={isLoading}
          >
            Dashboard with API
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Create an e-commerce product listing page")}
            disabled={isLoading}
          >
            E-commerce Store
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Create a blog platform with user authentication")}
            disabled={isLoading}
          >
            Blog Platform
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Build a dashboard with charts")}
            disabled={isLoading}
          >
            Dashboard
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Generate a contact form component")}
            disabled={isLoading}
          >
            Contact Form
          </Button>
        </div>
      </form>
    </div>
  );
}