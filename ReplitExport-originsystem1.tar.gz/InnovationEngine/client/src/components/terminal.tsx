import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TerminalProps {
  projectId: number;
}

interface TerminalLine {
  id: number;
  type: 'command' | 'output' | 'error' | 'success';
  content: string;
  timestamp: Date;
}

export default function Terminal({ projectId }: TerminalProps) {
  const [history, setHistory] = useState<TerminalLine[]>([
    {
      id: 1,
      type: 'success',
      content: '✓ Development server started on http://localhost:5000',
      timestamp: new Date(),
    },
    {
      id: 2,
      type: 'success',
      content: '✓ Package dependencies installed successfully',
      timestamp: new Date(),
    },
    {
      id: 3,
      type: 'output',
      content: '⚠ Found 2 packages with available updates',
      timestamp: new Date(),
    },
  ]);
  
  const [currentCommand, setCurrentCommand] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [currentPath, setCurrentPath] = useState('~/my-react-app');
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const installPackageMutation = useMutation({
    mutationFn: async (packageName: string) => {
      return apiRequest("POST", "/api/packages/install", {
        packageName,
        projectId,
      });
    },
    onSuccess: (data) => {
      addToHistory({
        type: 'success',
        content: `✓ ${data.packageName}@${data.version} installed successfully`,
      });
    },
    onError: () => {
      addToHistory({
        type: 'error',
        content: '✗ Package installation failed',
      });
    },
  });

  useEffect(() => {
    // Auto-scroll to bottom when new content is added
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [history]);

  useEffect(() => {
    // Focus input when component mounts
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const addToHistory = (line: Omit<TerminalLine, 'id' | 'timestamp'>) => {
    setHistory(prev => [
      ...prev,
      {
        ...line,
        id: Date.now(),
        timestamp: new Date(),
      },
    ]);
  };

  const executeCommand = async (command: string) => {
    const trimmedCommand = command.trim();
    if (!trimmedCommand) return;

    // Add command to history
    addToHistory({
      type: 'command',
      content: `$ ${trimmedCommand}`,
    });

    // Add to command history
    setCommandHistory(prev => [...prev, trimmedCommand]);
    setHistoryIndex(-1);

    // Parse and execute command
    const [cmd, ...args] = trimmedCommand.split(' ');

    switch (cmd.toLowerCase()) {
      case 'npm':
      case 'yarn':
        handlePackageCommand(cmd, args);
        break;
      
      case 'ls':
      case 'dir':
        handleListCommand();
        break;
      
      case 'cd':
        handleChangeDirectory(args[0] || '~');
        break;
      
      case 'pwd':
        addToHistory({
          type: 'output',
          content: currentPath,
        });
        break;
      
      case 'clear':
        setHistory([]);
        break;
      
      case 'help':
        handleHelpCommand();
        break;
      
      case 'git':
        handleGitCommand(args);
        break;
      
      default:
        addToHistory({
          type: 'error',
          content: `Command not found: ${cmd}`,
        });
    }

    setCurrentCommand('');
  };

  const handlePackageCommand = async (packageManager: string, args: string[]) => {
    const [action, ...packages] = args;

    switch (action) {
      case 'install':
      case 'add':
        if (packages.length === 0) {
          addToHistory({
            type: 'output',
            content: 'Installing dependencies...',
          });
          setTimeout(() => {
            addToHistory({
              type: 'success',
              content: '✓ Dependencies installed successfully',
            });
          }, 1000);
        } else {
          packages.forEach(pkg => {
            addToHistory({
              type: 'output',
              content: `Installing ${pkg}...`,
            });
            installPackageMutation.mutate(pkg);
          });
        }
        break;
      
      case 'start':
      case 'dev':
        addToHistory({
          type: 'output',
          content: 'Starting development server...',
        });
        setTimeout(() => {
          addToHistory({
            type: 'success',
            content: '✓ Server running at http://localhost:5000',
          });
          addToHistory({
            type: 'success',
            content: '✓ Live reload enabled',
          });
        }, 1500);
        break;
      
      case 'build':
        addToHistory({
          type: 'output',
          content: 'Building for production...',
        });
        setTimeout(() => {
          addToHistory({
            type: 'success',
            content: '✓ Build completed successfully',
          });
        }, 2000);
        break;
      
      default:
        addToHistory({
          type: 'error',
          content: `Unknown ${packageManager} command: ${action}`,
        });
    }
  };

  const handleListCommand = () => {
    const files = [
      'src/',
      'public/',
      'package.json',
      'README.md',
      'node_modules/',
    ];
    
    files.forEach(file => {
      addToHistory({
        type: 'output',
        content: file,
      });
    });
  };

  const handleChangeDirectory = (path: string) => {
    if (path === '~' || path === '') {
      setCurrentPath('~/my-react-app');
    } else if (path === '..') {
      const parts = currentPath.split('/');
      if (parts.length > 1) {
        setCurrentPath(parts.slice(0, -1).join('/'));
      }
    } else {
      setCurrentPath(`${currentPath}/${path}`);
    }
  };

  const handleHelpCommand = () => {
    const helpText = [
      'Available commands:',
      '  npm install [package]  - Install packages',
      '  npm start              - Start development server',
      '  npm build              - Build for production',
      '  ls, dir                - List files',
      '  cd [directory]         - Change directory',
      '  pwd                    - Show current directory',
      '  git status             - Show git status',
      '  clear                  - Clear terminal',
      '  help                   - Show this help',
    ];
    
    helpText.forEach(line => {
      addToHistory({
        type: 'output',
        content: line,
      });
    });
  };

  const handleGitCommand = (args: string[]) => {
    const [action] = args;
    
    switch (action) {
      case 'status':
        addToHistory({
          type: 'output',
          content: 'On branch main',
        });
        addToHistory({
          type: 'output',
          content: 'Your branch is up to date with \'origin/main\'.',
        });
        addToHistory({
          type: 'output',
          content: 'Changes not staged for commit:',
        });
        addToHistory({
          type: 'output',
          content: '  modified: src/App.jsx',
        });
        break;
      
      case 'add':
        addToHistory({
          type: 'success',
          content: 'Changes staged for commit',
        });
        break;
      
      case 'commit':
        addToHistory({
          type: 'success',
          content: 'Commit created successfully',
        });
        break;
      
      default:
        addToHistory({
          type: 'error',
          content: `Unknown git command: ${action}`,
        });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'Enter':
        executeCommand(currentCommand);
        break;
      
      case 'ArrowUp':
        e.preventDefault();
        if (commandHistory.length > 0) {
          const newIndex = historyIndex + 1;
          if (newIndex < commandHistory.length) {
            setHistoryIndex(newIndex);
            setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
          }
        }
        break;
      
      case 'ArrowDown':
        e.preventDefault();
        if (historyIndex > 0) {
          const newIndex = historyIndex - 1;
          setHistoryIndex(newIndex);
          setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
        } else if (historyIndex === 0) {
          setHistoryIndex(-1);
          setCurrentCommand('');
        }
        break;
      
      case 'Tab':
        e.preventDefault();
        // Basic tab completion for common commands
        const commonCommands = ['npm', 'git', 'cd', 'ls', 'clear', 'help'];
        const matches = commonCommands.filter(cmd => cmd.startsWith(currentCommand));
        if (matches.length === 1) {
          setCurrentCommand(matches[0] + ' ');
        }
        break;
    }
  };

  const getLineClass = (type: TerminalLine['type']) => {
    switch (type) {
      case 'command':
        return 'text-blue-400';
      case 'error':
        return 'text-red-400';
      case 'success':
        return 'text-green-400';
      default:
        return 'text-slate-300';
    }
  };

  const clearTerminal = () => {
    setHistory([]);
  };

  return (
    <div className="h-full bg-gray-900 text-slate-300 font-mono text-sm flex flex-col">
      {/* Terminal Output */}
      <div ref={terminalRef} className="flex-1 overflow-y-auto p-4 space-y-1">
        <div className="text-slate-400 text-xs mb-2">
          InnoXAI Terminal v1.0.0 - Type 'help' for available commands
        </div>
        
        {history.map(line => (
          <div key={line.id} className={getLineClass(line.type)}>
            {line.type === 'command' && (
              <span className="text-green-400">{currentPath} </span>
            )}
            {line.content}
          </div>
        ))}
        
        {/* Current Input Line */}
        <div className="flex items-center">
          <span className="text-green-400 mr-2">{currentPath} $</span>
          <Input
            ref={inputRef}
            value={currentCommand}
            onChange={(e) => setCurrentCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-none text-slate-300 p-0 focus:ring-0 font-mono"
            placeholder="Type a command..."
          />
          <div className="w-2 h-4 bg-slate-300 ml-1 animate-pulse"></div>
        </div>
      </div>

      {/* Terminal Actions */}
      <div className="border-t border-gray-800 p-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={clearTerminal}
            className="text-slate-400 hover:text-white h-6 text-xs"
          >
            <i className="fas fa-trash mr-1"></i>Clear
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => executeCommand('npm start')}
            className="text-slate-400 hover:text-white h-6 text-xs"
          >
            <i className="fas fa-play mr-1"></i>Start Dev
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => executeCommand('npm install')}
            className="text-slate-400 hover:text-white h-6 text-xs"
          >
            <i className="fas fa-download mr-1"></i>Install
          </Button>
        </div>
        
        <div className="text-xs text-slate-500">
          {installPackageMutation.isPending && (
            <span className="text-yellow-400">
              <i className="fas fa-spinner fa-spin mr-1"></i>
              Installing package...
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
