/**
 * PreviewIframe Component
 * 
 * A controlled iframe component that connects to the InnoXAI sandbox environment with:
 * - Real-time preview updates via WebSocket
 * - Secure cross-origin communication
 * - Error handling and connection monitoring
 * - Auto-refresh capabilities
 */

import { useState, useRef, useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PreviewIframeProps {
  projectId?: string | number;
  className?: string;
  style?: React.CSSProperties;
  onProjectUpdate?: (project: any) => void;
}

export function PreviewIframe({ 
  projectId, 
  className, 
  style, 
  onProjectUpdate 
}: PreviewIframeProps) {
  const { toast } = useToast();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Generate sandbox URL with project parameter
  const sandboxUrl = `http://localhost:5174${projectId ? `?project=${projectId}` : ''}`;

  // Force refresh the iframe
  const forceRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
    setIsLoading(true);
    setConnectionError(null);
  }, []);

  // Handle iframe load events
  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    const handleLoad = () => {
      setIsLoading(false);
      setConnectionError(null);
      setIsConnected(true);
      setLastUpdate(new Date());
      
      console.log('InnoXAI Sandbox loaded successfully');
    };

    const handleError = () => {
      setIsLoading(false);
      setIsConnected(false);
      setConnectionError('Failed to load sandbox environment');
      
      toast({
        title: 'Preview Error',
        description: 'Could not connect to sandbox environment',
        variant: 'destructive'
      });
    };

    // Listen for messages from sandbox
    const handleMessage = (event: MessageEvent) => {
      // Validate origin for security
      const sandboxOrigin = new URL(sandboxUrl).origin;
      if (event.origin !== sandboxOrigin) {
        return;
      }

      // Handle different message types from sandbox
      switch (event.data.type) {
        case 'project-updated':
          setLastUpdate(new Date());
          onProjectUpdate?.(event.data.project);
          break;
          
        case 'error':
          setConnectionError(event.data.message);
          toast({
            title: 'Sandbox Error',
            description: event.data.message,
            variant: 'destructive'
          });
          break;
          
        case 'ready':
          setIsConnected(true);
          console.log('Sandbox environment is ready');
          break;
          
        default:
          // Handle other message types as needed
          break;
      }
    };

    iframe.addEventListener('load', handleLoad);
    iframe.addEventListener('error', handleError);
    window.addEventListener('message', handleMessage);

    return () => {
      iframe.removeEventListener('load', handleLoad);
      iframe.removeEventListener('error', handleError);
      window.removeEventListener('message', handleMessage);
    };
  }, [refreshKey, sandboxUrl, toast, onProjectUpdate]);

  // Send initialization message to sandbox when ready
  useEffect(() => {
    if (isConnected && iframeRef.current && projectId) {
      const message = {
        type: 'init',
        projectId: projectId,
        timestamp: Date.now()
      };
      
      iframeRef.current.contentWindow?.postMessage(
        message,
        new URL(sandboxUrl).origin
      );
    }
  }, [isConnected, projectId, sandboxUrl]);

  // Reset when project changes
  useEffect(() => {
    if (projectId) {
      forceRefresh();
    }
  }, [projectId, forceRefresh]);

  return (
    <div className={cn(
      'relative w-full h-full bg-muted/30 overflow-hidden rounded-lg border',
      className
    )} style={style}>
      
      {/* Loading State */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
          <div className="text-center space-y-3">
            <LoadingSpinner className="mx-auto" />
            <p className="text-sm text-muted-foreground">
              Connecting to InnoXAI Sandbox...
            </p>
          </div>
        </div>
      )}

      {/* Error State */}
      {connectionError && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
          <div className="text-center space-y-4 p-6">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto" />
            <div className="space-y-2">
              <h3 className="font-semibold text-foreground">Connection Failed</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                {connectionError}
              </p>
            </div>
            <Button onClick={forceRefresh} size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry Connection
            </Button>
          </div>
        </div>
      )}

      {/* Main Iframe */}
      <iframe
        key={refreshKey}
        ref={iframeRef}
        src={sandboxUrl}
        className={cn(
          'w-full h-full border-none transition-opacity duration-300',
          isLoading || connectionError ? 'opacity-0' : 'opacity-100'
        )}
        allow="accelerometer; camera; encrypted-media; geolocation; gyroscope; microphone; midi; payment; usb"
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-modals allow-downloads"
        title="InnoXAI Sandbox Preview"
        referrerPolicy="strict-origin-when-cross-origin"
      />

      {/* Connection Status Indicator */}
      <div className="absolute top-3 right-3 z-20">
        <div className={cn(
          'flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium',
          'backdrop-blur-sm border shadow-sm',
          isConnected 
            ? 'bg-green-50 text-green-700 border-green-200' 
            : 'bg-red-50 text-red-700 border-red-200'
        )}>
          {isConnected ? (
            <>
              <Wifi className="w-3 h-3" />
              Connected
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3" />
              Disconnected
            </>
          )}
        </div>
      </div>

      {/* Refresh Button */}
      <div className="absolute bottom-3 right-3 z-20">
        <Button
          size="sm"
          variant="secondary"
          onClick={forceRefresh}
          className="backdrop-blur-sm bg-background/80 border shadow-sm"
        >
          <RefreshCw className="w-4 h-4" />
        </Button>
      </div>

      {/* Last Update Indicator */}
      {lastUpdate && isConnected && (
        <div className="absolute bottom-3 left-3 z-20">
          <div className="px-3 py-1.5 rounded-full text-xs text-muted-foreground bg-background/80 backdrop-blur-sm border shadow-sm">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </div>
        </div>
      )}
    </div>
  );
}