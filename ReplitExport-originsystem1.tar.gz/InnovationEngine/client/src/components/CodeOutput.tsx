import React, { useState, useRef, useEffect } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus, vs } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { 
  Copy, 
  Check, 
  Moon, 
  Sun, 
  Download, 
  Maximize2, 
  Minimize2,
  Eye,
  Code,
  Palette,
  ZoomIn,
  ZoomOut,
  RotateCcw
} from 'lucide-react';
import { Tooltip, TooltipTrigger, TooltipContent } from './ui/tooltip';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { cn } from '@/lib/utils';

interface CodeOutputProps {
  code: string;
  language?: string;
  className?: string;
  showLineNumbers?: boolean;
  wrapLines?: boolean;
  maxHeight?: string;
  theme?: 'dark' | 'light';
  title?: string;
  filename?: string;
  showToolbar?: boolean;
  allowDownload?: boolean;
  allowFullscreen?: boolean;
  interactive?: boolean;
  onLanguageChange?: (language: string) => void;
  onThemeChange?: (theme: 'dark' | 'light') => void;
}

export function CodeOutput({
  code,
  language = 'typescript',
  className,
  showLineNumbers = true,
  wrapLines = false,
  maxHeight = 'none',
  theme: initialTheme = 'dark',
  title,
  filename,
  showToolbar = true,
  allowDownload = true,
  allowFullscreen = true,
  interactive = false,
  onLanguageChange,
  onThemeChange,
}: CodeOutputProps) {
  const [copied, setCopied] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(initialTheme);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [fontSize, setFontSize] = useState(14);
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  const [lineHeight, setLineHeight] = useState(1.6);
  const [wrapLinesState, setWrapLines] = useState(wrapLines);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    onThemeChange?.(newTheme);
  };

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    if (!isFullscreen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  };

  const handleDownload = () => {
    const extension = getFileExtension(selectedLanguage);
    const fileName = filename || `code.${extension}`;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleLanguageChange = (newLanguage: string) => {
    setSelectedLanguage(newLanguage);
    onLanguageChange?.(newLanguage);
  };

  const resetSettings = () => {
    setFontSize(14);
    setLineHeight(1.6);
    setTheme('dark');
    setSelectedLanguage(language);
  };

  const getFileExtension = (lang: string): string => {
    const extensions: Record<string, string> = {
      typescript: 'ts',
      javascript: 'js',
      python: 'py',
      java: 'java',
      cpp: 'cpp',
      csharp: 'cs',
      php: 'php',
      ruby: 'rb',
      go: 'go',
      rust: 'rs',
      html: 'html',
      css: 'css',
      json: 'json',
      yaml: 'yml',
      xml: 'xml',
      sql: 'sql',
    };
    return extensions[lang] || 'txt';
  };

  const getLanguageStats = () => {
    const lines = code.split('\n').length;
    const chars = code.length;
    const words = code.split(/\s+/).filter(word => word.length > 0).length;
    return { lines, chars, words };
  };

  const style = theme === 'dark' ? vscDarkPlus : vs;
  const actualMaxHeight = isExpanded ? 'none' : maxHeight;
  const stats = getLanguageStats();

  // Language options for the selector
  const languageOptions = [
    'typescript', 'javascript', 'python', 'java', 'cpp', 'csharp',
    'php', 'ruby', 'go', 'rust', 'html', 'css', 'json', 'yaml', 'xml', 'sql'
  ];

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        toggleFullscreen();
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isFullscreen]);

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative group rounded-xl overflow-hidden border bg-background shadow-lg transition-all duration-300',
        isFullscreen && 'fixed inset-0 z-50 rounded-none',
        className
      )}
    >
      {/* Enhanced Header with Title and Stats */}
      <div className="flex items-center justify-between px-4 py-3 bg-muted/50 border-b">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Code className="h-4 w-4 text-muted-foreground" />
            <div className="text-sm font-mono text-muted-foreground">
              {title || filename || `${selectedLanguage.toUpperCase()}`}
            </div>
          </div>
          {showToolbar && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                {stats.lines} lines
              </Badge>
              <Badge variant="outline" className="text-xs">
                {stats.chars} chars
              </Badge>
            </div>
          )}
        </div>

        {showToolbar && (
          <div className="flex items-center gap-1">
            {/* Language Selector */}
            {interactive && (
              <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
                <SelectTrigger className="h-7 w-24 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {languageOptions.map((lang) => (
                    <SelectItem key={lang} value={lang} className="text-xs">
                      {lang.toUpperCase()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Font Size Controls */}
            {interactive && (
              <>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                      onClick={() => setFontSize(Math.max(8, fontSize - 2))}
                    >
                      <ZoomOut className="h-3 w-3" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Decrease font size</TooltipContent>
                </Tooltip>

                <span className="text-xs text-muted-foreground px-1 min-w-[2rem] text-center">
                  {fontSize}px
                </span>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                      onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                    >
                      <ZoomIn className="h-3 w-3" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Increase font size</TooltipContent>
                </Tooltip>
              </>
            )}

            {/* Theme Toggle */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                  onClick={toggleTheme}
                >
                  {theme === 'dark' ? (
                    <Sun className="h-4 w-4" />
                  ) : (
                    <Moon className="h-4 w-4" />
                  )}
                  <span className="sr-only">Toggle theme</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Toggle theme</TooltipContent>
            </Tooltip>

            {/* Copy Button */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                  onClick={handleCopy}
                >
                  {copied ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                  <span className="sr-only">Copy code</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {copied ? 'Copied!' : 'Copy to clipboard'}
              </TooltipContent>
            </Tooltip>

            {/* Download Button */}
            {allowDownload && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                    onClick={handleDownload}
                  >
                    <Download className="h-4 w-4" />
                    <span className="sr-only">Download code</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Download as file</TooltipContent>
              </Tooltip>
            )}

            {/* Fullscreen Toggle */}
            {allowFullscreen && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                    onClick={toggleFullscreen}
                  >
                    {isFullscreen ? (
                      <Minimize2 className="h-4 w-4" />
                    ) : (
                      <Maximize2 className="h-4 w-4" />
                    )}
                    <span className="sr-only">Toggle fullscreen</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
                </TooltipContent>
              </Tooltip>
            )}

            {/* Reset Settings */}
            {interactive && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                    onClick={resetSettings}
                  >
                    <RotateCcw className="h-4 w-4" />
                    <span className="sr-only">Reset settings</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Reset to defaults</TooltipContent>
              </Tooltip>
            )}

            {/* Expand/Collapse */}
            {maxHeight !== 'none' && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-muted-foreground hover:text-foreground"
                    onClick={toggleExpand}
                  >
                    <span className="text-xs font-medium">
                      {isExpanded ? 'Collapse' : 'Expand'}
                    </span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {isExpanded ? 'Collapse code' : 'Expand code'}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        )}
      </div>

      {/* Advanced Settings Panel (for interactive mode) */}
      {interactive && showToolbar && (
        <div className="px-4 py-2 bg-muted/30 border-b">
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Line Height:</span>
              <Slider
                value={[lineHeight]}
                onValueChange={([value]) => setLineHeight(value)}
                min={1.2}
                max={2.4}
                step={0.1}
                className="w-16"
              />
              <span className="text-muted-foreground min-w-[2rem]">{lineHeight.toFixed(1)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Word Wrap:</span>
              <Button
                variant={wrapLinesState ? "default" : "outline"}
                size="sm"
                className="h-6 px-2 text-xs"
                onClick={() => setWrapLines(!wrapLinesState)}
              >
                {wrapLinesState ? 'On' : 'Off'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Code Display */}
      <div className={cn(
        "relative",
        isFullscreen && "h-[calc(100vh-120px)] overflow-auto"
      )}>
        <SyntaxHighlighter
          language={selectedLanguage}
          style={style}
          showLineNumbers={showLineNumbers}
          wrapLines={wrapLinesState}
          customStyle={{
            margin: 0,
            fontSize: `${fontSize}px`,
            fontFamily: 'var(--font-mono), Fira Code, monospace',
            lineHeight: lineHeight.toString(),
            padding: '20px',
            background: 'transparent',
            borderRadius: 0,
            maxHeight: isFullscreen ? 'none' : actualMaxHeight,
            overflow: 'auto',
          }}
          lineNumberStyle={{
            minWidth: '3em',
            color: theme === 'dark' ? '#6e7681' : '#999999',
            fontSize: `${Math.max(10, fontSize - 2)}px`,
            paddingRight: '1em',
          }}
          codeTagProps={{
            style: {
              fontFamily: 'var(--font-mono), Fira Code, monospace',
            }
          }}
        >
          {code}
        </SyntaxHighlighter>
      </div>

      {/* Footer with additional info for fullscreen mode */}
      {isFullscreen && (
        <div className="absolute bottom-0 left-0 right-0 px-4 py-2 bg-muted/50 border-t">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-4">
              <span>{stats.lines} lines, {stats.words} words, {stats.chars} characters</span>
              <span>Language: {selectedLanguage.toUpperCase()}</span>
            </div>
            <span>Press ESC to exit fullscreen</span>
          </div>
        </div>
      )}
    </div>
  );
}