import { useState } from 'react';
import { FiFolder, FiFile, FiChevronRight, FiChevronDown, FiPackage } from 'react-icons/fi';

interface FileTreeProps {
  files: Array<{
    id: string;
    name: string;
    path: string;
    content: string;
  }>;
  onFileSelect: (file: any) => void;
  dependencies: string[];
}

export default function FileTree({ files = [], onFileSelect, dependencies = [] }: FileTreeProps) {
  const [expandedFolders, setExpandedFolders] = useState(['src']);

  const toggleFolder = (folder: string) => {
    setExpandedFolders(prev => 
      prev.includes(folder) 
        ? prev.filter(f => f !== folder) 
        : [...prev, folder]
    );
  };

  if (!files || files.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        <FiFolder className="mx-auto mb-2 text-2xl" />
        <p>No files in project</p>
      </div>
    );
  }

  const filesByFolder = files.reduce((acc: Record<string, any[]>, file) => {
    const folder = file.path.split('/')[0];
    if (!acc[folder]) acc[folder] = [];
    acc[folder].push(file);
    return acc;
  }, {});

  return (
    <div className="file-tree">
      {dependencies.length > 0 && (
        <div className="dependency-section">
          <div className="section-header" onClick={() => toggleFolder('node_modules')}>
            <FiPackage />
            <span>Dependencies</span>
            {expandedFolders.includes('node_modules') ? <FiChevronDown /> : <FiChevronRight />}
          </div>
          {expandedFolders.includes('node_modules') && (
            <div className="dependency-list">
              {dependencies.map(dep => (
                <div key={dep} className="dependency-item">
                  <FiFile /> {dep}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      
      {Object.entries(filesByFolder).map(([folder, folderFiles]) => (
        <div key={folder} className="folder-section">
          <div className="section-header" onClick={() => toggleFolder(folder)}>
            <FiFolder />
            <span>{folder}</span>
            {expandedFolders.includes(folder) ? <FiChevronDown /> : <FiChevronRight />}
          </div>
          {expandedFolders.includes(folder) && (
            <div className="file-list">
              {folderFiles.map(file => (
                <div 
                  key={file.id} 
                  className="file-item"
                  onClick={() => onFileSelect(file)}
                >
                  <FiFile /> {file.name}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}