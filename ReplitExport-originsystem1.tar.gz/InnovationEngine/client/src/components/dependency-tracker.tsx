import { useEffect, useState } from 'react';

interface DependencyTrackerProps {
  dependencies: string[];
}

export default function DependencyTracker({ dependencies }: DependencyTrackerProps) {
  const [installedDeps, setInstalledDeps] = useState<string[]>([]);

  useEffect(() => {
    if (dependencies.length === 0) return;

    setInstalledDeps([]); // Reset when new dependencies come in

    const installInterval = setInterval(() => {
      setInstalledDeps(prev => {
        const nextIndex = prev.length;
        const nextDep = dependencies[nextIndex];
        
        if (nextDep && !prev.includes(nextDep)) {
          const newInstalled = [...prev, nextDep];
          
          // Clear interval when all dependencies are installed
          if (newInstalled.length === dependencies.length) {
            clearInterval(installInterval);
          }
          
          return newInstalled;
        }
        
        return prev;
      });
    }, 800);

    return () => clearInterval(installInterval);
  }, [dependencies]);

  if (dependencies.length === 0) {
    return (
      <div className="dependency-tracker">
        <h3>Dependencies</h3>
        <p className="no-deps">No dependencies detected</p>
      </div>
    );
  }

  return (
    <div className="dependency-tracker">
      <h3>Dependencies</h3>
      <ul className="dependency-list">
        {dependencies.map((dep) => (
          <li 
            key={dep} 
            className={installedDeps.includes(dep) ? 'installed' : 'pending'}
          >
            <span className="dep-name">{dep}</span>
            <span className="status">
              {installedDeps.includes(dep) ? '✓' : '⌛'}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}