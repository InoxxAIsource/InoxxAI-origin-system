import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { File } from '@/../../shared/schema';

interface CanvasPreviewProps {
  projectId?: number;
  generatedCode?: string;
  onDependenciesDetected?: (deps: string[]) => void;
}

export default function CanvasPreview({ projectId = 1, generatedCode, onDependenciesDetected }: CanvasPreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [dependencies, setDependencies] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch project files to get the latest code
  const { data: files = [] } = useQuery<File[]>({
    queryKey: [`/api/projects/${projectId}/files`],
    enabled: !!projectId,
  });

  useEffect(() => {
    if (generatedCode) {
      updatePreview(generatedCode);
      extractDependencies(generatedCode);
    } else if (files.length > 0) {
      // Use the project files to generate preview
      const mainFile = files.find((f) => f.path === 'src/App.jsx') || files[0];
      if (mainFile) {
        updatePreview(mainFile.content);
        extractDependencies(mainFile.content);
      }
    }
  }, [generatedCode, files]);

  const updatePreview = (code: string) => {
    setIsLoading(true);
    const iframe = iframeRef.current;
    if (iframe) {
      const html = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Preview</title>
            ${generateStyleTags()}
            ${generateScriptTags(dependencies)}
            <style>
              body {
                margin: 0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
                background: #ffffff;
              }
              * {
                box-sizing: border-box;
              }
            </style>
          </head>
          <body>
            <div id="root"></div>
            <script type="text/babel">
              ${transformCodeForPreview(code)}
            </script>
          </body>
        </html>
      `;
      iframe.srcdoc = html;
      
      // Simulate loading time
      setTimeout(() => setIsLoading(false), 1000);
    }
  };

  const generateStyleTags = () => {
    return `
      <script src="https://cdn.tailwindcss.com"></script>
      <style>
        .canvas-preview-container {
          padding: 1rem;
          min-height: 100vh;
        }
      </style>
    `;
  };

  const generateScriptTags = (deps: string[]) => {
    return `
      <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
      <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
      <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    `;
  };

  const transformCodeForPreview = (code: string) => {
    // Remove import statements and transform for browser execution
    let transformedCode = code
      .replace(/import.*from.*['"`];?\n?/g, '')
      .replace(/export\s+default\s+/g, '');

    // If it's a component, render it
    if (transformedCode.includes('function') || transformedCode.includes('const')) {
      transformedCode += `
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(React.createElement(App || Component));
      `;
    }

    return transformedCode;
  };

  const extractDependencies = (code: string) => {
    const newDeps = detectDependencies(code);
    setDependencies(newDeps);
    onDependenciesDetected?.(newDeps);
    installDependencies(newDeps);
  };

  const detectDependencies = (code: string): string[] => {
    const deps: string[] = [];
    
    // Extract from import statements
    const importMatches = code.match(/import.*from\s+['"`]([^'"`]+)['"`]/g);
    if (importMatches) {
      importMatches.forEach(match => {
        const dep = match.match(/from\s+['"`]([^'"`]+)['"`]/);
        if (dep && dep[1] && !dep[1].startsWith('.') && !dep[1].startsWith('/')) {
          deps.push(dep[1]);
        }
      });
    }

    // Extract from require statements
    const requireMatches = code.match(/require\(['"`]([^'"`]+)['"`]\)/g);
    if (requireMatches) {
      requireMatches.forEach(match => {
        const dep = match.match(/require\(['"`]([^'"`]+)['"`]\)/);
        if (dep && dep[1] && !dep[1].startsWith('.') && !dep[1].startsWith('/')) {
          deps.push(dep[1]);
        }
      });
    }

    return Array.from(new Set(deps)); // Remove duplicates
  };

  const installDependencies = async (deps: string[]) => {
    // In a real implementation, this would trigger actual dependency installation
    console.log('Installing dependencies:', deps);
    
    // Simulate dependency installation
    deps.forEach((dep, index) => {
      setTimeout(() => {
        console.log(`Installed: ${dep}`);
      }, (index + 1) * 500);
    });
  };

  return (
    <div className="canvas-preview">
      <div className="canvas-header">
        <div className="preview-controls">
          <div className="viewport-selector">
            <button className="viewport-btn active">Desktop</button>
            <button className="viewport-btn">Tablet</button>
            <button className="viewport-btn">Mobile</button>
          </div>
          <div className="preview-actions">
            <button className="action-btn">
              <span>🔄</span>
            </button>
            <button className="action-btn">
              <span>📱</span>
            </button>
            <button className="action-btn">
              <span>🔗</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="canvas-content">
        <iframe 
          ref={iframeRef}
          className="canvas-iframe"
          sandbox="allow-scripts allow-same-origin allow-forms"
          title="Code Preview"
        />
        
        {isLoading && (
          <div className="loading-overlay">
            <div className="loading-spinner"></div>
            <p>Rendering preview...</p>
          </div>
        )}
      </div>
      
      <div className="canvas-footer">
        <div className="status-indicator">
          <span className="status-dot"></span>
          <span>Preview Active</span>
        </div>
        <div className="performance-info">
          <span>Load time: 1.2s</span>
        </div>
      </div>
    </div>
  );
}