import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface RobustPreviewProps {
  code?: string;
  isGenerating?: boolean;
  onDependenciesDetected?: (deps: string[]) => void;
}

export default function RobustPreview({ code, isGenerating = false, onDependenciesDetected }: RobustPreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showPlaceholder, setShowPlaceholder] = useState(true);

  const cleanCodeForPreview = (rawCode: string): string => {
    try {
      let cleaned = rawCode;
      
      // Extract frontend code if multi-file structure
      if (cleaned.includes('// Frontend:') || cleaned.includes('// React Component:')) {
        const frontendStart = cleaned.search(/(\/\/ Frontend:|\/\/ React Component:)/);
        if (frontendStart !== -1) {
          cleaned = cleaned.substring(frontendStart);
          // Remove everything after backend markers
          const backendMarkers = ['// Backend:', '// Server:', '// API:', '// Express', '// Node.js'];
          for (const marker of backendMarkers) {
            if (cleaned.includes(marker)) {
              cleaned = cleaned.split(marker)[0];
            }
          }
        }
      } else if (cleaned.includes('// Backend:') || cleaned.includes('// Server:')) {
        // If only backend code, extract until backend marker
        const backendStart = cleaned.search(/(\/\/ Backend:|\/\/ Server:)/);
        if (backendStart > 0) {
          cleaned = cleaned.substring(0, backendStart);
        }
      }
      
      // Extract main React component from multi-file structure
      if (cleaned.includes('// File:') || cleaned.includes('// App.tsx') || cleaned.includes('// src/')) {
        // Look for the main App component file
        const patterns = [
          /\/\/ File: src\/App\.tsx\n([\s\S]*?)(?=\/\/ File:|$)/,
          /\/\/ App\.tsx\n([\s\S]*?)(?=\/\/ |$)/,
          /\/\/ src\/App\.tsx\n([\s\S]*?)(?=\/\/ |$)/
        ];
        
        for (const pattern of patterns) {
          const match = cleaned.match(pattern);
          if (match && match[1]) {
            cleaned = match[1];
            break;
          }
        }
      }
      
      // Remove CSS and style sections that cause parsing errors
      cleaned = cleaned
        .replace(/\/\/ (?:File: )?(?:src\/)?(?:index\.)?css[\s\S]*?(?=\/\/ (?:File:|src\/)|import|const|function|export|$)/g, '')
        .replace(/\/\/ tailwind\.config\.js[\s\S]*?(?=\/\/ (?:File:|src\/)|import|const|function|export|$)/g, '')
        .replace(/body\s*\{[\s\S]*?\}/g, '')
        .replace(/html\s*\{[\s\S]*?\}/g, '')
        .replace(/\*\s*\{[\s\S]*?\}/g, '');
      
      // Extract React component from markdown blocks
      if (cleaned.includes('```')) {
        // Look for the main App component specifically
        const appComponentMatch = cleaned.match(/```(?:tsx?|typescript)\s*\/\/ src\/App\.tsx\s*([\s\S]*?)```/);
        if (appComponentMatch) {
          cleaned = appComponentMatch[1];
        } else {
          // Look for any TypeScript/React component
          const reactMatch = cleaned.match(/```(?:tsx?|typescript)\s*([\s\S]*?)```/);
          if (reactMatch && reactMatch[1].includes('React')) {
            cleaned = reactMatch[1];
          } else {
            // Fallback: remove all markdown and extract first component
            cleaned = cleaned.replace(/```(?:tsx?|jsx?|javascript|typescript|json|css|html|bash)?\s*/g, '').replace(/```/g, '');
          }
        }
      }
      
      // Remove package.json and file comments but keep code
      cleaned = cleaned
        .replace(/\/\/ package\.json[\s\S]*?(?=\/\/ [A-Z]|import|const|function|export|$)/g, '')
        .replace(/^\/\/ File:.*$/gm, '')
        .replace(/^\s*\/\/.*$/gm, '') // Remove comment lines
        .trim();
      
      // Remove TypeScript syntax that breaks Babel
      cleaned = cleaned
        .replace(/import\s+.*?from\s+['"][^'"]*['"];?\s*/g, '')
        .replace(/import\s+['"][^'"]*['"];?\s*/g, '')
        .replace(/:\s*React\.FC<[^>]*>/g, '')
        .replace(/:\s*\{\s*\[\s*key\s*\]\s*\}/g, ': { [key: string]: string }')
        .replace(/:\s*\{\s*\[\s*key:\s*string\s*\]:\s*[^}]*\}/g, '')
        .replace(/type\s+\w+\s*=\s*\{[^}]*\};?\s*/g, '')
        .replace(/interface\s+\w+\s*\{[^}]*\};?\s*/g, '')
        .replace(/:\s*React\.FC/g, '')
        .replace(/:\s*FC<[^>]*>/g, '')
        .replace(/:\s*FC/g, '')
        .replace(/as\s+HTMLElement/g, '')
        .replace(/as\s+\w+/g, '')
        .replace(/:\s*(string|number|boolean|any|void|object|HTMLElement|React\.\w+|HTMLInputElement|HTMLFormElement)/g, '')
        .replace(/interface\s+\w+\s*\{[^}]*\}/g, '')
        .replace(/type\s+\w+\s*=\s*[^;]+;/g, '')
        .replace(/useState<[^>]*>/g, 'useState')
        .replace(/useEffect<[^>]*>/g, 'useEffect')
        .replace(/useRef<[^>]*>/g, 'useRef')
        .replace(/\(([^:)]+):\s*[^)]+\)/g, '($1)')
        .replace(/export\s+default\s+/g, 'window.Component = ')
        .replace(/export\s+/g, 'window.');
      
      // Handle problematic libraries
      cleaned = cleaned
        .replace(/WalletConnectProvider/g, 'null')
        .replace(/Web3Provider/g, 'null')
        .replace(/import.*?Chart.*?from.*?['"`].*?['"`];?\s*/gi, '')
        .replace(/Chart\.register\([^)]*\);?\s*/g, '')
        // Fix Chart.js component imports
        .replace(/import\s*\{[^}]*Line[^}]*\}\s*from\s*['"`]react-chartjs-2['"`];?\s*/gi, '')
        .replace(/import\s*\{[^}]*Bar[^}]*\}\s*from\s*['"`]react-chartjs-2['"`];?\s*/gi, '')
        .replace(/import\s*\{[^}]*Pie[^}]*\}\s*from\s*['"`]react-chartjs-2['"`];?\s*/gi, '')
        .replace(/import\s*['"`]chart\.js\/auto['"`];?\s*/gi, '')
        // Remove React Router imports
        .replace(/import\s*\{[^}]*Router[^}]*\}\s*from\s*['"`]react-router-dom['"`];?\s*/gi, '')
        .replace(/import\s*\{[^}]*Route[^}]*\}\s*from\s*['"`]react-router-dom['"`];?\s*/gi, '')
        .replace(/import\s*\{[^}]*Switch[^}]*\}\s*from\s*['"`]react-router-dom['"`];?\s*/gi, '')
        .replace(/import\s*\{[^}]*Link[^}]*\}\s*from\s*['"`]react-router-dom['"`];?\s*/gi, '')
        // Remove react-icons imports (not available in preview)
        .replace(/import\s*\{[^}]*\}\s*from\s*['"`]react-icons\/\w+['"`];?\s*/gi, '');
      
      // Create Router component replacements for navigation
      if (cleaned.includes('<Router') || cleaned.includes('<Route') || cleaned.includes('<Switch')) {
        const routerComponents = `
          const Router = ({ children }) => React.createElement('div', { className: 'router-container' }, children);
          const Route = ({ path, component: Component, children, ...props }) => {
            return Component ? React.createElement(Component, props) : children || null;
          };
          const Switch = ({ children }) => {
            // Simple switch - just render the first child for preview
            const firstChild = React.Children.toArray(children)[0];
            return firstChild || null;
          };
          const Link = ({ to, children, className, ...props }) => {
            return React.createElement('a', { 
              href: '#', 
              className: className || 'text-blue-600 hover:underline',
              onClick: (e) => e.preventDefault(),
              ...props 
            }, children);
          };
        `;
        cleaned = routerComponents + cleaned;
      }

      // Create Chart.js component replacements
      if (cleaned.includes('<Line') || cleaned.includes('<Bar') || cleaned.includes('<Pie')) {
        // Add chart component definitions at the start
        const chartComponents = `
          const LineChart = ({ data, options = {} }) => {
            const canvasRef = React.useRef();
            React.useEffect(() => {
              if (canvasRef.current && typeof Chart !== 'undefined') {
                Chart.register(Chart.CategoryScale, Chart.LinearScale, Chart.PointElement, Chart.LineElement, Chart.Title, Chart.Tooltip, Chart.Legend);
                const chart = new Chart(canvasRef.current, { type: 'line', data, options });
                return () => chart.destroy();
              }
            }, [data, options]);
            return React.createElement('canvas', { ref: canvasRef, className: 'w-full h-64' });
          };
          
          const BarChart = ({ data, options = {} }) => {
            const canvasRef = React.useRef();
            React.useEffect(() => {
              if (canvasRef.current && typeof Chart !== 'undefined') {
                Chart.register(Chart.CategoryScale, Chart.LinearScale, Chart.BarElement, Chart.Title, Chart.Tooltip, Chart.Legend);
                const chart = new Chart(canvasRef.current, { type: 'bar', data, options });
                return () => chart.destroy();
              }
            }, [data, options]);
            return React.createElement('canvas', { ref: canvasRef, className: 'w-full h-64' });
          };
          
          const PieChart = ({ data, options = {} }) => {
            const canvasRef = React.useRef();
            React.useEffect(() => {
              if (canvasRef.current && typeof Chart !== 'undefined') {
                Chart.register(Chart.ArcElement, Chart.Tooltip, Chart.Legend);
                const chart = new Chart(canvasRef.current, { type: 'pie', data, options });
                return () => chart.destroy();
              }
            }, [data, options]);
            return React.createElement('canvas', { ref: canvasRef, className: 'w-full h-64' });
          };
        `;
        
        // Insert chart components at the beginning
        cleaned = chartComponents + cleaned;
        
        // Replace component usage - handle both self-closing and regular tags
        cleaned = cleaned
          .replace(/<Line(\s+[^>]*)?(\s*\/?>)/g, '<LineChart$1$2')
          .replace(/<Bar(\s+[^>]*)?(\s*\/?>)/g, '<BarChart$1$2')
          .replace(/<Pie(\s+[^>]*)?(\s*\/?>)/g, '<PieChart$1$2')
          // Also handle closing tags
          .replace(/<\/Line>/g, '</LineChart>')
          .replace(/<\/Bar>/g, '</BarChart>')
          .replace(/<\/Pie>/g, '</PieChart>');
      }
      
      // Ensure there's always a valid component
      if (!cleaned.includes('window.Component') && !cleaned.includes('window.App')) {
        // If we have a function or arrow function, wrap it properly
        if (cleaned.includes('const App') || cleaned.includes('function App')) {
          cleaned = cleaned.replace(/const App[^=]*=/, 'window.Component =');
          cleaned = cleaned.replace(/function App/, 'window.Component = function');
        } else {
          // Create a fallback component
          cleaned = `window.Component = () => React.createElement('div', { 
            className: 'p-8 text-center bg-gray-50 rounded-lg' 
          }, 
            React.createElement('h2', { className: 'text-xl font-semibold mb-2' }, 'Generated Content'),
            React.createElement('p', { className: 'text-gray-600' }, 'Your generated component is ready')
          );`;
        }
      }
      
      return cleaned.trim();
    } catch (error) {
      console.error('Code cleaning error:', error);
      return `window.Component = () => React.createElement('div', { 
        className: 'p-4 text-red-500 bg-red-50 rounded border border-red-200' 
      }, 
        React.createElement('h3', { className: 'font-semibold mb-2' }, 'Preview Error'),
        React.createElement('p', { className: 'text-sm' }, 'Unable to process generated code')
      );`;
    }
  };

  useEffect(() => {
    if (!code) return;

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'PREVIEW_READY') {
        setIsLoading(false);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    if (!isGenerating && !isLoading) {
      const timer = setTimeout(() => setShowPlaceholder(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isGenerating, isLoading]);

  useEffect(() => {
    if (!iframeRef.current || !code) return;
    setIsLoading(true);
    setShowPlaceholder(true);

    const cleanedCode = cleanCodeForPreview(code);

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <script src="https://cdn.tailwindcss.com"></script>
          <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
          <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
          <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
          <script src="https://unpkg.com/chart.js@4.4.0/dist/chart.umd.js"></script>
          <style>
            body { 
              margin: 0; 
              font-family: Inter, sans-serif; 
              line-height: 1.6;
            }
            .loading, .error { 
              display: flex; 
              justify-content: center; 
              align-items: center; 
              height: 100vh; 
              padding: 20px;
              text-align: center;
            }
            .error {
              color: #ef4444;
              background: #fef2f2;
              border: 1px solid #fecaca;
              border-radius: 8px;
              margin: 20px;
            }
          </style>
        </head>
        <body>
          <div id="root"></div>
          <script type="text/babel">
            try {
              const { useState, useEffect } = React;
              
              // Set up Chart.js if available
              if (typeof Chart !== 'undefined') {
                Chart.register(
                  Chart.CategoryScale, Chart.LinearScale, Chart.PointElement, 
                  Chart.LineElement, Chart.BarElement, Chart.ArcElement,
                  Chart.Title, Chart.Tooltip, Chart.Legend
                );
              }
              
              ${cleanedCode}
              
              const root = ReactDOM.createRoot(document.getElementById('root'));
              const ComponentToRender = window.Component || window.App || (() => 
                React.createElement('div', { className: 'loading' }, 'Component ready!')
              );
              root.render(React.createElement(ComponentToRender));
              
              // Notify parent when ready
              window.addEventListener('load', () => {
                window.parent.postMessage({ type: 'PREVIEW_READY' }, '*');
              });
              
            } catch (error) {
              console.error('Preview error:', error);
              document.getElementById('root').innerHTML = 
                '<div class="error"><div><h3>Preview Error</h3><p>Check browser console for details</p></div></div>';
            }
          </script>
        </body>
      </html>
    `;

    iframeRef.current.srcdoc = html;
  }, [code]);

  return (
    <div className="relative h-full">
      <AnimatePresence>
        {(isGenerating || showPlaceholder) && (
          <motion.div
            className="absolute inset-0 bg-white z-10 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">
                {isGenerating ? 'Generating preview...' : 'Loading component...'}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <iframe
        ref={iframeRef}
        sandbox="allow-scripts allow-same-origin"
        className="w-full h-full border-0"
        title="Component Preview"
      />
    </div>
  );
}