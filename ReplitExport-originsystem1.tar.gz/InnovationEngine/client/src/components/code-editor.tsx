import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import type { File } from "@shared/schema";

interface CodeEditorProps {
  file: File;
  onChange: (content: string) => void;
  onAIAssistant: () => void;
}

export default function CodeEditor({ file, onChange, onAIAssistant }: CodeEditorProps) {
  const [content, setContent] = useState(file.content);
  const [cursorPosition, setCursorPosition] = useState({ line: 1, column: 1 });
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setContent(file.content);
  }, [file.content]);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    onChange(newContent);
  };

  const handleCursorChange = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const { selectionStart } = textarea;
    const beforeCursor = content.slice(0, selectionStart);
    const lines = beforeCursor.split('\n');
    const line = lines.length;
    const column = lines[lines.length - 1].length + 1;
    
    setCursorPosition({ line, column });
  };

  const formatCode = () => {
    // Basic code formatting - in a real implementation, use prettier or similar
    const formatted = content
      .split('\n')
      .map(line => line.trim())
      .join('\n');
    
    handleContentChange(formatted);
  };

  const insertTemplate = (template: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const { selectionStart, selectionEnd } = textarea;
    const newContent = 
      content.slice(0, selectionStart) + 
      template + 
      content.slice(selectionEnd);
    
    handleContentChange(newContent);
  };

  const renderLineNumbers = () => {
    const lines = content.split('\n');
    return lines.map((_, index) => (
      <div key={index} className="text-right pr-4 text-slate-500 select-none">
        {index + 1}
      </div>
    ));
  };

  const highlightSyntax = (code: string, language: string): string => {
    // Basic syntax highlighting - in a real implementation, use Prism.js or similar
    if (language === 'javascript' || language === 'typescript') {
      return code
        .replace(/\b(import|export|const|let|var|function|class|if|else|for|while|return|try|catch)\b/g, '<span class="syntax-keyword">$1</span>')
        .replace(/'([^']*)'/g, '<span class="syntax-string">\'$1\'</span>')
        .replace(/"([^"]*)"/g, '<span class="syntax-string">"$1"</span>')
        .replace(/\/\/.*$/gm, '<span class="syntax-comment">$&</span>')
        .replace(/\b(\d+)\b/g, '<span class="syntax-number">$1</span>');
    }
    
    if (language === 'css') {
      return code
        .replace(/([a-zA-Z-]+):/g, '<span class="syntax-attribute">$1</span>:')
        .replace(/\/\*[\s\S]*?\*\//g, '<span class="syntax-comment">$&</span>')
        .replace(/\{|\}/g, '<span class="syntax-operator">$&</span>');
    }

    return code;
  };

  const getLanguageTemplates = (language: string) => {
    const templates: Record<string, { name: string; code: string }[]> = {
      javascript: [
        { name: 'React Component', code: 'function Component() {\n  return (\n    <div>\n      \n    </div>\n  );\n}' },
        { name: 'useState Hook', code: 'const [state, setState] = useState();' },
        { name: 'useEffect Hook', code: 'useEffect(() => {\n  \n}, []);' },
        { name: 'Arrow Function', code: 'const fn = () => {\n  \n};' },
      ],
      typescript: [
        { name: 'Interface', code: 'interface Props {\n  \n}' },
        { name: 'Type', code: 'type MyType = {\n  \n};' },
        { name: 'Typed Function', code: 'function fn(param: string): string {\n  return param;\n}' },
      ],
      css: [
        { name: 'Flexbox Container', code: '.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}' },
        { name: 'Grid Layout', code: '.grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));\n  gap: 1rem;\n}' },
      ],
    };

    return templates[language] || [];
  };

  return (
    <div className="h-full bg-editor-bg relative flex">
      {/* Line Numbers */}
      <div className="w-12 bg-gray-900 border-r border-editor-border py-4 text-xs font-mono overflow-hidden">
        {renderLineNumbers()}
      </div>

      {/* Editor Content */}
      <div className="flex-1 relative">
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => handleContentChange(e.target.value)}
          onSelect={handleCursorChange}
          onKeyUp={handleCursorChange}
          onClick={handleCursorChange}
          className="w-full h-full p-4 bg-transparent text-editor-text font-mono text-sm resize-none focus:outline-none"
          style={{
            tabSize: 2,
            fontFamily: 'JetBrains Mono, Fira Code, Monaco, Consolas, monospace',
            lineHeight: '1.5',
          }}
          spellCheck={false}
        />

        {/* Syntax highlighting overlay (simplified) */}
        <div 
          className="absolute inset-0 p-4 font-mono text-sm pointer-events-none whitespace-pre-wrap"
          style={{
            lineHeight: '1.5',
            color: 'transparent',
            fontFamily: 'JetBrains Mono, Fira Code, Monaco, Consolas, monospace',
          }}
          dangerouslySetInnerHTML={{
            __html: highlightSyntax(content, file.language)
          }}
        />
      </div>

      {/* AI Assistant Button */}
      <div className="absolute bottom-4 right-4">
        <Button
          onClick={onAIAssistant}
          className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:shadow-lg transition-shadow"
        >
          <i className="fas fa-robot text-white"></i>
        </Button>
      </div>

      {/* Code Templates Panel */}
      <div className="absolute top-4 right-4 w-64 bg-gray-800 border border-gray-700 rounded-lg shadow-lg p-3 hidden group-hover:block">
        <h4 className="text-sm font-medium text-white mb-2">Code Templates</h4>
        <div className="space-y-1">
          {getLanguageTemplates(file.language).map((template, index) => (
            <button
              key={index}
              onClick={() => insertTemplate(template.code)}
              className="w-full text-left px-2 py-1 text-sm text-slate-300 hover:bg-gray-700 rounded"
            >
              {template.name}
            </button>
          ))}
        </div>
      </div>

      {/* Toolbar */}
      <div className="absolute top-2 right-2 flex items-center space-x-1 bg-gray-800 rounded p-1 opacity-0 hover:opacity-100 transition-opacity">
        <Button
          variant="ghost"
          size="sm"
          onClick={formatCode}
          className="h-6 w-6 p-0 text-slate-400 hover:text-white"
          title="Format Code"
        >
          <i className="fas fa-align-left text-xs"></i>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0 text-slate-400 hover:text-white"
          title="Find & Replace"
        >
          <i className="fas fa-search text-xs"></i>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0 text-slate-400 hover:text-white"
          title="Toggle Minimap"
        >
          <i className="fas fa-map text-xs"></i>
        </Button>
      </div>

      {/* Cursor Position Display */}
      <div className="absolute bottom-2 left-2 text-xs text-slate-500 bg-gray-800 px-2 py-1 rounded">
        Ln {cursorPosition.line}, Col {cursorPosition.column}
      </div>
    </div>
  );
}
