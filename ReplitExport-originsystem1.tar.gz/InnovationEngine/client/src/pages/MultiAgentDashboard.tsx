import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface Job {
  id: string;
  status: 'running' | 'completed' | 'failed';
  prompt: string;
  userId?: string;
  startTime: string;
  endTime?: string;
  result?: any;
  error?: string;
}

interface AuditEntry {
  timestamp: string;
  prompt: string;
  userId?: string;
  status: 'started' | 'completed' | 'failed';
  metrics?: any;
  error?: any;
}

const MultiAgentDashboard = () => {
  const [selectedTab, setSelectedTab] = useState('overview');
  const [promptInput, setPromptInput] = useState('');
  const queryClient = useQueryClient();

  // Fetch active jobs
  const { data: jobsData } = useQuery({
    queryKey: ['/api/v1/self-healing/jobs'],
    refetchInterval: 2000, // Refresh every 2 seconds
  });

  // Fetch audit log
  const { data: auditData } = useQuery({
    queryKey: ['/api/v1/self-healing/audit'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Execute self-healing loop mutation
  const executeLoopMutation = useMutation({
    mutationFn: async (data: { prompt: string; options?: any }) => {
      const response = await fetch('/api/v1/self-healing/autonomous-loop', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: data.prompt,
          userId: 'dashboard-user',
          options: data.options
        })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/v1/self-healing/jobs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/v1/self-healing/audit'] });
      setPromptInput('');
    }
  });

  const jobs: Job[] = (jobsData as any)?.jobs || [];
  const auditEntries: AuditEntry[] = (auditData as any)?.entries || [];

  const handleExecuteLoop = () => {
    if (promptInput.trim()) {
      executeLoopMutation.mutate({
        prompt: promptInput,
        options: { priority: 'medium' }
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-blue-600 bg-blue-100';
      case 'completed': return 'text-green-600 bg-green-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const StatsCard = ({ title, value, subtitle, color }: {
    title: string;
    value: string | number;
    subtitle?: string;
    color?: string;
  }) => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-sm font-medium text-gray-600 mb-2">{title}</h3>
      <div className={`text-3xl font-bold ${color || 'text-gray-900'}`}>{value}</div>
      {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Multi-Agent Control Center</h1>
          <p className="text-gray-600">Monitor and control the self-healing development loop</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Execution Panel */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Execute Self-Healing Loop</h2>
          <div className="flex gap-4">
            <textarea
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder="Enter your development prompt (e.g., 'create a react todo app with authentication')"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
            />
            <button
              onClick={handleExecuteLoop}
              disabled={executeLoopMutation.isPending || !promptInput.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {executeLoopMutation.isPending ? 'Executing...' : 'Execute Loop'}
            </button>
          </div>
          {executeLoopMutation.error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700">Error: {(executeLoopMutation.error as Error).message}</p>
            </div>
          )}
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Active Jobs"
            value={jobs.filter(j => j.status === 'running').length}
            subtitle="Currently executing"
            color="text-blue-600"
          />
          <StatsCard
            title="Completed Today"
            value={jobs.filter(j => j.status === 'completed').length}
            subtitle="Successfully finished"
            color="text-green-600"
          />
          <StatsCard
            title="Failed Jobs"
            value={jobs.filter(j => j.status === 'failed').length}
            subtitle="Require attention"
            color="text-red-600"
          />
          <StatsCard
            title="Total Operations"
            value={auditEntries.length}
            subtitle="All time"
            color="text-purple-600"
          />
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'jobs', label: 'Active Jobs' },
                { id: 'audit', label: 'Audit Log' },
                { id: 'agents', label: 'Agent Status' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    selectedTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {selectedTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">System Status</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-800 mb-2">Agent Pipeline</h4>
                      <div className="space-y-2">
                        {[
                          'Planner Agent',
                          'Code Writer Agent',
                          'Dependency Agent',
                          'DB Schema Agent',
                          'Deployment Agent',
                          'Test Writer Agent',
                          'Test Executor',
                          'Error Resolver Agent'
                        ].map((agent) => (
                          <div key={agent} className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">{agent}</span>
                            <div className="flex items-center">
                              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                              <span className="text-xs text-green-600">Active</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-800 mb-2">Recent Activity</h4>
                      <div className="space-y-2">
                        {auditEntries.slice(0, 5).map((entry, index) => (
                          <div key={index} className="text-sm">
                            <div className="flex items-center justify-between">
                              <span className="text-gray-600 truncate">
                                {entry.prompt.substring(0, 30)}...
                              </span>
                              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(entry.status)}`}>
                                {entry.status}
                              </span>
                            </div>
                            <div className="text-xs text-gray-400">
                              {new Date(entry.timestamp).toLocaleTimeString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {selectedTab === 'jobs' && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Active Jobs</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Job ID</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Status</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Prompt</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Started</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Duration</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {jobs.map((job) => (
                        <tr key={job.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm font-mono text-gray-600">
                            {job.id.substring(0, 12)}...
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(job.status)}`}>
                              {job.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900 max-w-xs truncate">
                            {job.prompt}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {new Date(job.startTime).toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {job.endTime 
                              ? `${Math.round((new Date(job.endTime).getTime() - new Date(job.startTime).getTime()) / 1000)}s`
                              : 'Running...'
                            }
                          </td>
                        </tr>
                      ))}
                      {jobs.length === 0 && (
                        <tr>
                          <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                            No active jobs
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {selectedTab === 'audit' && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Audit Log</h3>
                <div className="space-y-4">
                  {auditEntries.map((entry, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(entry.status)}`}>
                          {entry.status}
                        </span>
                        <span className="text-sm text-gray-500">
                          {new Date(entry.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-900 mb-2">{entry.prompt}</p>
                      {entry.metrics && (
                        <div className="text-xs text-gray-600">
                          Duration: {entry.metrics.duration}ms | 
                          Memory: {Math.round(entry.metrics.memoryDelta?.heapUsed / 1024 / 1024 || 0)}MB
                        </div>
                      )}
                      {entry.error && (
                        <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
                          {entry.error.message || JSON.stringify(entry.error)}
                        </div>
                      )}
                    </div>
                  ))}
                  {auditEntries.length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      No audit entries available
                    </div>
                  )}
                </div>
              </div>
            )}

            {selectedTab === 'agents' && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Agent Status & Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    { name: 'Planner Agent', role: 'Task breakdown and architecture planning', status: 'healthy' },
                    { name: 'Code Writer Agent', role: 'Code generation and implementation', status: 'healthy' },
                    { name: 'Dependency Agent', role: 'Package management and installation', status: 'healthy' },
                    { name: 'DB Schema Agent', role: 'Database schema generation', status: 'healthy' },
                    { name: 'Deployment Agent', role: 'Container and cloud deployment', status: 'healthy' },
                    { name: 'Test Writer Agent', role: 'Test suite generation', status: 'healthy' },
                    { name: 'Test Executor', role: 'Code validation and testing', status: 'healthy' },
                    { name: 'Error Resolver Agent', role: 'Debugging and error resolution', status: 'healthy' }
                  ].map((agent) => (
                    <div key={agent.name} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-800">{agent.name}</h4>
                        <div className="flex items-center">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                          <span className="text-xs text-green-600">Healthy</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">{agent.role}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MultiAgentDashboard;