import { useState, useEffect, useRef } from 'react';
import { FiCode, FiEye, FiSearch, FiMessageSquare, FiFile, FiChevronDown, FiChevronRight } from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import CodeVisualizer from '@/components/CodeVisualizer';
import CanvasPreview from '@/components/CanvasPreview';
import { InteractiveCodeExplorer } from '@/components/InteractiveCodeExplorer';

interface Message {
  id: number;
  text: string;
  isAI: boolean;
  isResult?: boolean;
  isQuestion?: boolean;
  isProgress?: boolean;
  generatedCode?: string;
  framework?: string;
  styling?: string;
  files?: string[];
}

interface GeneratedFile {
  id: string;
  name: string;
  path: string;
  content: string;
}

export default function Generate() {
  const [activeTab, setActiveTab] = useState('preview');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [prompt, setPrompt] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([]);
  const [currentFile, setCurrentFile] = useState<GeneratedFile | null>(null);
  const [dependencies, setDependencies] = useState<string[]>([]);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "I can help you build React components, Next.js applications, create diagrams, write code, and much more.",
      isAI: true
    },
    {
      id: 2,
      text: "What would you like to create today?",
      isAI: true
    }
  ]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Helper function to detect language from filename
  function getLanguageFromFile(filename: string): string {
    const extension = filename.split('.').pop()?.toLowerCase();
    switch(extension) {
      case 'jsx': return 'jsx';
      case 'tsx': return 'tsx';
      case 'js': return 'javascript';
      case 'ts': return 'typescript';
      case 'css': return 'css';
      case 'scss': return 'scss';
      case 'json': return 'json';
      case 'html': return 'html';
      case 'xml': return 'xml';
      case 'md': return 'markdown';
      default: return 'javascript';
    }
  }

  // Enhanced file generation function
  const generateFiles = (prompt: string, generatedCode: string) => {
    const projectName = prompt.toLowerCase().replace(/\s+/g, '-');
    
    const files: GeneratedFile[] = [
      {
        id: 'file1',
        name: 'App.jsx',
        path: 'src/App.jsx',
        content: generatedCode
      },
      {
        id: 'file2',
        name: 'App.css',
        path: 'src/App.css',
        content: `body {
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
}

.app {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

header {
  text-align: center;
  margin-bottom: 3rem;
}

.card {
  background: #f8fafc;
  border-radius: 0.5rem;
  padding: 1.5rem;
  margin-bottom: 1rem;
  border: 1px solid #e2e8f0;
  transition: all 0.2s;
}

.card:hover {
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}`
      },
      {
        id: 'file3',
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify({
          name: projectName,
          version: "1.0.0",
          private: true,
          dependencies: {
            "react": "^18.2.0",
            "react-dom": "^18.2.0",
            "@types/react": "^18.0.25",
            "@types/react-dom": "^18.0.9"
          },
          scripts: {
            "start": "react-scripts start",
            "build": "react-scripts build",
            "test": "react-scripts test",
            "eject": "react-scripts eject"
          }
        }, null, 2)
      }
    ];

    setGeneratedFiles(files);
    setCurrentFile(files[0]);
    
    // Extract dependencies from package.json
    const packageFile = files.find(f => f.name === 'package.json');
    if (packageFile) {
      try {
        const packageData = JSON.parse(packageFile.content);
        setDependencies(Object.keys(packageData.dependencies || {}));
      } catch (e) {
        setDependencies(['react', 'react-dom']);
      }
    }
  };

  // AI code generation mutation
  const generateCodeMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        prompt,
        framework: "react",
        styling: "tailwind"
      });
      return await response.json();
    },
    onSuccess: (data: any) => {
      console.log('AI generation response:', data);
      
      // Extract the generated code from the API response
      let cleanCode = data.generatedCode || data.code || '';
      console.log('Raw code length:', cleanCode.length);
      console.log('Raw code sample:', cleanCode.substring(0, 500));
      
      // Extract React components from multi-file structure
      if (cleanCode.includes('// src/') || cleanCode.includes('// App.tsx') || cleanCode.includes('// components/')) {
        // Find all React component files in the generated code
        const allComponents = [];
        const componentRegex = /\/\/ (?:src\/)?(?:components\/)?([A-Za-z]+\.tsx|App\.tsx)\s*([\s\S]*?)(?=\/\/ |$)/g;
        let match;
        
        while ((match = componentRegex.exec(cleanCode)) !== null) {
          const fileName = match[1];
          const componentCode = match[2].trim();
          if (componentCode && componentCode.includes('React') && !componentCode.includes('<!DOCTYPE')) {
            allComponents.push({
              name: fileName,
              code: componentCode
            });
          }
        }
        
        if (allComponents.length > 0) {
          // Combine all components, putting App last so other components are defined first
          const appComponent = allComponents.find(c => c.name === 'App.tsx');
          const otherComponents = allComponents.filter(c => c.name !== 'App.tsx');
          
          let combinedCode = '';
          
          // Add other components first, but skip index.tsx
          otherComponents.forEach(component => {
            if (!component.name.includes('index.tsx')) {
              combinedCode += component.code + '\n\n';
            }
          });
          
          // Add App component last
          if (appComponent) {
            combinedCode += appComponent.code;
          }
          
          // Clean up TypeScript syntax very carefully - minimal changes only
          combinedCode = combinedCode
            // Remove only complete interface definitions on their own lines
            .replace(/^interface\s+\w+\s*\{[\s\S]*?\}\s*$/gm, '')
            // Remove import statements
            .replace(/^import[\s\S]*?from\s+['"][^'"]*['"];?\s*$/gm, '')
            // Fix React component type annotations - be very specific
            .replace(/:\s*React\.FC<[^>]*>/g, '')
            .replace(/:\s*React\.FC(?![a-zA-Z])/g, '')
            // Fix useState/useEffect generics only
            .replace(/useState<[^>]+>/g, 'useState')
            .replace(/useEffect<[^>]+>/g, 'useEffect');
          
          cleanCode = combinedCode.trim();
        } else {
          // Fallback: extract just the App component
          const appMatch = cleanCode.match(/\/\/ src\/App\.tsx\s*([\s\S]*?)(?=\/\/ src\/|\/\/ public\/|$)/);
          if (appMatch) {
            cleanCode = appMatch[1];
          }
        }
      } else if (cleanCode.includes('```tsx')) {
        // Extract from markdown blocks
        const tsxMatch = cleanCode.match(/```tsx\s*([\s\S]*?)```/);
        if (tsxMatch) {
          cleanCode = tsxMatch[1];
        }
      } else {
        // Clean up markdown and extract any component, filtering out non-React files
        cleanCode = cleanCode
          .replace(/```(?:typescript|tsx|jsx|javascript)\n?/g, '')
          .replace(/```(?:bash|json|shell)\n?/g, '')
          .replace(/```\n?/g, '')
          // Remove all non-React files and setup instructions
          .replace(/\/\/ index\.html[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ index\.js[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ package\.json[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ tailwind\.config\.js[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ src\/index\.tsx[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ src\/index\.css[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/\/\/ public\/index\.html[\s\S]*?(?=\/\/ |$)/g, '')
          .replace(/### Additional Steps[\s\S]*$/, '')
          // Remove bash commands and setup instructions
          .replace(/^bash\s*$/gm, '')
          .replace(/^mkdir\s+.*$/gm, '')
          .replace(/^cd\s+.*$/gm, '')
          .replace(/^npm\s+.*$/gm, '')
          .replace(/^npx\s+.*$/gm, '')
          .replace(/^json\s*$/gm, '')
          .replace(/\/\/ First.*?(?=\/\/ [A-Z]|\w+\s*=|const|function|class|export|import|$)/s, '')
          .replace(/\/\/ Update.*?(?=\/\/ [A-Z]|\w+\s*=|const|function|class|export|import|$)/s, '')
          // Remove problematic comments that break syntax
          .replace(/\(Optional.*?\)/g, '')
          .replace(/\/\/ Install.*$/gm, '')
          .replace(/\/\/ Run:.*$/gm, '')
          .replace(/\/\/ Navigate.*$/gm, '')
          // Clean up any remaining setup instruction patterns
          .replace(/module\.exports\s*=\s*\{[\s\S]*?\};?/g, '')
          .replace(/@tailwind\s+\w+;?/g, '')
          .trim();
      }
      
      // Detect if this is a modification request that should preserve existing content
      const isModificationRequest = prompt.toLowerCase().includes('add') && 
                                   (prompt.toLowerCase().includes('to this') || 
                                    prompt.toLowerCase().includes('to the page'));
      
      // Smart preservation logic: keep existing working code when new response doesn't enhance it
      const hasWorkingCode = generatedCode && generatedCode.length > 500;
      const newCodeIsMinimal = cleanCode.length < 1500;
      const newCodeIsGeneric = cleanCode.includes('Welcome to Our Website') || 
                              cleanCode.includes('Learn More') ||
                              cleanCode.includes('Some content for');
      const containsSetupInstructions = cleanCode.includes('mkdir') || cleanCode.includes('npm ') || 
                                       cleanCode.includes('bash') || cleanCode.includes('npx ') || 
                                       cleanCode.includes('cd ');
      
      // If it's a modification request but the new code is generic/minimal, preserve existing
      if ((!cleanCode.includes('const') && !cleanCode.includes('function') && !cleanCode.includes('export')) || 
          containsSetupInstructions || 
          (isModificationRequest && hasWorkingCode && (newCodeIsMinimal || newCodeIsGeneric))) {
        console.log('Preserving previous working code - modification request resulted in generic content');
        if (generatedCode) {
          cleanCode = generatedCode;
        }
      }
      
      console.log('Cleaned code length:', cleanCode.length);
      console.log('Setting generated code and updating messages...');
      
      // Write the cleaned code to sandbox filesystem for proper Vite compilation
      fetch('/api/sandbox/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: cleanCode,
          filename: 'App.tsx'
        })
      })
      .then(() => console.log('Code written to sandbox filesystem'))
      .catch(writeError => console.error('Failed to write to sandbox:', writeError));
      
      setGeneratedCode(cleanCode);
      setIsGenerating(false);
      setProgress(100);
      
      // Store the prompt for file generation
      const submittedPrompt = prompt || 'component';
      
      // Generate multiple files from the code
      generateFiles(submittedPrompt, cleanCode);
      
      // Add AI response message with file information
      setMessages(prev => {
        const filteredMessages = prev.filter(msg => !msg.isProgress);
        const newMessage = {
          id: Date.now() + 2,
          text: `I've created your component with all the essential features you need.`,
          isAI: true,
          isResult: true,
          generatedCode: cleanCode,
          framework: "react",
          styling: "tailwind",
          files: ['App.jsx', 'App.css', 'package.json']
        };
        console.log('Adding new message:', newMessage);
        return [...filteredMessages, newMessage];
      });
    },
    onError: (error: any) => {
      console.error('Generation error:', error);
      setIsGenerating(false);
      setProgress(0);
      
      setMessages(prev => [...prev, {
        id: Date.now() + 2,
        text: "Sorry, I encountered an error generating your code. Please try again.",
        isAI: true
      }]);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;
    
    const userPrompt = prompt.trim();
    console.log('Submitting prompt:', userPrompt);
    
    // Add user message
    setMessages(prev => [...prev, {
      id: Date.now(),
      text: userPrompt,
      isAI: false
    }]);
    
    // Start generation
    setIsGenerating(true);
    setProgress(0);
    
    // Add thinking message
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: "Generating your code...",
        isAI: true,
        isProgress: true
      }]);
    }, 500);
    
    // Call AI generation
    generateCodeMutation.mutate(userPrompt);
    
    setPrompt('');
  };

  // Simulate progress during generation
  useEffect(() => {
    if (isGenerating) {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) return prev;
          return prev + Math.random() * 5;
        });
      }, 200);
      
      return () => clearInterval(interval);
    }
  }, [isGenerating]);

  return (
    <div className="generate-container">
      {/* File tree sidebar */}
      {generatedFiles.length > 0 && (
        <div className="file-tree-sidebar">
          <div className="file-tree">
            <div className="section-header">
              <FiChevronDown />
              Project Files
            </div>
            <div className="file-list">
              {generatedFiles.map((file) => (
                <div
                  key={file.id}
                  className={`file-item ${currentFile?.id === file.id ? 'active' : ''}`}
                  onClick={() => setCurrentFile(file)}
                >
                  <FiFile />
                  {file.name}
                </div>
              ))}
            </div>
            
            {dependencies.length > 0 && (
              <div className="dependency-section">
                <div className="section-header">
                  <FiChevronDown />
                  Dependencies
                </div>
                <div className="dependency-list">
                  {dependencies.map((dep) => (
                    <div key={dep} className="dependency-item">
                      📦 {dep}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Chat sidebar */}
      <div className="chat-sidebar">
        <div className="chat-header">
          <h3>General chat</h3>
          <span>InnoXAI</span>
        </div>
        
        <div className="chat-messages">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`message ${message.isAI ? 'ai' : 'user'} ${message.isQuestion ? 'question' : ''}`}
            >
              {message.text}
              
              {message.isResult && (
                <div className="result-files">
                  <div className="files-created">
                    {message.files?.map(file => (
                      <div key={file} className="file-badge">
                        <FiFile /> {file}
                      </div>
                    ))}
                  </div>
                  <div className="result-actions">
                    <button onClick={() => setActiveTab('preview')}>
                      <FiEye /> Preview
                    </button>
                    <button onClick={() => setActiveTab('code')}>
                      <FiCode /> Code
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
          
          <AnimatePresence>
            {isGenerating && (
              <motion.div
                className="generation-progress"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="progress-bar" style={{ width: `${progress}%` }} />
                <span>Generating... {Math.round(progress)}%</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <form onSubmit={handleSubmit} className="chat-input">
          <input
            ref={inputRef}
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="What would you like to create?"
            disabled={isGenerating}
          />
          <button type="submit" disabled={isGenerating || !prompt.trim()}>
            <FiMessageSquare />
          </button>
        </form>
      </div>
      
      {/* Main content area */}
      <div className="content-area">
        <div className="tabs">
          <button
            className={activeTab === 'code' ? 'active' : ''}
            onClick={() => setActiveTab('code')}
          >
            <FiCode /> Code
          </button>
          <button
            className={activeTab === 'preview' ? 'active' : ''}
            onClick={() => setActiveTab('preview')}
          >
            <FiEye /> Preview
          </button>
          <button
            className={activeTab === 'explore' ? 'active' : ''}
            onClick={() => setActiveTab('explore')}
          >
            <FiSearch /> Explore
          </button>
        </div>
        
        <div className="tab-content">
          {activeTab === 'code' ? (
            <div className="code-editor">
              {currentFile ? (
                <>
                  <div className="file-header">
                    <FiFile /> {currentFile.path}
                    <div className="language-tag">
                      {currentFile.name.split('.').pop()}
                    </div>
                  </div>
                  <CodeVisualizer 
                    code={currentFile.content} 
                    language={getLanguageFromFile(currentFile.name)}
                    speed={5}
                  />
                </>
              ) : (
                <div className="empty-state">
                  <p>No file selected or generated yet</p>
                </div>
              )}
            </div>
          ) : activeTab === 'preview' ? (
            <div className="preview-container">
              <CanvasPreview code={currentFile?.content || generatedCode} />
            </div>
          ) : activeTab === 'explore' ? (
            <div className="explore-container">
              {currentFile ? (
                <InteractiveCodeExplorer 
                  code={currentFile.content}
                  language={getLanguageFromFile(currentFile.name)}
                  onElementSelect={(element) => {
                    console.log('Selected element:', element);
                  }}
                />
              ) : generatedCode ? (
                <InteractiveCodeExplorer 
                  code={generatedCode}
                  language="typescript"
                  onElementSelect={(element) => {
                    console.log('Selected element:', element);
                  }}
                />
              ) : (
                <div className="empty-state">
                  <p>Generate some code first to explore it interactively</p>
                </div>
              )}
            </div>
          ) : null}
        </div>
        
        <div className="search-box">
          <FiSearch />
          <input type="text" placeholder="Ask a follow up..." />
        </div>
      </div>
    </div>
  );
}