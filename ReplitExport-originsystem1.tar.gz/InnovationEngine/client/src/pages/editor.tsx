import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams } from "wouter";
import { io, Socket } from "socket.io-client";
import FileTree from "@/components/file-tree";
import CodeEditor from "@/components/code-editor";
import LivePreview from "@/components/live-preview";
import Terminal from "@/components/terminal";
import AIAssistant from "@/components/ai-assistant";
import StatusBar from "@/components/status-bar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { apiRequest } from "@/lib/queryClient";
import type { Project, File } from "@shared/schema";

export default function Editor() {
  const { id } = useParams<{ id: string }>();
  const projectId = id ? parseInt(id) : 1; // Default to project 1
  const queryClient = useQueryClient();
  
  const [socket, setSocket] = useState<Socket | null>(null);
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [openFiles, setOpenFiles] = useState<number[]>([]);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
  const [bottomPanelHeight, setBottomPanelHeight] = useState(200);
  const [showBottomPanel, setShowBottomPanel] = useState(true);

  // Initialize WebSocket connection
  useEffect(() => {
    const newSocket = io(window.location.origin);
    setSocket(newSocket);

    newSocket.emit("joinProject", projectId);

    newSocket.on("fileCreated", (file: File) => {
      queryClient.setQueryData([`/api/projects/${projectId}/files`], (oldFiles: File[] = []) => [
        ...oldFiles,
        file,
      ]);
    });

    newSocket.on("fileUpdated", (file: File) => {
      queryClient.setQueryData([`/api/projects/${projectId}/files`], (oldFiles: File[] = []) =>
        oldFiles.map(f => f.id === file.id ? file : f)
      );
    });

    newSocket.on("fileDeleted", ({ id }: { id: number }) => {
      queryClient.setQueryData([`/api/projects/${projectId}/files`], (oldFiles: File[] = []) =>
        oldFiles.filter(f => f.id !== id)
      );
      setOpenFiles(prev => prev.filter(fileId => fileId !== id));
      if (activeFileId === id) {
        setActiveFileId(openFiles.find(fId => fId !== id) || null);
      }
    });

    return () => {
      newSocket.emit("leaveProject", projectId);
      newSocket.disconnect();
    };
  }, [projectId, queryClient, activeFileId, openFiles]);

  // Fetch project data
  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}`],
    enabled: !!projectId,
  });

  // Fetch project files
  const { data: files = [], isLoading: filesLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/files`],
    enabled: !!projectId,
  });

  // Get active file
  const activeFile = files.find(f => f.id === activeFileId);

  // Update file mutation
  const updateFileMutation = useMutation({
    mutationFn: async ({ id, content }: { id: number; content: string }) => {
      return apiRequest("PUT", `/api/files/${id}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/files`] });
    },
  });

  // Create file mutation
  const createFileMutation = useMutation({
    mutationFn: async (fileData: { path: string; content: string; language: string }) => {
      return apiRequest("POST", "/api/files", {
        ...fileData,
        projectId,
        isOpen: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/files`] });
    },
  });

  const handleFileSelect = (fileId: number) => {
    setActiveFileId(fileId);
    if (!openFiles.includes(fileId)) {
      setOpenFiles(prev => [...prev, fileId]);
    }
  };

  const handleFileClose = (fileId: number) => {
    setOpenFiles(prev => prev.filter(id => id !== fileId));
    if (activeFileId === fileId) {
      const remainingFiles = openFiles.filter(id => id !== fileId);
      setActiveFileId(remainingFiles[remainingFiles.length - 1] || null);
    }
  };

  const handleFileContentChange = (content: string) => {
    if (activeFileId) {
      updateFileMutation.mutate({ id: activeFileId, content });
      
      // Emit real-time change
      socket?.emit("codeChange", {
        projectId,
        fileId: activeFileId,
        content,
      });
    }
  };

  const handleCreateFile = (path: string) => {
    const language = getLanguageFromPath(path);
    const content = getDefaultContent(language);
    
    createFileMutation.mutate({
      path,
      content,
      language,
    });
  };

  const getLanguageFromPath = (path: string): string => {
    const ext = path.split('.').pop()?.toLowerCase();
    const languageMap: Record<string, string> = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'css': 'css',
      'scss': 'scss',
      'html': 'html',
      'json': 'json',
      'md': 'markdown',
    };
    return languageMap[ext || ''] || 'plaintext';
  };

  const getDefaultContent = (language: string): string => {
    const templates: Record<string, string> = {
      'javascript': '// New JavaScript file\n\nexport default function Component() {\n  return (\n    <div>\n      <h1>Hello World</h1>\n    </div>\n  );\n}',
      'typescript': '// New TypeScript file\n\ninterface Props {\n  title: string;\n}\n\nexport default function Component({ title }: Props) {\n  return (\n    <div>\n      <h1>{title}</h1>\n    </div>\n  );\n}',
      'css': '/* New CSS file */\n\n.container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 1rem;\n}',
      'html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Document</title>\n</head>\n<body>\n  <h1>Hello World</h1>\n</body>\n</html>',
      'json': '{\n  "name": "new-file",\n  "version": "1.0.0"\n}',
    };
    return templates[language] || '// New file\n';
  };

  if (projectLoading || filesLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading InnoXAI...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-editor-bg text-editor-text">
      {/* Header */}
      <header className="h-12 bg-editor-panel border-b border-editor-border flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <i className="fas fa-code text-white text-sm"></i>
            </div>
            <span className="text-lg font-semibold text-white">InnoXAI</span>
            <span className="text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded">BETA</span>
          </div>
          
          <nav className="hidden md:flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
              <i className="fas fa-folder-open mr-2"></i>Open
            </Button>
            <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
              <i className="fas fa-plus mr-2"></i>New Project
            </Button>
            <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
              <i className="fas fa-rocket mr-2"></i>Deploy
            </Button>
          </nav>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <i className="fas fa-users"></i>
          </Button>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <i className="fas fa-cog"></i>
          </Button>
          <div className="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center cursor-pointer">
            <span className="text-xs font-medium text-white">JD</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          {/* Sidebar */}
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
            <FileTree
              files={files}
              onFileSelect={handleFileSelect}
              onCreateFile={handleCreateFile}
              activeFileId={activeFileId}
              projectId={projectId}
            />
          </ResizablePanel>

          <ResizableHandle />

          {/* Editor Area */}
          <ResizablePanel defaultSize={50} minSize={30}>
            <div className="h-full flex flex-col">
              {/* Tab Bar */}
              <div className="h-10 bg-editor-panel border-b border-editor-border flex items-center">
                <div className="flex overflow-x-auto">
                  {openFiles.map(fileId => {
                    const file = files.find(f => f.id === fileId);
                    if (!file) return null;
                    
                    return (
                      <div
                        key={fileId}
                        className={`flex items-center px-4 py-2 border-r border-editor-border cursor-pointer group ${
                          activeFileId === fileId ? 'bg-editor-bg text-white' : 'text-slate-300 hover:bg-editor-border'
                        }`}
                        onClick={() => setActiveFileId(fileId)}
                      >
                        <i className={`${getFileIcon(file.path)} mr-2 text-sm`}></i>
                        <span className="text-sm truncate">{file.path.split('/').pop()}</span>
                        <button
                          className="ml-2 p-1 opacity-0 group-hover:opacity-100 hover:bg-editor-border rounded"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleFileClose(fileId);
                          }}
                        >
                          <i className="fas fa-times text-xs"></i>
                        </button>
                      </div>
                    );
                  })}
                </div>
                
                <div className="ml-auto flex items-center space-x-1 px-4">
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <i className="fas fa-play text-green-400"></i>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <i className="fas fa-bug"></i>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <i className="fas fa-share-alt"></i>
                  </Button>
                </div>
              </div>

              {/* Code Editor */}
              <div className="flex-1 relative">
                {activeFile ? (
                  <CodeEditor
                    file={activeFile}
                    onChange={handleFileContentChange}
                    onAIAssistant={() => setIsAIAssistantOpen(true)}
                  />
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center text-slate-400">
                      <i className="fas fa-file-code text-4xl mb-4"></i>
                      <p>Select a file to start editing</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle />

          {/* Preview Panel */}
          <ResizablePanel defaultSize={30} minSize={25}>
            <LivePreview projectId={projectId} />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* Bottom Panel */}
      {showBottomPanel && (
        <div className="border-t border-editor-border" style={{ height: bottomPanelHeight }}>
          <Tabs defaultValue="terminal" className="h-full flex flex-col">
            <TabsList className="bg-editor-panel border-b border-editor-border rounded-none justify-start h-10">
              <TabsTrigger value="terminal" className="data-[state=active]:bg-editor-bg">
                <i className="fas fa-terminal mr-2"></i>Terminal
              </TabsTrigger>
              <TabsTrigger value="console" className="data-[state=active]:bg-editor-bg">
                <i className="fas fa-bug mr-2"></i>Console
              </TabsTrigger>
              <TabsTrigger value="problems" className="data-[state=active]:bg-editor-bg">
                <i className="fas fa-exclamation-triangle mr-2"></i>Problems
                <span className="ml-1 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">2</span>
              </TabsTrigger>
              <div className="ml-auto flex items-center px-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowBottomPanel(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <i className="fas fa-times"></i>
                </Button>
              </div>
            </TabsList>
            
            <TabsContent value="terminal" className="flex-1 m-0">
              <Terminal projectId={projectId} />
            </TabsContent>
            
            <TabsContent value="console" className="flex-1 m-0 p-4">
              <div className="font-mono text-sm text-slate-400">
                <div>Console output will appear here...</div>
              </div>
            </TabsContent>
            
            <TabsContent value="problems" className="flex-1 m-0 p-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-red-400">
                  <i className="fas fa-times-circle"></i>
                  <span className="text-sm">Unexpected token ';' at line 15:23</span>
                </div>
                <div className="flex items-center space-x-2 text-yellow-400">
                  <i className="fas fa-exclamation-triangle"></i>
                  <span className="text-sm">Unused variable 'data' at line 8:12</span>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}

      {/* Status Bar */}
      <StatusBar 
        project={project}
        activeFile={activeFile}
        showBottomPanel={showBottomPanel}
        onToggleBottomPanel={() => setShowBottomPanel(!showBottomPanel)}
      />

      {/* AI Assistant Modal */}
      {isAIAssistantOpen && (
        <AIAssistant
          isOpen={isAIAssistantOpen}
          onClose={() => setIsAIAssistantOpen(false)}
          projectId={projectId}
        />
      )}
    </div>
  );
}

function getFileIcon(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase();
  const iconMap: Record<string, string> = {
    'js': 'fab fa-js-square file-icon-js',
    'jsx': 'fab fa-react file-icon-react',
    'ts': 'fas fa-code file-icon-typescript',
    'tsx': 'fab fa-react file-icon-react',
    'css': 'fab fa-css3-alt file-icon-css',
    'scss': 'fab fa-sass file-icon-css',
    'html': 'fab fa-html5 file-icon-html',
    'json': 'fas fa-cube file-icon-json',
    'md': 'fab fa-markdown',
  };
  return iconMap[ext || ''] || 'fas fa-file-alt';
}
