import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Code, 
  Zap, 
  Users, 
  Network, 
  Activity, 
  Shield,
  FileText,
  BarChart3,
  Monitor
} from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  const handleChatStart = () => {
    setLocation('/generate');
  };

  const navigateToDemo = (path: string) => {
    setLocation(path);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20">
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center space-y-6 mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl font-bold mb-4">
              InnoXAI Development Platform
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Next-generation web development with AI-powered multi-agent collaboration, 
              real-time collaboration, and enterprise-grade infrastructure.
            </p>
          </motion.div>
          
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Button 
              size="lg" 
              onClick={handleChatStart}
              className="text-lg px-8 py-6"
            >
              <Code className="mr-2 h-5 w-5" />
              Start Building
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => navigateToDemo('/editor')}
              className="text-lg px-8 py-6"
            >
              <Monitor className="mr-2 h-5 w-5" />
              Open Editor
            </Button>
          </motion.div>
        </div>

        {/* Feature Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <Card className="relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Activity className="h-8 w-8 text-blue-500" />
                <Badge variant="secondary">Live</Badge>
              </div>
              <CardTitle className="text-lg">Real-time Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Instant file synchronization and live preview updates with sub-second latency
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Users className="h-8 w-8 text-green-500" />
                <Badge variant="secondary">Multi-User</Badge>
              </div>
              <CardTitle className="text-lg">Collaboration</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Real-time collaborative editing with cursor tracking and conflict resolution
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Zap className="h-8 w-8 text-yellow-500" />
                <Badge variant="secondary">Optimized</Badge>
              </div>
              <CardTitle className="text-lg">Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Advanced metrics monitoring with intelligent caching and compression
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Shield className="h-8 w-8 text-purple-500" />
                <Badge variant="secondary">Enterprise</Badge>
              </div>
              <CardTitle className="text-lg">Reliability</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Enterprise-grade error recovery with automatic reconnection and message queuing
              </CardDescription>
            </CardContent>
          </Card>
        </motion.div>

        {/* Platform Highlights */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <Card className="p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center space-x-2 text-2xl">
                <Network className="h-6 w-6" />
                <span>Enhanced Socket System</span>
              </CardTitle>
              <CardDescription className="text-base">
                Advanced WebSocket infrastructure with comprehensive monitoring and collaboration features
              </CardDescription>
            </CardHeader>
            <CardContent className="px-0 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Core Features</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Smart reconnection with backoff</li>
                    <li>• Message queuing for offline support</li>
                    <li>• Real-time latency monitoring</li>
                    <li>• Binary event compression</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Advanced Capabilities</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Multi-user collaboration</li>
                    <li>• File system integration</li>
                    <li>• Performance analytics</li>
                    <li>• Error recovery mechanisms</li>
                  </ul>
                </div>
              </div>
              <Button 
                onClick={() => navigateToDemo('/editor')}
                className="w-full"
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                Open Live Editor
              </Button>
            </CardContent>
          </Card>

          <Card className="p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center space-x-2 text-2xl">
                <FileText className="h-6 w-6" />
                <span>Multi-Agent Architecture</span>
              </CardTitle>
              <CardDescription className="text-base">
                Specialized AI agents working together for comprehensive development workflows
              </CardDescription>
            </CardHeader>
            <CardContent className="px-0 space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
                  <span className="text-sm font-medium">Code Writer Agent</span>
                  <Badge variant="outline">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
                  <span className="text-sm font-medium">Test Writer Agent</span>
                  <Badge variant="outline">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
                  <span className="text-sm font-medium">Deployment Agent</span>
                  <Badge variant="outline">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
                  <span className="text-sm font-medium">Error Resolver Agent</span>
                  <Badge variant="outline">Active</Badge>
                </div>
              </div>
              <Button 
                onClick={() => navigateToDemo('/generate')}
                className="w-full"
              >
                <Code className="mr-2 h-4 w-4" />
                Start AI Generation
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Start Examples */}
        <motion.div
          className="text-center space-y-6"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
        >
          <h2 className="text-3xl font-bold">Quick Start Examples</h2>
          <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
            {[
              "Multi-agent dashboard with real-time metrics",
              "E-commerce platform with live collaboration",
              "React application with WebSocket integration",
              "Full-stack platform with AI assistance",
              "Real-time collaboration workspace"
            ].map((example, index) => (
              <motion.button
                key={index}
                onClick={handleChatStart}
                className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-full text-sm transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                "{example}"
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}