import { useEffect, useRef, useCallback, useState, useMemo } from "react";
import { Socket, io } from "socket.io-client";
import { logger } from "../utils/logger";

export type BuildStatus = {
  status: "started" | "completed" | "failed" | "cancelled";
  success?: boolean;
  warnings?: string[];
  errors?: string[];
  timestamp?: string;
  buildTime?: number;
  progress?: number;
  stage?: string;
  buildId?: string;
  artifacts?: string[];
  memoryUsage?: number;
  cpuUsage?: number;
};

export type PreviewError = {
  message: string;
  stack?: string;
  code?: string;
  timestamp: string;
  severity?: "error" | "warning" | "info" | "debug";
  source?: string;
  line?: number;
  column?: number;
  file?: string;
  category?: "compile" | "runtime" | "network" | "security";
};

export type ConnectionState = "disconnected" | "connecting" | "connected" | "reconnecting" | "error" | "authenticating";

export type SocketMetrics = {
  connectionAttempts: number;
  lastConnectedAt?: Date;
  lastDisconnectedAt?: Date;
  totalReconnects: number;
  averageLatency?: number;
  maxLatency?: number;
  minLatency?: number;
  totalMessages: number;
  totalErrors: number;
  uptime?: number;
  bytesReceived?: number;
  bytesSent?: number;
};

export type CollaborationEvent = {
  type: "cursor" | "selection" | "edit" | "join" | "leave";
  userId: string;
  userName?: string;
  data: any;
  timestamp: string;
};

export type FileWatchEvent = {
  type: "created" | "modified" | "deleted" | "renamed";
  path: string;
  oldPath?: string;
  size?: number;
  timestamp: string;
  checksum?: string;
};

export interface PreviewSocketOptions {
  url?: string;
  autoConnect?: boolean;
  reconnect?: boolean;
  reconnectAttempts?: number;
  reconnectDelay?: number;
  timeout?: number;
  maxReconnectDelay?: number;
  heartbeatInterval?: number;
  enableMetrics?: boolean;
  enableCompression?: boolean;
  enableCollaboration?: boolean;
  enableFileWatching?: boolean;
  namespace?: string;
  auth?: Record<string, any>;
  userId?: string;
  userName?: string;
  projectId?: string;
  
  // Advanced options
  maxMessageQueue?: number;
  enableBinaryEvents?: boolean;
  enablePerformanceMonitoring?: boolean;
  enableErrorRecovery?: boolean;
  enableDebugMode?: boolean;
  customHeaders?: Record<string, string>;
  
  // Event handlers
  onConnect?: () => void;
  onDisconnect?: (reason: string) => void;
  onError?: (err: Error) => void;
  onReconnect?: (attempt: number) => void;
  onReconnectFailed?: () => void;
  onBuildStart?: (buildId: string) => void;
  onBuildComplete?: (payload: BuildStatus) => void;
  onErrorEvent?: (payload: PreviewError) => void;
  onFileUpdate?: (filePaths: string[]) => void;
  onFileWatch?: (event: FileWatchEvent) => void;
  onConnectionStateChange?: (state: ConnectionState) => void;
  onLatencyUpdate?: (latency: number) => void;
  onCollaboration?: (event: CollaborationEvent) => void;
  onPerformanceUpdate?: (metrics: SocketMetrics) => void;
}

export const DEFAULT_SOCKET_OPTIONS: Required<Omit<PreviewSocketOptions, 
  'onConnect' | 'onDisconnect' | 'onError' | 'onReconnect' | 'onReconnectFailed' | 
  'onBuildStart' | 'onBuildComplete' | 'onErrorEvent' | 'onFileUpdate' | 'onFileWatch' |
  'onConnectionStateChange' | 'onLatencyUpdate' | 'onCollaboration' | 'onPerformanceUpdate' |
  'auth' | 'userId' | 'userName' | 'projectId' | 'customHeaders'
>> = {
  url: import.meta.env.VITE_SOCKET_URL || "http://localhost:5000",
  autoConnect: true,
  reconnect: true,
  reconnectAttempts: 10,
  reconnectDelay: 1000,
  maxReconnectDelay: 30000,
  timeout: 20000,
  heartbeatInterval: 25000,
  enableMetrics: true,
  enableCompression: true,
  enableCollaboration: false,
  enableFileWatching: true,
  namespace: "/preview",
  maxMessageQueue: 100,
  enableBinaryEvents: true,
  enablePerformanceMonitoring: true,
  enableErrorRecovery: true,
  enableDebugMode: false,
};

export function usePreviewSocket(
  onPreviewUpdate: (filePaths?: string[]) => void,
  options?: PreviewSocketOptions
) {
  const socketRef = useRef<Socket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const latencyStartRef = useRef<number>(0);
  const eventListenersSetupRef = useRef<boolean>(false);
  const messageQueueRef = useRef<Array<{ event: string; payload: any }>>([]);
  const performanceMonitorRef = useRef<NodeJS.Timeout | null>(null);

  // Memoize merged options to prevent unnecessary re-renders
  const mergedOptions = useMemo(() => ({
    ...DEFAULT_SOCKET_OPTIONS,
    ...options,
  }), [options]);

  // Enhanced state management
  const [connectionState, setConnectionState] = useState<ConnectionState>("disconnected");
  const [metrics, setMetrics] = useState<SocketMetrics>({
    connectionAttempts: 0,
    totalReconnects: 0,
    totalMessages: 0,
    totalErrors: 0,
    bytesReceived: 0,
    bytesSent: 0,
  });
  const [queuedMessages, setQueuedMessages] = useState<number>(0);
  const [lastActivity, setLastActivity] = useState<Date>(new Date());

  // Update connection state with callback
  const updateConnectionState = useCallback((newState: ConnectionState) => {
    setConnectionState(prevState => {
      if (prevState !== newState) {
        if (mergedOptions.enableDebugMode) {
          logger.debug(`Connection state transition: ${prevState} -> ${newState}`);
        }
        mergedOptions.onConnectionStateChange?.(newState);
        return newState;
      }
      return prevState;
    });
  }, [mergedOptions]);

  // Enhanced metrics tracking with performance monitoring
  const updateMetrics = useCallback((update: Partial<SocketMetrics>) => {
    if (!mergedOptions.enableMetrics) return;
    
    setMetrics(prev => {
      const newMetrics = { ...prev, ...update };
      
      // Calculate uptime
      if (prev.lastConnectedAt) {
        newMetrics.uptime = Math.floor((Date.now() - prev.lastConnectedAt.getTime()) / 1000);
      }
      
      // Update latency statistics
      if (update.averageLatency !== undefined) {
        newMetrics.maxLatency = prev.maxLatency 
          ? Math.max(prev.maxLatency, update.averageLatency)
          : update.averageLatency;
        newMetrics.minLatency = prev.minLatency 
          ? Math.min(prev.minLatency, update.averageLatency)
          : update.averageLatency;
      }
      
      if (mergedOptions.enablePerformanceMonitoring) {
        mergedOptions.onPerformanceUpdate?.(newMetrics);
      }
      
      return newMetrics;
    });
  }, [mergedOptions]);

  // Message queue management for offline scenarios
  const queueMessage = useCallback((event: string, payload: any) => {
    if (messageQueueRef.current.length >= mergedOptions.maxMessageQueue) {
      messageQueueRef.current.shift(); // Remove oldest message
    }
    
    messageQueueRef.current.push({ event, payload });
    setQueuedMessages(messageQueueRef.current.length);
    
    if (mergedOptions.enableDebugMode) {
      logger.debug(`Message queued: ${event}`, { queueSize: messageQueueRef.current.length });
    }
  }, [mergedOptions]);

  const processMessageQueue = useCallback(() => {
    if (!socketRef.current?.connected || messageQueueRef.current.length === 0) return;
    
    const messages = [...messageQueueRef.current];
    messageQueueRef.current = [];
    setQueuedMessages(0);
    
    logger.info(`Processing ${messages.length} queued messages`);
    
    messages.forEach(({ event, payload }) => {
      socketRef.current?.emit(event, payload);
      updateMetrics({ totalMessages: metrics.totalMessages + 1 });
    });
  }, [metrics.totalMessages, updateMetrics]);

  // Enhanced heartbeat with adaptive interval
  const startHeartbeat = useCallback(() => {
    if (!mergedOptions.heartbeatInterval || heartbeatIntervalRef.current) return;

    heartbeatIntervalRef.current = setInterval(() => {
      if (socketRef.current?.connected) {
        latencyStartRef.current = Date.now();
        socketRef.current.emit("ping", { timestamp: Date.now() });
        setLastActivity(new Date());
      }
    }, mergedOptions.heartbeatInterval);
    
    if (mergedOptions.enableDebugMode) {
      logger.debug(`Heartbeat started with interval: ${mergedOptions.heartbeatInterval}ms`);
    }
  }, [mergedOptions]);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
      heartbeatIntervalRef.current = null;
      
      if (mergedOptions.enableDebugMode) {
        logger.debug("Heartbeat stopped");
      }
    }
  }, [mergedOptions]);

  // Performance monitoring
  const startPerformanceMonitoring = useCallback(() => {
    if (!mergedOptions.enablePerformanceMonitoring || performanceMonitorRef.current) return;

    performanceMonitorRef.current = setInterval(() => {
      if (mergedOptions.enableMetrics) {
        const memoryInfo = (performance as any).memory;
        if (memoryInfo) {
          logger.debug("Performance metrics", {
            heapUsed: Math.round(memoryInfo.usedJSHeapSize / 1024 / 1024),
            heapTotal: Math.round(memoryInfo.totalJSHeapSize / 1024 / 1024),
            connectionState,
            uptime: metrics.uptime,
          });
        }
      }
    }, 60000); // Every minute
  }, [mergedOptions, connectionState, metrics.uptime]);

  const stopPerformanceMonitoring = useCallback(() => {
    if (performanceMonitorRef.current) {
      clearInterval(performanceMonitorRef.current);
      performanceMonitorRef.current = null;
    }
  }, []);

  // Enhanced connection with retry logic and authentication
  const connect = useCallback(async () => {
    if (socketRef.current?.connected) {
      if (mergedOptions.enableDebugMode) {
        logger.debug("Socket already connected");
      }
      return;
    }

    updateConnectionState("connecting");
    updateMetrics({ 
      connectionAttempts: metrics.connectionAttempts + 1 
    });

    logger.info("Initiating socket connection", { 
      url: mergedOptions.url,
      namespace: mergedOptions.namespace,
      attempt: metrics.connectionAttempts + 1
    });

    try {
      if (mergedOptions.auth || mergedOptions.userId) {
        updateConnectionState("authenticating");
      }

      const socketUrl = mergedOptions.namespace 
        ? `${mergedOptions.url}${mergedOptions.namespace}`
        : mergedOptions.url;

      const socketConfig = {
        autoConnect: false, // Manual control
        reconnection: mergedOptions.reconnect,
        reconnectionAttempts: mergedOptions.reconnectAttempts,
        reconnectionDelay: mergedOptions.reconnectDelay,
        reconnectionDelayMax: mergedOptions.maxReconnectDelay,
        timeout: mergedOptions.timeout,
        transports: ["websocket", "polling"],
        upgrade: true,
        compression: mergedOptions.enableCompression,
        forceNew: false,
        auth: {
          ...mergedOptions.auth,
          userId: mergedOptions.userId,
          userName: mergedOptions.userName,
          projectId: mergedOptions.projectId,
          timestamp: Date.now(),
        },
        extraHeaders: mergedOptions.customHeaders,
      };

      socketRef.current = io(socketUrl, socketConfig);
      setupEventListeners();
      
      // Manual connect for better control
      socketRef.current.connect();
      
    } catch (error) {
      logger.error("Connection setup failed", error);
      updateConnectionState("error");
      updateMetrics({ totalErrors: metrics.totalErrors + 1 });
      throw error;
    }
  }, [mergedOptions, metrics, updateConnectionState, updateMetrics]);

  // Enhanced disconnect with cleanup
  const disconnect = useCallback(() => {
    logger.info("Initiating disconnect");
    
    // Clear all timers
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    stopHeartbeat();
    stopPerformanceMonitoring();

    // Clear message queue if needed
    if (messageQueueRef.current.length > 0) {
      logger.debug(`Clearing ${messageQueueRef.current.length} queued messages`);
      messageQueueRef.current = [];
      setQueuedMessages(0);
    }

    if (socketRef.current) {
      socketRef.current.removeAllListeners();
      socketRef.current.disconnect();
      socketRef.current = null;
      eventListenersSetupRef.current = false;
    }

    updateConnectionState("disconnected");
  }, [stopHeartbeat, stopPerformanceMonitoring, updateConnectionState]);

  // Smart reconnect with exponential backoff and jitter
  const reconnect = useCallback(() => {
    if (connectionState === "reconnecting" || connectionState === "connecting") {
      logger.debug("Reconnection already in progress");
      return;
    }

    updateConnectionState("reconnecting");
    disconnect();
    
    // Exponential backoff with jitter
    const baseDelay = mergedOptions.reconnectDelay;
    const exponentialDelay = baseDelay * Math.pow(2, metrics.totalReconnects);
    const jitter = Math.random() * 1000; // Add up to 1 second of jitter
    const delay = Math.min(exponentialDelay + jitter, mergedOptions.maxReconnectDelay);

    logger.info(`Scheduling reconnection`, { 
      delay: Math.round(delay),
      attempt: metrics.totalReconnects + 1,
      maxAttempts: mergedOptions.reconnectAttempts
    });
    
    reconnectTimeoutRef.current = setTimeout(() => {
      updateMetrics({ totalReconnects: metrics.totalReconnects + 1 });
      connect();
    }, delay);
  }, [connectionState, disconnect, connect, mergedOptions, metrics.totalReconnects, updateConnectionState, updateMetrics]);

  // Enhanced emit with queuing and error handling
  const emit = useCallback((event: string, payload?: any, callback?: Function) => {
    const messageSize = JSON.stringify(payload || {}).length;
    
    if (socketRef.current?.connected) {
      try {
        if (mergedOptions.enableDebugMode) {
          logger.debug(`Emitting event: ${event}`, { 
            payload: typeof payload === 'object' ? Object.keys(payload) : payload,
            size: messageSize
          });
        }
        
        socketRef.current.emit(event, payload, callback);
        updateMetrics({ 
          totalMessages: metrics.totalMessages + 1,
          bytesSent: (metrics.bytesSent || 0) + messageSize
        });
        setLastActivity(new Date());
        return true;
      } catch (error) {
        logger.error(`Error emitting ${event}`, error);
        updateMetrics({ totalErrors: metrics.totalErrors + 1 });
        return false;
      }
    } else {
      if (mergedOptions.enableErrorRecovery) {
        queueMessage(event, payload);
        logger.debug(`Queued message: ${event} (socket not connected)`);
        return false;
      } else {
        logger.warn(`Cannot emit ${event} - socket not connected`, { 
          connectionState,
          event,
          queueEnabled: mergedOptions.enableErrorRecovery
        });
        return false;
      }
    }
  }, [connectionState, mergedOptions, metrics, queueMessage, updateMetrics]);

  // Comprehensive event listener setup with error boundaries
  const setupEventListeners = useCallback(() => {
    const socket = socketRef.current;
    if (!socket || eventListenersSetupRef.current) return;

    logger.debug("Setting up comprehensive event listeners");
    eventListenersSetupRef.current = true;

    // Wrap all event handlers with error boundaries
    const safeHandler = (handler: Function) => (...args: any[]) => {
      try {
        return handler(...args);
      } catch (error) {
        logger.error("Event handler error", { error, handler: handler.name });
        updateMetrics({ totalErrors: metrics.totalErrors + 1 });
      }
    };

    // Connection lifecycle events
    socket.on("connect", safeHandler(() => {
      const now = new Date();
      logger.info("Successfully connected to preview socket", { 
        socketId: socket.id,
        timestamp: now.toISOString(),
        transport: socket.io.engine.transport.name
      });
      
      updateConnectionState("connected");
      updateMetrics({ 
        lastConnectedAt: now,
        totalReconnects: 0 // Reset on successful connection
      });
      
      startHeartbeat();
      startPerformanceMonitoring();
      processMessageQueue(); // Process any queued messages
      
      mergedOptions.onConnect?.();
    }));

    socket.on("disconnect", safeHandler((reason: string) => {
      const now = new Date();
      logger.info("Disconnected from preview socket", { 
        reason, 
        timestamp: now.toISOString(),
        wasConnected: connectionState === "connected"
      });
      
      updateConnectionState("disconnected");
      updateMetrics({ lastDisconnectedAt: now });
      stopHeartbeat();
      stopPerformanceMonitoring();
      
      mergedOptions.onDisconnect?.(reason);
      
      // Auto-reconnect on unexpected disconnections
      if (mergedOptions.reconnect && reason !== "io client disconnect") {
        setTimeout(() => reconnect(), 1000);
      }
    }));

    socket.on("connect_error", safeHandler((err: Error) => {
      logger.error("Socket connection error", { 
        message: err.message,
        type: (err as any).type,
        description: (err as any).description,
        context: (err as any).context
      });
      
      updateConnectionState("error");
      updateMetrics({ totalErrors: metrics.totalErrors + 1 });
      mergedOptions.onError?.(err);
    }));

    // Reconnection events
    socket.on("reconnect_attempt", safeHandler((attempt: number) => {
      logger.debug(`Reconnection attempt ${attempt}/${mergedOptions.reconnectAttempts}`);
      updateConnectionState("reconnecting");
      mergedOptions.onReconnect?.(attempt);
    }));

    socket.on("reconnect", safeHandler((attempt: number) => {
      logger.info(`Successfully reconnected after ${attempt} attempts`);
      updateMetrics({ totalReconnects: attempt });
    }));

    socket.on("reconnect_failed", safeHandler(() => {
      logger.error("All reconnection attempts exhausted");
      updateConnectionState("error");
      mergedOptions.onReconnectFailed?.();
    }));

    // Application-specific events with enhanced payloads
    socket.on("preview:update", safeHandler((payload: { 
      files: string[]; 
      timestamp?: string; 
      buildId?: string;
      changeType?: string;
    }) => {
      const messageSize = JSON.stringify(payload).length;
      updateMetrics({ 
        totalMessages: metrics.totalMessages + 1,
        bytesReceived: (metrics.bytesReceived || 0) + messageSize
      });
      
      logger.info("Received preview update", { 
        files: payload.files,
        timestamp: payload.timestamp,
        buildId: payload.buildId,
        changeType: payload.changeType,
        fileCount: payload.files?.length || 0
      });
      
      setLastActivity(new Date());
      mergedOptions.onFileUpdate?.(payload.files);
      onPreviewUpdate(payload.files);
    }));

    socket.on("preview:build-status", safeHandler((payload: BuildStatus) => {
      updateMetrics({ totalMessages: metrics.totalMessages + 1 });
      
      logger.info("Build status update", { 
        status: payload.status,
        success: payload.success,
        buildTime: payload.buildTime,
        progress: payload.progress,
        stage: payload.stage,
        buildId: payload.buildId
      });
      
      if (payload.status === "started" && payload.buildId) {
        mergedOptions.onBuildStart?.(payload.buildId);
      } else if (payload.status === "completed" || payload.status === "failed") {
        mergedOptions.onBuildComplete?.(payload);
      }
    }));

    socket.on("preview:error", safeHandler((payload: PreviewError) => {
      updateMetrics({ 
        totalMessages: metrics.totalMessages + 1,
        totalErrors: metrics.totalErrors + 1
      });
      
      logger.error("Preview error received", {
        message: payload.message,
        code: payload.code,
        severity: payload.severity,
        source: payload.source,
        file: payload.file,
        line: payload.line,
        category: payload.category,
        timestamp: payload.timestamp
      });
      
      mergedOptions.onErrorEvent?.(payload);
    }));

    // File watching events
    if (mergedOptions.enableFileWatching) {
      socket.on("file:watch", safeHandler((event: FileWatchEvent) => {
        updateMetrics({ totalMessages: metrics.totalMessages + 1 });
        
        logger.debug("File watch event", {
          type: event.type,
          path: event.path,
          oldPath: event.oldPath,
          size: event.size,
          timestamp: event.timestamp
        });
        
        mergedOptions.onFileWatch?.(event);
      }));
    }

    // Collaboration events
    if (mergedOptions.enableCollaboration) {
      socket.on("collaboration:event", safeHandler((event: CollaborationEvent) => {
        updateMetrics({ totalMessages: metrics.totalMessages + 1 });
        
        if (mergedOptions.enableDebugMode) {
          logger.debug("Collaboration event", {
            type: event.type,
            userId: event.userId,
            userName: event.userName,
            timestamp: event.timestamp
          });
        }
        
        mergedOptions.onCollaboration?.(event);
      }));
    }

    // Enhanced heartbeat response with latency calculation
    socket.on("pong", safeHandler((data: { timestamp?: number } = {}) => {
      if (latencyStartRef.current && mergedOptions.enableMetrics) {
        const latency = Date.now() - latencyStartRef.current;
        
        updateMetrics({
          averageLatency: metrics.averageLatency 
            ? Math.round((metrics.averageLatency * 0.8) + (latency * 0.2)) // Moving average
            : latency
        });
        
        if (mergedOptions.enableDebugMode) {
          logger.debug(`Heartbeat latency: ${latency}ms`);
        }
        
        mergedOptions.onLatencyUpdate?.(latency);
      }
    }));

    // Generic error handler
    socket.on("error", safeHandler((error: any) => {
      logger.error("Generic socket error", error);
      updateMetrics({ totalErrors: metrics.totalErrors + 1 });
      mergedOptions.onError?.(error);
    }));

    // Server-sent metrics
    socket.on("server:metrics", safeHandler((serverMetrics: any) => {
      if (mergedOptions.enableDebugMode) {
        logger.debug("Server metrics received", serverMetrics);
      }
    }));

  }, [onPreviewUpdate, mergedOptions, updateConnectionState, updateMetrics, startHeartbeat, 
      startPerformanceMonitoring, processMessageQueue, stopHeartbeat, stopPerformanceMonitoring, 
      reconnect, connectionState, metrics]);

  // Effect for managing connection lifecycle - fixed to prevent loops
  useEffect(() => {
    let mounted = true;
    
    if (mergedOptions.autoConnect && mounted) {
      const timer = setTimeout(() => {
        if (mounted && !socketRef.current?.connected) {
          connect();
        }
      }, 100);
      
      return () => {
        clearTimeout(timer);
        mounted = false;
      };
    }

    return () => {
      mounted = false;
    };
  }, [mergedOptions.autoConnect]);

  // Separate cleanup effect
  useEffect(() => {
    return () => {
      if (mergedOptions.enableDebugMode) {
        logger.debug("Hook cleanup: Disconnecting and clearing resources");
      }
      disconnect();
    };
  }, []);

  // Collaboration helpers
  const sendCollaborationEvent = useCallback((type: CollaborationEvent['type'], data: any) => {
    if (!mergedOptions.enableCollaboration) return false;
    
    return emit("collaboration:event", {
      type,
      userId: mergedOptions.userId,
      userName: mergedOptions.userName,
      data,
      timestamp: new Date().toISOString(),
    });
  }, [emit, mergedOptions]);

  // File watching helpers
  const watchFile = useCallback((filePath: string) => {
    return emit("file:watch", { action: "watch", path: filePath });
  }, [emit]);

  const unwatchFile = useCallback((filePath: string) => {
    return emit("file:watch", { action: "unwatch", path: filePath });
  }, [emit]);

  // Advanced utilities
  const getConnectionQuality = useCallback(() => {
    if (!metrics.averageLatency) return "unknown";
    if (metrics.averageLatency < 100) return "excellent";
    if (metrics.averageLatency < 300) return "good";
    if (metrics.averageLatency < 1000) return "fair";
    return "poor";
  }, [metrics.averageLatency]);

  const isHealthy = useCallback(() => {
    return connectionState === "connected" && 
           Date.now() - lastActivity.getTime() < (mergedOptions.heartbeatInterval * 2);
  }, [connectionState, lastActivity, mergedOptions.heartbeatInterval]);

  // Expose comprehensive API
  return {
    // Socket instance (readonly)
    socket: socketRef.current,
    
    // Connection management
    connect,
    disconnect,
    reconnect,
    
    // Communication
    emit,
    
    // State
    connectionState,
    isConnected: useCallback(() => socketRef.current?.connected || false, []),
    isConnecting: useCallback(() => 
      connectionState === "connecting" || 
      connectionState === "reconnecting" || 
      connectionState === "authenticating", [connectionState]),
    isHealthy,
    
    // Metrics and monitoring
    metrics: mergedOptions.enableMetrics ? metrics : null,
    queuedMessages,
    lastActivity,
    connectionQuality: getConnectionQuality(),
    
    // Collaboration features
    sendCollaborationEvent: mergedOptions.enableCollaboration ? sendCollaborationEvent : undefined,
    
    // File watching
    watchFile: mergedOptions.enableFileWatching ? watchFile : undefined,
    unwatchFile: mergedOptions.enableFileWatching ? unwatchFile : undefined,
    
    // Utilities
    getSocketId: useCallback(() => socketRef.current?.id, []),
    forceReconnect: useCallback(() => {
      logger.info("Force reconnect requested");
      disconnect();
      setTimeout(connect, 500);
    }, [disconnect, connect]),
    
    // Advanced operations
    clearMessageQueue: useCallback(() => {
      messageQueueRef.current = [];
      setQueuedMessages(0);
      logger.info("Message queue cleared");
    }, []),
    
    getQueuedMessages: useCallback(() => [...messageQueueRef.current], []),
    
    // Debug helpers
    enableDebugMode: useCallback(() => {
      logger.info("Debug mode enabled");
    }, []),
    
    getDebugInfo: useCallback(() => ({
      connectionState,
      metrics,
      queuedMessages,
      lastActivity,
      socketId: socketRef.current?.id,
      transport: socketRef.current?.io?.engine?.transport?.name,
      options: mergedOptions,
    }), [connectionState, metrics, queuedMessages, lastActivity, mergedOptions]),
  };
}