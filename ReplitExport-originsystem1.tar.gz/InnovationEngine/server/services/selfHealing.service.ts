import { SelfHealingLoop } from "../agents/selfHealingLoop";

interface PipelineResult {
  success: boolean;
  metrics: object;
  artifacts?: string[];
  error?: string;
  retries?: number;
}

interface AuditEntry {
  timestamp: Date;
  prompt: string;
  userId?: string;
  status: 'started' | 'completed' | 'failed';
  metrics?: object;
  error?: any;
}

class Logger {
  static info(message: string) {
    console.log(`[INFO] ${new Date().toISOString()} - ${message}`);
  }

  static error(message: string, error?: any) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error);
  }
}

class AuditTrail {
  private entries: AuditEntry[] = [];

  recordStart(prompt: string, userId?: string) {
    this.entries.push({
      timestamp: new Date(),
      prompt,
      userId,
      status: 'started'
    });
  }

  recordCompletion(prompt: string, success: boolean, metrics: object) {
    this.entries.push({
      timestamp: new Date(),
      prompt,
      status: success ? 'completed' : 'failed',
      metrics
    });
  }

  recordError(prompt: string, error: any, metrics: object) {
    this.entries.push({
      timestamp: new Date(),
      prompt,
      status: 'failed',
      error,
      metrics
    });
  }

  getEntries(): AuditEntry[] {
    return this.entries;
  }
}

class PerformanceMonitor {
  private startTime: number = 0;
  private metrics: any = {};

  startTracking() {
    this.startTime = Date.now();
    this.metrics = {
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage()
    };
  }

  getMetrics() {
    const endTime = Date.now();
    const endMemory = process.memoryUsage();
    const endCpu = process.cpuUsage();

    return {
      duration: endTime - this.startTime,
      memoryDelta: {
        rss: endMemory.rss - this.metrics.memoryUsage.rss,
        heapUsed: endMemory.heapUsed - this.metrics.memoryUsage.heapUsed
      },
      cpuUsage: endCpu
    };
  }

  stopTracking() {
    this.metrics = {};
  }
}

export class SelfHealingService {
  private static instance: SelfHealingService;
  private auditTrail = new AuditTrail();
  private performanceMonitor = new PerformanceMonitor();
  private activeJobs = new Map<string, any>();

  private constructor() {} // Private for singleton pattern

  public static getInstance(): SelfHealingService {
    if (!SelfHealingService.instance) {
      SelfHealingService.instance = new SelfHealingService();
    }
    return SelfHealingService.instance;
  }

  public async runFullSelfHealingPipeline(
    prompt: string,
    userId?: string,
    options?: {
      timeout?: number;
      priority?: 'low' | 'medium' | 'high';
    }
  ): Promise<PipelineResult> {
    const startTime = Date.now();
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const loop = new SelfHealingLoop({
      maxRetries: options?.priority === 'high' ? 8 : 5,
      validationTimeout: options?.timeout || 30000
    });

    try {
      this.auditTrail.recordStart(prompt, userId);
      this.performanceMonitor.startTracking();

      // Track active job
      this.activeJobs.set(jobId, {
        status: 'running',
        prompt,
        userId,
        startTime: new Date()
      });

      const result = await loop.execute(prompt);
      const metrics = this.performanceMonitor.getMetrics();

      const pipelineResult: PipelineResult = {
        success: result.success,
        metrics: {
          ...metrics,
          ...result.metrics
        },
        retries: this.getRetryCount(loop),
        artifacts: this.getGeneratedArtifacts(result.generatedFiles)
      };

      this.auditTrail.recordCompletion(prompt, result.success, metrics);
      Logger.info(`Pipeline completed in ${Date.now() - startTime}ms`);

      // Update job status
      this.activeJobs.set(jobId, {
        ...this.activeJobs.get(jobId),
        status: result.success ? 'completed' : 'failed',
        endTime: new Date(),
        result: pipelineResult
      });

      return pipelineResult;
    } catch (error) {
      const metrics = this.performanceMonitor.getMetrics();
      this.auditTrail.recordError(prompt, error, metrics);
      
      Logger.error(`Pipeline failed after ${Date.now() - startTime}ms`, error);
      
      // Update job status
      this.activeJobs.set(jobId, {
        ...this.activeJobs.get(jobId),
        status: 'failed',
        endTime: new Date(),
        error: (error as Error).message
      });

      throw error;
    } finally {
      this.performanceMonitor.stopTracking();
    }
  }

  public async getJobStatus(jobId: string) {
    const job = this.activeJobs.get(jobId);
    if (!job) {
      return { error: 'Job not found' };
    }
    return job;
  }

  public getAuditLog() {
    return this.auditTrail.getEntries();
  }

  public getActiveJobs() {
    return Array.from(this.activeJobs.entries()).map(([id, job]) => ({
      id,
      ...job
    }));
  }

  private getRetryCount(loop: any): number {
    return loop.retries || 0;
  }

  private getGeneratedArtifacts(generatedFiles?: Map<string, string>): string[] {
    if (!generatedFiles) return [];
    return Array.from(generatedFiles.keys());
  }
}

// Singleton export for convenience
export const selfHealingService = SelfHealingService.getInstance();