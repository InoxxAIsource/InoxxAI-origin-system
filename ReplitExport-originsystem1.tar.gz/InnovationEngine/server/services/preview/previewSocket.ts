import { Server as SocketIOServer, Socket } from "socket.io";
import { Server as HttpServer } from "http";
import { Server as HttpsServer } from "https";
import { EventEmitter } from "events";
import { z } from "zod";
import * as crypto from "crypto";

// Enhanced Type Definitions
type ServerType = HttpServer | HttpsServer;

// Configuration schema
const PreviewSocketConfigSchema = z.object({
  allowedOrigins: z.union([z.array(z.string()), z.string()]).default(["*"]),
  pingInterval: z.number().default(25000),
  pingTimeout: z.number().default(20000),
  maxHttpBufferSize: z.number().default(1e6),
  enableCompression: z.boolean().default(true),
  enableMetrics: z.boolean().default(true),
  enableHeartbeat: z.boolean().default(true),
  enableReconnection: z.boolean().default(true),
  maxConnections: z.number().default(1000),
  enableBroadcastThrottling: z.boolean().default(true),
  broadcastThrottleMs: z.number().default(100),
  enableClientValidation: z.boolean().default(true),
  enablePerformanceMonitoring: z.boolean().default(true),
  metricsInterval: z.number().default(30000),
  enableCollaboration: z.boolean().default(true),
  enableAIInsights: z.boolean().default(true),
  enableSecurity: z.boolean().default(true),
  enableAnalytics: z.boolean().default(true),
  maxRoomsPerClient: z.number().default(10),
  messageRetentionMs: z.number().default(300000), // 5 minutes
});

type PreviewSocketConfig = z.infer<typeof PreviewSocketConfigSchema>;

// Enhanced event types
export type PreviewEvent = 
  | 'build:started'
  | 'build:progress'
  | 'build:completed'
  | 'build:failed'
  | 'file:changed'
  | 'hot:reload'
  | 'error:runtime'
  | 'collab:join'
  | 'collab:leave'
  | 'collab:edit'
  | 'collab:cursor'
  | 'collab:selection'
  | 'ai:insight'
  | 'ai:suggestion'
  | 'metrics:update'
  | 'security:scan'
  | 'performance:alert';

export interface PreviewBuildStatus {
  id: string;
  status: 'idle' | 'building' | 'success' | 'error';
  progress: number;
  startTime?: Date;
  endTime?: Date;
  duration?: number;
  errors?: BuildError[];
  warnings?: BuildWarning[];
  artifacts?: BuildArtifact[];
  performance?: PerformanceData;
}

export interface BuildError {
  id: string;
  type: 'syntax' | 'type' | 'dependency' | 'runtime';
  severity: 'error' | 'warning' | 'info';
  message: string;
  file: string;
  line: number;
  column: number;
  suggestions: string[];
  fixable: boolean;
}

export interface BuildWarning {
  id: string;
  type: 'performance' | 'accessibility' | 'seo' | 'security';
  message: string;
  file: string;
  severity: 'low' | 'medium' | 'high';
  impact: string;
  recommendation: string;
}

export interface BuildArtifact {
  type: 'bundle' | 'chunk' | 'asset' | 'sourcemap';
  name: string;
  size: number;
  path: string;
  hash: string;
  compressed: boolean;
  gzipSize?: number;
  brotliSize?: number;
}

export interface PerformanceData {
  bundleSize: number;
  chunkCount: number;
  loadTime: number;
  buildTime: number;
  memoryUsage: number;
  cpuUsage: number;
  networkLatency: number;
  renderTime: number;
  interactivityTime: number;
  cumulativeLayoutShift: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  totalBlockingTime: number;
}

interface HighPreviewMetrics {
  totalConnections: number;
  activeConnections: number;
  totalMessages: number;
  totalErrors: number;
  averageLatency: number;
  peakConnections: number;
  messageRate: number; // messages per second
  errorRate: number; // errors per minute
  uptime: number; // seconds
  lastEventTimestamp: Date;
  bandwidthUsage: {
    incoming: number; // bytes
    outgoing: number; // bytes
  };
  connectionsByOrigin: Map<string, number>;
  performanceStats: {
    cpu: number;
    memory: number;
    eventLoopDelay: number;
  };
  collaborationStats: {
    activeRooms: number;
    totalRooms: number;
    activeCollaborators: number;
    editsPerMinute: number;
    conflictResolutions: number;
  };
  aiInsights: {
    generated: number;
    applied: number;
    dismissed: number;
    averageConfidence: number;
  };
  securityMetrics: {
    threatsBlocked: number;
    vulnerabilitiesDetected: number;
    riskScore: number;
    lastScan: Date;
  };
}

interface ClientInfo {
  id: string;
  connectedAt: Date;
  lastActivity: Date;
  userAgent?: string;
  ipAddress?: string;
  origin?: string;
  version?: string;
  latencySamples: number[];
  messageCount: number;
  errorCount: number;
  bytesReceived: number;
  bytesSent: number;
  authenticated: boolean;
  capabilities: Set<string>;
  metadata: Record<string, any>;
  rooms: Set<string>;
  user?: UserInfo;
  presence: 'active' | 'idle' | 'away';
  role: 'owner' | 'collaborator' | 'viewer';
  permissions: Set<string>;
}

interface UserInfo {
  id: string;
  username: string;
  email?: string;
  avatar?: string;
  displayName?: string;
  preferences: Record<string, any>;
}

interface CollaborationRoom {
  id: string;
  name: string;
  createdAt: Date;
  lastActivity: Date;
  participants: Set<string>;
  owner: string;
  settings: RoomSettings;
  state: RoomState;
  history: CollaborationEvent[];
}

interface RoomSettings {
  maxParticipants: number;
  allowAnonymous: boolean;
  enableVoice: boolean;
  enableVideo: boolean;
  enableScreenShare: boolean;
  recordSession: boolean;
  permissions: Record<string, string[]>;
}

interface RoomState {
  activeFile?: string;
  cursor: Map<string, CursorPosition>;
  selections: Map<string, SelectionRange>;
  edits: OperationalTransform[];
  breakpoints: Map<string, DebugBreakpoint[]>;
  comments: Comment[];
}

interface CursorPosition {
  file: string;
  line: number;
  column: number;
  timestamp: Date;
}

interface SelectionRange {
  file: string;
  start: { line: number; column: number };
  end: { line: number; column: number };
  timestamp: Date;
}

interface OperationalTransform {
  id: string;
  clientId: string;
  operation: 'insert' | 'delete' | 'retain';
  position: number;
  content?: string;
  length?: number;
  timestamp: Date;
  applied: boolean;
}

interface DebugBreakpoint {
  id: string;
  file: string;
  line: number;
  condition?: string;
  enabled: boolean;
  hitCount: number;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  file: string;
  line: number;
  resolved: boolean;
  createdAt: Date;
  replies: CommentReply[];
}

interface CommentReply {
  id: string;
  author: string;
  content: string;
  createdAt: Date;
}

interface CollaborationEvent {
  id: string;
  type: 'join' | 'leave' | 'edit' | 'cursor' | 'comment' | 'breakpoint';
  clientId: string;
  timestamp: Date;
  data: any;
}

interface PreviewMessage {
  type: PreviewEvent;
  payload: any;
  timestamp: string;
  id: string;
  priority?: 'low' | 'normal' | 'high' | 'critical';
  targetClients?: string[];
  targetRooms?: string[];
  requiresAck?: boolean;
  metadata?: Record<string, any>;
}

interface AIInsight {
  id: string;
  type: 'optimization' | 'error' | 'suggestion' | 'warning' | 'security';
  priority: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  recommendation: string;
  implementation: string;
  impact: 'positive' | 'neutral' | 'negative';
  confidence: number;
  tags: string[];
  timestamp: Date;
  resolved: boolean;
  automatable: boolean;
  appliedCount: number;
  dismissedCount: number;
}

interface SecurityAlert {
  id: string;
  type: 'vulnerability' | 'threat' | 'compliance' | 'policy';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  recommendation: string;
  file?: string;
  line?: number;
  references: string[];
  cvss?: number;
  timestamp: Date;
  resolved: boolean;
  autoFixAvailable: boolean;
}

// Message Queue Implementation with Priority
class PriorityMessageQueue {
  private queues: Map<string, PreviewMessage[]> = new Map([
    ['critical', []],
    ['high', []],
    ['normal', []],
    ['low', []]
  ]);
  private processing = false;
  private readonly maxSize: number;

  constructor(maxSize = 5000) {
    this.maxSize = maxSize;
  }

  enqueue(message: PreviewMessage): boolean {
    const priority = message.priority || 'normal';
    const queue = this.queues.get(priority);
    
    if (!queue) return false;

    // Check total size across all queues
    const totalSize = Array.from(this.queues.values()).reduce((sum, q) => sum + q.length, 0);
    
    if (totalSize >= this.maxSize) {
      // Remove oldest low priority messages first
      const lowQueue = this.queues.get('low')!;
      if (lowQueue.length > 0) {
        lowQueue.shift();
      } else {
        return false; // Queue full
      }
    }

    queue.push(message);
    return true;
  }

  dequeue(): PreviewMessage | undefined {
    // Process in priority order
    for (const priority of ['critical', 'high', 'normal', 'low']) {
      const queue = this.queues.get(priority)!;
      if (queue.length > 0) {
        return queue.shift();
      }
    }
    return undefined;
  }

  size(): number {
    return Array.from(this.queues.values()).reduce((sum, queue) => sum + queue.length, 0);
  }

  clear(): void {
    this.queues.forEach(queue => queue.length = 0);
  }

  getQueueSizes(): Record<string, number> {
    const sizes: Record<string, number> = {};
    this.queues.forEach((queue, priority) => {
      sizes[priority] = queue.length;
    });
    return sizes;
  }
}

// Enhanced Performance Monitor
class AdvancedPerformanceMonitor {
  private eventProcessingTimes: number[] = [];
  private messageRates: { timestamp: number; count: number }[] = [];
  private errorRates: { timestamp: number; count: number }[] = [];
  private latencySamples: number[] = [];
  private startTime = Date.now();

  recordEventProcessingTime(duration: number): void {
    this.eventProcessingTimes.push(duration);
    if (this.eventProcessingTimes.length > 1000) {
      this.eventProcessingTimes = this.eventProcessingTimes.slice(-500);
    }
  }

  recordMessage(): void {
    const now = Date.now();
    this.messageRates.push({ timestamp: now, count: 1 });
    
    // Clean old entries (keep last 5 minutes)
    const cutoff = now - 300000;
    this.messageRates = this.messageRates.filter(entry => entry.timestamp > cutoff);
  }

  recordError(): void {
    const now = Date.now();
    this.errorRates.push({ timestamp: now, count: 1 });
    
    // Clean old entries (keep last 5 minutes)
    const cutoff = now - 300000;
    this.errorRates = this.errorRates.filter(entry => entry.timestamp > cutoff);
  }

  recordLatency(latency: number): void {
    this.latencySamples.push(latency);
    if (this.latencySamples.length > 100) {
      this.latencySamples = this.latencySamples.slice(-50);
    }
  }

  getAverageProcessingTime(): number {
    return this.eventProcessingTimes.length > 0 
      ? this.eventProcessingTimes.reduce((a, b) => a + b, 0) / this.eventProcessingTimes.length 
      : 0;
  }

  getMessageRate(): number {
    const now = Date.now();
    const oneMinuteAgo = now - 60000;
    const recentMessages = this.messageRates.filter(entry => entry.timestamp > oneMinuteAgo);
    return recentMessages.length;
  }

  getErrorRate(): number {
    const now = Date.now();
    const oneMinuteAgo = now - 60000;
    const recentErrors = this.errorRates.filter(entry => entry.timestamp > oneMinuteAgo);
    return recentErrors.length;
  }

  getAverageLatency(): number {
    return this.latencySamples.length > 0 
      ? this.latencySamples.reduce((a, b) => a + b, 0) / this.latencySamples.length 
      : 0;
  }

  getUptime(): number {
    return Math.floor((Date.now() - this.startTime) / 1000);
  }

  reset(): void {
    this.eventProcessingTimes = [];
    this.messageRates = [];
    this.errorRates = [];
    this.latencySamples = [];
    this.startTime = Date.now();
  }
}

// Collaboration Manager
class CollaborationManager extends EventEmitter {
  private rooms = new Map<string, CollaborationRoom>();
  private userRooms = new Map<string, Set<string>>();

  createRoom(id: string, name: string, owner: string, settings?: Partial<RoomSettings>): CollaborationRoom {
    const room: CollaborationRoom = {
      id,
      name,
      createdAt: new Date(),
      lastActivity: new Date(),
      participants: new Set([owner]),
      owner,
      settings: {
        maxParticipants: 50,
        allowAnonymous: false,
        enableVoice: false,
        enableVideo: false,
        enableScreenShare: false,
        recordSession: false,
        permissions: {},
        ...settings
      },
      state: {
        cursor: new Map(),
        selections: new Map(),
        edits: [],
        breakpoints: new Map(),
        comments: []
      },
      history: []
    };

    this.rooms.set(id, room);
    
    if (!this.userRooms.has(owner)) {
      this.userRooms.set(owner, new Set());
    }
    this.userRooms.get(owner)!.add(id);

    this.emit('room:created', { room });
    return room;
  }

  joinRoom(roomId: string, clientId: string): boolean {
    const room = this.rooms.get(roomId);
    if (!room) return false;

    if (room.participants.size >= room.settings.maxParticipants) {
      return false;
    }

    room.participants.add(clientId);
    room.lastActivity = new Date();

    if (!this.userRooms.has(clientId)) {
      this.userRooms.set(clientId, new Set());
    }
    this.userRooms.get(clientId)!.add(roomId);

    const event: CollaborationEvent = {
      id: crypto.randomUUID(),
      type: 'join',
      clientId,
      timestamp: new Date(),
      data: { roomId }
    };
    room.history.push(event);

    this.emit('room:joined', { roomId, clientId, room });
    return true;
  }

  leaveRoom(roomId: string, clientId: string): boolean {
    const room = this.rooms.get(roomId);
    if (!room) return false;

    room.participants.delete(clientId);
    room.state.cursor.delete(clientId);
    room.state.selections.delete(clientId);

    const userRooms = this.userRooms.get(clientId);
    if (userRooms) {
      userRooms.delete(roomId);
      if (userRooms.size === 0) {
        this.userRooms.delete(clientId);
      }
    }

    const event: CollaborationEvent = {
      id: crypto.randomUUID(),
      type: 'leave',
      clientId,
      timestamp: new Date(),
      data: { roomId }
    };
    room.history.push(event);

    // Clean up empty rooms (except if owner is still present)
    if (room.participants.size === 0 || (room.participants.size === 1 && !room.participants.has(room.owner))) {
      this.rooms.delete(roomId);
    }

    this.emit('room:left', { roomId, clientId, room });
    return true;
  }

  updateCursor(roomId: string, clientId: string, position: CursorPosition): void {
    const room = this.rooms.get(roomId);
    if (!room || !room.participants.has(clientId)) return;

    room.state.cursor.set(clientId, position);
    room.lastActivity = new Date();

    this.emit('collaboration:cursor', { roomId, clientId, position });
  }

  updateSelection(roomId: string, clientId: string, selection: SelectionRange): void {
    const room = this.rooms.get(roomId);
    if (!room || !room.participants.has(clientId)) return;

    room.state.selections.set(clientId, selection);
    room.lastActivity = new Date();

    this.emit('collaboration:selection', { roomId, clientId, selection });
  }

  applyEdit(roomId: string, clientId: string, operation: OperationalTransform): void {
    const room = this.rooms.get(roomId);
    if (!room || !room.participants.has(clientId)) return;

    // Apply operational transform logic here
    room.state.edits.push(operation);
    room.lastActivity = new Date();

    const event: CollaborationEvent = {
      id: crypto.randomUUID(),
      type: 'edit',
      clientId,
      timestamp: new Date(),
      data: { operation }
    };
    room.history.push(event);

    this.emit('collaboration:edit', { roomId, clientId, operation });
  }

  getRoom(roomId: string): CollaborationRoom | undefined {
    return this.rooms.get(roomId);
  }

  getUserRooms(clientId: string): string[] {
    return Array.from(this.userRooms.get(clientId) || []);
  }

  getAllRooms(): CollaborationRoom[] {
    return Array.from(this.rooms.values());
  }

  cleanup(): void {
    // Clean up old rooms and history
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    for (const [roomId, room] of this.rooms.entries()) {
      if (now - room.lastActivity.getTime() > maxAge && room.participants.size === 0) {
        this.rooms.delete(roomId);
      } else {
        // Keep only recent history
        room.history = room.history.filter(event => now - event.timestamp.getTime() < maxAge);
      }
    }
  }
}

// Main Enhanced PreviewSocket Service
export class EnhancedPreviewSocketService extends EventEmitter {
  private static instance: EnhancedPreviewSocketService;
  private io: SocketIOServer | null = null;
  private connectedClients = new Map<string, ClientInfo>();
  private messageQueue = new PriorityMessageQueue();
  private performanceMonitor = new AdvancedPerformanceMonitor();
  private collaborationManager = new CollaborationManager();
  private broadcastThrottle = new Map<string, NodeJS.Timeout>();
  private metricsInterval: NodeJS.Timeout | null = null;
  private cleanupInterval: NodeJS.Timeout | null = null;
  private aiInsights: AIInsight[] = [];
  private securityAlerts: SecurityAlert[] = [];
  private startTime = Date.now();

  private metrics: HighPreviewMetrics = {
    totalConnections: 0,
    activeConnections: 0,
    totalMessages: 0,
    totalErrors: 0,
    averageLatency: 0,
    peakConnections: 0,
    messageRate: 0,
    errorRate: 0,
    uptime: 0,
    lastEventTimestamp: new Date(),
    bandwidthUsage: { incoming: 0, outgoing: 0 },
    connectionsByOrigin: new Map(),
    performanceStats: { cpu: 0, memory: 0, eventLoopDelay: 0 },
    collaborationStats: {
      activeRooms: 0,
      totalRooms: 0,
      activeCollaborators: 0,
      editsPerMinute: 0,
      conflictResolutions: 0
    },
    aiInsights: {
      generated: 0,
      applied: 0,
      dismissed: 0,
      averageConfidence: 0
    },
    securityMetrics: {
      threatsBlocked: 0,
      vulnerabilitiesDetected: 0,
      riskScore: 0,
      lastScan: new Date()
    }
  };

  private config: PreviewSocketConfig;

  private constructor() {
    super();
    this.setMaxListeners(100);
    this.config = PreviewSocketConfigSchema.parse({});
  }

  public static getInstance(): EnhancedPreviewSocketService {
    if (!EnhancedPreviewSocketService.instance) {
      EnhancedPreviewSocketService.instance = new EnhancedPreviewSocketService();
    }
    return EnhancedPreviewSocketService.instance;
  }

  public initialize(server: ServerType, options: Partial<PreviewSocketConfig> = {}): void {
    if (this.io) {
      console.warn("Preview socket already initialized");
      return;
    }

    this.config = PreviewSocketConfigSchema.parse({ ...this.config, ...options });

    this.io = new SocketIOServer(server, {
      cors: {
        origin: this.config.allowedOrigins,
        methods: ["GET", "POST"],
        credentials: true,
      },
      pingInterval: this.config.pingInterval,
      pingTimeout: this.config.pingTimeout,
      maxHttpBufferSize: this.config.maxHttpBufferSize,
      compression: this.config.enableCompression,
      transports: ["websocket", "polling"],
      allowEIO3: true,
    });

    this.setupMiddleware();
    this.setupConnectionHandlers();
    this.setupCollaborationHandlers();
    this.startMetricsCollection();
    this.startCleanupProcess();
    this.processMessageQueue();

    console.log("Enhanced High Preview WebSocket server initialized", {
      options: this.config,
      timestamp: new Date().toISOString(),
    });

    this.emit('service:initialized', { config: this.config });
  }

  private setupMiddleware(): void {
    if (!this.io) return;

    this.io.use(async (socket, next) => {
      try {
        const startTime = Date.now();
        
        // Origin validation
        const origin = socket.handshake.headers.origin;
        if (this.config.enableSecurity && !this.validateOrigin(origin)) {
          this.emit('security:violation', {
            clientId: socket.id,
            violation: 'invalid_origin',
            severity: 'medium' as const,
          });
          return next(new Error("Origin not allowed"));
        }

        // Connection limit check
        if (this.connectedClients.size >= this.config.maxConnections) {
          this.emit('capacity:limit', {
            current: this.connectedClients.size,
            limit: this.config.maxConnections,
          });
          return next(new Error("Connection limit exceeded"));
        }

        this.performanceMonitor.recordEventProcessingTime(Date.now() - startTime);
        next();
      } catch (error) {
        this.emit('error:occurred', { error: error as Error, context: { phase: 'middleware' } });
        next(error);
      }
    });
  }

  private validateOrigin(origin: string | undefined): boolean {
    if (!origin) return false;
    
    const allowedOrigins = Array.isArray(this.config.allowedOrigins) 
      ? this.config.allowedOrigins 
      : [this.config.allowedOrigins];
    
    return allowedOrigins.includes("*") || allowedOrigins.includes(origin);
  }

  private setupConnectionHandlers(): void {
    if (!this.io) return;

    this.io.on("connection", (socket: Socket) => {
      const clientInfo = this.createClientInfo(socket);
      this.addClient(socket.id, clientInfo);

      console.log(`Client connected: ${socket.id}`, { 
        clientInfo: this.sanitizeClientInfo(clientInfo),
        totalConnections: this.metrics.totalConnections,
        activeConnections: this.metrics.activeConnections,
      });

      this.emit('client:connected', { clientInfo });
      this.setupClientHandlers(socket, clientInfo);
    });
  }

  private createClientInfo(socket: Socket): ClientInfo {
    const now = new Date();
    return {
      id: socket.id,
      connectedAt: now,
      lastActivity: now,
      userAgent: socket.handshake.headers["user-agent"],
      ipAddress: socket.handshake.address,
      origin: socket.handshake.headers.origin,
      version: socket.handshake.query.version as string,
      latencySamples: [],
      messageCount: 0,
      errorCount: 0,
      bytesReceived: 0,
      bytesSent: 0,
      authenticated: false,
      capabilities: new Set(),
      metadata: {},
      rooms: new Set(),
      presence: 'active',
      role: 'viewer',
      permissions: new Set(['read'])
    };
  }

  private addClient(socketId: string, clientInfo: ClientInfo): void {
    this.connectedClients.set(socketId, clientInfo);
    this.metrics.totalConnections++;
    this.metrics.activeConnections = this.connectedClients.size;
    this.metrics.peakConnections = Math.max(this.metrics.peakConnections, this.metrics.activeConnections);

    if (clientInfo.origin) {
      const currentCount = this.metrics.connectionsByOrigin.get(clientInfo.origin) || 0;
      this.metrics.connectionsByOrigin.set(clientInfo.origin, currentCount + 1);
    }
  }

  private setupClientHandlers(socket: Socket, clientInfo: ClientInfo): void {
    // Heartbeat/Ping handling
    socket.on("pong", (latency: number) => {
      this.handlePong(clientInfo, latency);
    });

    // Authentication
    socket.on("authenticate", (data: any) => {
      this.handleAuthentication(socket, clientInfo, data);
    });

    // File change events
    socket.on("file:changed", (data: any) => {
      this.handleFileChange(socket, clientInfo, data);
    });

    // Build events
    socket.on("build:trigger", (data: any) => {
      this.handleBuildTrigger(socket, clientInfo, data);
    });

    // Collaboration events
    socket.on("collab:join", (data: any) => {
      this.handleCollabJoin(socket, clientInfo, data);
    });

    socket.on("collab:leave", (data: any) => {
      this.handleCollabLeave(socket, clientInfo, data);
    });

    socket.on("collab:edit", (data: any) => {
      this.handleCollabEdit(socket, clientInfo, data);
    });

    socket.on("collab:cursor", (data: any) => {
      this.handleCollabCursor(socket, clientInfo, data);
    });

    // AI events
    socket.on("ai:request", (data: any) => {
      this.handleAIRequest(socket, clientInfo, data);
    });

    // Disconnect handling
    socket.on("disconnect", (reason: string) => {
      this.handleDisconnect(socket, clientInfo, reason);
    });

    // Error handling
    socket.on("error", (error: Error) => {
      this.handleClientError(socket, clientInfo, error);
    });
  }

  private setupCollaborationHandlers(): void {
    this.collaborationManager.on('room:created', (data) => {
      this.broadcastToRoom(data.room.id, 'collab:room:created', data);
    });

    this.collaborationManager.on('room:joined', (data) => {
      this.broadcastToRoom(data.roomId, 'collab:user:joined', data);
    });

    this.collaborationManager.on('room:left', (data) => {
      this.broadcastToRoom(data.roomId, 'collab:user:left', data);
    });

    this.collaborationManager.on('collaboration:edit', (data) => {
      this.broadcastToRoom(data.roomId, 'collab:edit', data, [data.clientId]);
    });

    this.collaborationManager.on('collaboration:cursor', (data) => {
      this.broadcastToRoom(data.roomId, 'collab:cursor', data, [data.clientId]);
    });
  }

  private handlePong(clientInfo: ClientInfo, latency: number): void {
    clientInfo.latencySamples.push(latency);
    if (clientInfo.latencySamples.length > 10) {
      clientInfo.latencySamples = clientInfo.latencySamples.slice(-5);
    }
    clientInfo.lastActivity = new Date();
    clientInfo.presence = 'active';
    
    this.performanceMonitor.recordLatency(latency);
  }

  private handleAuthentication(socket: Socket, clientInfo: ClientInfo, data: any): void {
    try {
      // Validate authentication data
      if (data.token) {
        // In a real implementation, validate the JWT token
        clientInfo.authenticated = true;
        clientInfo.user = data.user;
        clientInfo.role = data.role || 'collaborator';
        clientInfo.permissions = new Set(data.permissions || ['read', 'write']);
        
        socket.emit('auth:success', { clientId: clientInfo.id });
        this.emit('client:authenticated', { clientId: clientInfo.id, metadata: data });
      } else {
        socket.emit('auth:failed', { error: 'Invalid credentials' });
      }
    } catch (error) {
      this.handleClientError(socket, clientInfo, error as Error);
    }
  }

  private handleFileChange(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const message: PreviewMessage = {
      type: 'file:changed',
      payload: data,
      timestamp: new Date().toISOString(),
      id: crypto.randomUUID(),
      priority: 'high',
      metadata: { clientId: clientInfo.id }
    };

    this.messageQueue.enqueue(message);
    this.performanceMonitor.recordMessage();
  }

  private handleBuildTrigger(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const message: PreviewMessage = {
      type: 'build:started',
      payload: {
        buildId: crypto.randomUUID(),
        timestamp: new Date(),
        triggeredBy: clientInfo.id,
        ...data
      },
      timestamp: new Date().toISOString(),
      id: crypto.randomUUID(),
      priority: 'critical'
    };

    this.messageQueue.enqueue(message);
    this.broadcastToAll('build:started', message.payload);
  }

  private handleCollabJoin(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const { roomId, roomName } = data;
    
    if (clientInfo.rooms.size >= this.config.maxRoomsPerClient) {
      socket.emit('collab:error', { error: 'Maximum rooms exceeded' });
      return;
    }

    // Create room if it doesn't exist
    if (!this.collaborationManager.getRoom(roomId)) {
      this.collaborationManager.createRoom(roomId, roomName, clientInfo.id);
    }

    if (this.collaborationManager.joinRoom(roomId, clientInfo.id)) {
      clientInfo.rooms.add(roomId);
      socket.join(roomId);
      socket.emit('collab:joined', { roomId, participants: this.getRoomParticipants(roomId) });
    } else {
      socket.emit('collab:error', { error: 'Failed to join room' });
    }
  }

  private handleCollabLeave(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const { roomId } = data;
    
    if (this.collaborationManager.leaveRoom(roomId, clientInfo.id)) {
      clientInfo.rooms.delete(roomId);
      socket.leave(roomId);
      socket.emit('collab:left', { roomId });
    }
  }

  private handleCollabEdit(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const { roomId, operation } = data;
    
    if (!clientInfo.rooms.has(roomId)) {
      socket.emit('collab:error', { error: 'Not in room' });
      return;
    }

    const transform: OperationalTransform = {
      id: crypto.randomUUID(),
      clientId: clientInfo.id,
      operation: operation.type,
      position: operation.position,
      content: operation.content,
      length: operation.length,
      timestamp: new Date(),
      applied: false
    };

    this.collaborationManager.applyEdit(roomId, clientInfo.id, transform);
  }

  private handleCollabCursor(socket: Socket, clientInfo: ClientInfo, data: any): void {
    const { roomId, cursor } = data;
    
    if (!clientInfo.rooms.has(roomId)) return;

    const position: CursorPosition = {
      file: cursor.file,
      line: cursor.line,
      column: cursor.column,
      timestamp: new Date()
    };

    this.collaborationManager.updateCursor(roomId, clientInfo.id, position);
  }

  private handleAIRequest(socket: Socket, clientInfo: ClientInfo, data: any): void {
    // Generate AI insight
    const insight: AIInsight = {
      id: crypto.randomUUID(),
      type: data.type || 'suggestion',
      priority: data.priority || 'medium',
      title: data.title || 'AI Suggestion',
      description: data.description || '',
      recommendation: data.recommendation || '',
      implementation: data.implementation || '',
      impact: 'positive',
      confidence: Math.random() * 0.3 + 0.7, // 70-100%
      tags: data.tags || [],
      timestamp: new Date(),
      resolved: false,
      automatable: data.automatable || false,
      appliedCount: 0,
      dismissedCount: 0
    };

    this.aiInsights.push(insight);
    this.metrics.aiInsights.generated++;

    socket.emit('ai:insight', insight);
    this.emit('ai:insight:generated', { insight, clientId: clientInfo.id });
  }

  private handleDisconnect(socket: Socket, clientInfo: ClientInfo, reason: string): void {
    const duration = Date.now() - clientInfo.connectedAt.getTime();
    
    // Leave all collaboration rooms
    for (const roomId of clientInfo.rooms) {
      this.collaborationManager.leaveRoom(roomId, clientInfo.id);
    }

    this.connectedClients.delete(socket.id);
    this.metrics.activeConnections = this.connectedClients.size;

    if (clientInfo.origin) {
      const currentCount = this.metrics.connectionsByOrigin.get(clientInfo.origin) || 0;
      if (currentCount > 1) {
        this.metrics.connectionsByOrigin.set(clientInfo.origin, currentCount - 1);
      } else {
        this.metrics.connectionsByOrigin.delete(clientInfo.origin);
      }
    }

    console.log(`Client disconnected: ${socket.id}`, { reason, duration });
    this.emit('client:disconnected', { clientId: socket.id, duration });
  }

  private handleClientError(socket: Socket, clientInfo: ClientInfo, error: Error): void {
    clientInfo.errorCount++;
    this.metrics.totalErrors++;
    this.performanceMonitor.recordError();

    console.error(`Client error: ${socket.id}`, error);
    this.emit('error:occurred', { error, context: { clientId: socket.id } });
  }

  private sanitizeClientInfo(clientInfo: ClientInfo): Partial<ClientInfo> {
    return {
      id: clientInfo.id,
      connectedAt: clientInfo.connectedAt,
      userAgent: clientInfo.userAgent,
      origin: clientInfo.origin,
      authenticated: clientInfo.authenticated,
      messageCount: clientInfo.messageCount,
      presence: clientInfo.presence,
      role: clientInfo.role
    };
  }

  private getRoomParticipants(roomId: string): string[] {
    const room = this.collaborationManager.getRoom(roomId);
    return room ? Array.from(room.participants) : [];
  }

  private broadcastToRoom(roomId: string, event: string, data: any, excludeClients: string[] = []): void {
    if (!this.io) return;

    this.io.to(roomId).except(excludeClients).emit(event, data);
  }

  private broadcastToAll(event: string, data: any, excludeClients: string[] = []): void {
    if (!this.io) return;

    const broadcast = excludeClients.length > 0 
      ? this.io.except(excludeClients)
      : this.io;
    
    broadcast.emit(event, data);
  }

  private processMessageQueue(): void {
    const processNext = () => {
      const message = this.messageQueue.dequeue();
      if (message) {
        this.processMessage(message);
      }
      
      // Continue processing
      setTimeout(processNext, 10);
    };

    processNext();
  }

  private processMessage(message: PreviewMessage): void {
    try {
      if (message.targetRooms?.length) {
        message.targetRooms.forEach(roomId => {
          this.broadcastToRoom(roomId, message.type, message.payload);
        });
      } else if (message.targetClients?.length) {
        message.targetClients.forEach(clientId => {
          this.io?.to(clientId).emit(message.type, message.payload);
        });
      } else {
        this.broadcastToAll(message.type, message.payload);
      }

      this.metrics.totalMessages++;
      this.performanceMonitor.recordMessage();
    } catch (error) {
      this.performanceMonitor.recordError();
      this.emit('error:occurred', { error: error as Error, context: { message } });
    }
  }

  private startMetricsCollection(): void {
    this.metricsInterval = setInterval(() => {
      this.updateMetrics();
      this.emit('metrics:updated', { metrics: this.metrics });
    }, this.config.metricsInterval);
  }

  private startCleanupProcess(): void {
    this.cleanupInterval = setInterval(() => {
      this.collaborationManager.cleanup();
      this.cleanupOldInsights();
      this.cleanupOldAlerts();
    }, 300000); // Every 5 minutes
  }

  private updateMetrics(): void {
    this.metrics.uptime = this.performanceMonitor.getUptime();
    this.metrics.averageLatency = this.performanceMonitor.getAverageLatency();
    this.metrics.messageRate = this.performanceMonitor.getMessageRate();
    this.metrics.errorRate = this.performanceMonitor.getErrorRate();
    this.metrics.lastEventTimestamp = new Date();

    // Update collaboration stats
    const rooms = this.collaborationManager.getAllRooms();
    this.metrics.collaborationStats.activeRooms = rooms.filter(r => r.participants.size > 0).length;
    this.metrics.collaborationStats.totalRooms = rooms.length;
    this.metrics.collaborationStats.activeCollaborators = this.connectedClients.size;

    // Update AI insights stats
    const recentInsights = this.aiInsights.filter(i => Date.now() - i.timestamp.getTime() < 300000);
    this.metrics.aiInsights.averageConfidence = recentInsights.length > 0
      ? recentInsights.reduce((sum, i) => sum + i.confidence, 0) / recentInsights.length
      : 0;

    // Update performance stats
    const memUsage = process.memoryUsage();
    this.metrics.performanceStats.memory = memUsage.heapUsed / 1024 / 1024; // MB
  }

  private cleanupOldInsights(): void {
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    const now = Date.now();
    
    this.aiInsights = this.aiInsights.filter(insight => 
      now - insight.timestamp.getTime() < maxAge
    );
  }

  private cleanupOldAlerts(): void {
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    const now = Date.now();
    
    this.securityAlerts = this.securityAlerts.filter(alert => 
      now - alert.timestamp.getTime() < maxAge
    );
  }

  // Public API methods
  public broadcast(event: PreviewEvent, data: any, options?: {
    priority?: PreviewMessage['priority'];
    targetRooms?: string[];
    targetClients?: string[];
  }): void {
    const message: PreviewMessage = {
      type: event,
      payload: data,
      timestamp: new Date().toISOString(),
      id: crypto.randomUUID(),
      priority: options?.priority || 'normal',
      targetRooms: options?.targetRooms,
      targetClients: options?.targetClients
    };

    this.messageQueue.enqueue(message);
  }

  public getMetrics(): HighPreviewMetrics {
    return { ...this.metrics };
  }

  public getConnectedClients(): ClientInfo[] {
    return Array.from(this.connectedClients.values());
  }

  public getCollaborationRooms(): CollaborationRoom[] {
    return this.collaborationManager.getAllRooms();
  }

  public getAIInsights(): AIInsight[] {
    return [...this.aiInsights];
  }

  public getSecurityAlerts(): SecurityAlert[] {
    return [...this.securityAlerts];
  }

  public disconnect(): void {
    if (this.metricsInterval) {
      clearInterval(this.metricsInterval);
    }
    
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }

    if (this.io) {
      this.io.close();
      this.io = null;
    }

    this.connectedClients.clear();
    this.messageQueue.clear();
    
    console.log("Enhanced Preview WebSocket server disconnected");
    this.emit('service:disconnected');
  }
}

// Export singleton instance
export const previewSocket = EnhancedPreviewSocketService.getInstance();