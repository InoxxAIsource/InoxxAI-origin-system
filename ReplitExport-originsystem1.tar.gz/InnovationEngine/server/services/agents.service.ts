import { runMultiAgentTask } from "../agents/index";

export async function executeMultiAgent(userPrompt: string) {
  const result = await runMultiAgentTask(userPrompt);
  return result;
}