// Self-Healing Multi-Agent Loop
import { EventEmitter } from "events";
import { generateCode } from "./simpleCodeAgent";
import { dbSchemaAgent } from "./dbSchemaAgent";
import OpenAI from "openai";

interface TaskItem {
  id: string;
  type: 'component' | 'api' | 'database' | 'deployment' | 'test';
  description: string;
  priority: 'high' | 'medium' | 'low';
  dependencies: string[];
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
}

interface PlannerOutput {
  projectType: string;
  tasks: TaskItem[];
  architecture: string;
  frameworks: string[];
  dependencies: string[];
  testStrategy: string;
  estimatedComplexity: 'simple' | 'moderate' | 'complex';
}

interface ValidationResult {
  passed: boolean;
  errors: string[];
  warnings: string[];
  coverage?: number;
}

interface LoopConfig {
  maxRetries?: number;
  validationTimeout?: number;
  bailOnCriticalError?: boolean;
  enableMetrics?: boolean;
}

export class SelfHealingLoop extends EventEmitter {
  private retries = 0;
  private config: Required<LoopConfig>;
  private openai: OpenAI;
  private generatedFiles: Map<string, string> = new Map();
  private installedDependencies: string[] = [];
  private currentPlan: PlannerOutput | null = null;

  static DEFAULT_CONFIG: Required<LoopConfig> = {
    maxRetries: 3,
    validationTimeout: 30000,
    bailOnCriticalError: true,
    enableMetrics: true
  };

  constructor(config: LoopConfig = {}) {
    super();
    this.config = { ...SelfHealingLoop.DEFAULT_CONFIG, ...config };
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.setupEventListeners();
  }

  private setupEventListeners() {
    this.on('phase:start', (phase) => console.log(`Starting phase: ${phase}`));
    this.on('phase:complete', (phase) => console.log(`Completed phase: ${phase}`));
    this.on('retry', (attempt) => console.log(`Retry attempt ${attempt}/${this.config.maxRetries}`));
    this.on('error', (error, phase) => console.error(`Error in ${phase}:`, error.message));
  }

  // 1️⃣ Planner Agent - Creates comprehensive task breakdown
  private async runPlannerAgent(userPrompt: string): Promise<PlannerOutput> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert software architect and project planner. 
          Create a detailed project plan with specific tasks, dependencies, and architecture decisions.
          
          Return a JSON object with:
          - projectType: The type of project (e.g., "react-app", "api-server", "fullstack")
          - tasks: Array of specific tasks with id, type, description, priority, dependencies, status
          - architecture: High-level architecture description
          - frameworks: Required frameworks and libraries
          - dependencies: Package dependencies needed
          - testStrategy: Testing approach and tools
          - estimatedComplexity: Project complexity level
          
          Make tasks specific and actionable. Include proper dependency ordering.`
        },
        {
          role: "user",
          content: userPrompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const plan = JSON.parse(response.choices[0].message.content);
    console.log('Project Plan Created:', {
      type: plan.projectType,
      taskCount: plan.tasks?.length || 0,
      complexity: plan.estimatedComplexity
    });

    return plan;
  }

  // 2️⃣ Code Writer Agent - Enhanced with task-specific generation
  private async runCodeWriterAgent(plan: PlannerOutput): Promise<void> {
    const codeTasks = plan.tasks.filter(task => 
      task.type === 'component' || task.type === 'api'
    );

    for (const task of codeTasks) {
      try {
        task.status = 'in-progress';
        
        const result = await generateCode(
          task.description,
          plan.projectType,
          this.getExistingCodeContext()
        );

        this.generatedFiles.set(task.id, result.code);
        task.status = 'completed';
        
        console.log(`Generated code for task: ${task.description}`);
      } catch (error) {
        task.status = 'failed';
        throw new Error(`Code generation failed for task ${task.id}: ${(error as Error).message}`);
      }
    }
  }

  // 3️⃣ Dependency Agent - Smart package management
  private async runDependencyAgent(plan: PlannerOutput): Promise<void> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o", 
      messages: [
        {
          role: "system",
          content: `You are a package management expert. Analyze the project requirements and provide:
          1. Essential dependencies with exact versions
          2. Dev dependencies for development and testing
          3. Installation order (some packages need to be installed first)
          4. Any post-install configuration steps needed
          
          Return JSON with: { "dependencies": [], "devDependencies": [], "installOrder": [], "postInstall": [] }`
        },
        {
          role: "user", 
          content: `Project: ${plan.projectType}, Frameworks: ${plan.frameworks.join(', ')}, Base deps: ${plan.dependencies.join(', ')}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const depPlan = JSON.parse(response.choices[0].message.content);
    
    // Simulate dependency installation
    this.installedDependencies = [
      ...depPlan.dependencies || [],
      ...depPlan.devDependencies || []
    ];
    
    console.log(`Installed ${this.installedDependencies.length} dependencies`);
  }

  // 4️⃣ Database Schema Agent - Enhanced with relationships
  private async runDBSchemaAgent(plan: PlannerOutput): Promise<void> {
    const dbTasks = plan.tasks.filter(task => task.type === 'database');
    
    if (dbTasks.length === 0) {
      console.log('No database tasks found, skipping schema generation');
      return;
    }

    try {
      const schemaRequirements = {
        projectName: plan.projectType,
        databasePattern: "monolithic" as const,
        complexity: plan.estimatedComplexity === 'simple' ? "simple" as const : 
                   plan.estimatedComplexity === 'complex' ? "complex" as const : "moderate" as const,
        consistency: "acid" as const,
        expectedScale: {
          users: plan.estimatedComplexity === 'simple' ? 1000 : 
                plan.estimatedComplexity === 'complex' ? 100000 : 10000,
          transactionsPerSecond: 100,
          dataGrowthGBPerMonth: 10
        },
        features: dbTasks.map(task => task.description),
        compliance: [] as const
      };

      const schemaResult = await dbSchemaAgent.generateSchema(schemaRequirements);
      
      // Store generated schema
      this.generatedFiles.set('database-schema', schemaResult.web2Schema.models);
      this.generatedFiles.set('database-migrations', schemaResult.web2Schema.migrations);
      
      console.log('Database schema and migrations generated');
    } catch (error) {
      throw new Error(`Database schema generation failed: ${(error as Error).message}`);
    }
  }

  // 5️⃣ Deployment Agent - Container and cloud deployment
  private async runDeploymentAgent(plan: PlannerOutput): Promise<void> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a DevOps engineer. Create deployment configurations for the project.
          Generate: Dockerfile, docker-compose.yml, deployment scripts, environment configs.
          Consider: ${plan.projectType}, dependencies: ${this.installedDependencies.join(', ')}
          
          Return JSON with deployment files and their contents.`
        },
        {
          role: "user",
          content: `Create deployment config for: ${plan.projectType} with complexity: ${plan.estimatedComplexity}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const deploymentConfig = JSON.parse(response.choices[0].message.content);
    
    // Store deployment files
    Object.entries(deploymentConfig).forEach(([filename, content]) => {
      this.generatedFiles.set(`deployment-${filename}`, content as string);
    });
    
    console.log('Deployment configurations generated');
  }

  // 6️⃣ Test Writer Agent - Comprehensive test suite
  private async runTestWriterAgent(plan: PlannerOutput): Promise<void> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a testing expert. Generate comprehensive tests including:
          - Unit tests for components/functions
          - Integration tests for APIs
          - End-to-end tests for user workflows
          - Performance tests for critical paths
          
          Use modern testing frameworks and best practices.
          Return JSON with test files and their content.`
        },
        {
          role: "user",
          content: `Generate tests for: ${plan.projectType}, Strategy: ${plan.testStrategy}, Generated files: ${Array.from(this.generatedFiles.keys()).join(', ')}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const testSuite = JSON.parse(response.choices[0].message.content);
    
    // Store test files
    Object.entries(testSuite).forEach(([filename, content]) => {
      this.generatedFiles.set(`test-${filename}`, content as string);
    });
    
    console.log(`Generated ${Object.keys(testSuite).length} test files`);
  }

  // 7️⃣ Test Executor - Real validation
  private async runTestExecutor(): Promise<ValidationResult> {
    const testFiles = Array.from(this.generatedFiles.keys()).filter(key => key.startsWith('test-'));
    
    if (testFiles.length === 0) {
      return { passed: true, errors: [], warnings: ['No tests to execute'] };
    }

    try {
      const errors: string[] = [];
      const warnings: string[] = [];
      
      // Validate code syntax and structure
      for (const [filename, content] of this.generatedFiles.entries()) {
        if (!content.trim()) {
          errors.push(`Empty file: ${filename}`);
        }
        
        // Basic syntax validation
        if (filename.includes('.js') || filename.includes('.ts')) {
          if (!content.includes('export') && !content.includes('module.exports')) {
            warnings.push(`No exports found in ${filename}`);
          }
        }
      }

      // Check dependencies are properly installed
      const missingDeps = this.validateDependencies();
      if (missingDeps.length > 0) {
        errors.push(`Missing dependencies: ${missingDeps.join(', ')}`);
      }

      const passed = errors.length === 0;
      
      console.log(`Test Execution: ${passed ? 'PASSED' : 'FAILED'}`);
      if (errors.length > 0) console.log('Errors:', errors);
      if (warnings.length > 0) console.log('Warnings:', warnings);

      return { passed, errors, warnings, coverage: passed ? 85 : 0 };
    } catch (error) {
      return { 
        passed: false, 
        errors: [`Test execution failed: ${(error as Error).message}`], 
        warnings: [] 
      };
    }
  }

  // 8️⃣ Error Resolver Agent - Intelligent problem solving
  private async runErrorResolverAgent(validationResult: ValidationResult): Promise<void> {
    if (validationResult.passed) return;

    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert debugging and error resolution agent. 
          Analyze the errors and provide specific fixes for the code.
          
          Return JSON with:
          - fixes: Array of specific changes to make
          - filesToUpdate: Files that need modification
          - newDependencies: Additional packages needed
          - explanation: Why these errors occurred and how fixes address them`
        },
        {
          role: "user",
          content: `Errors: ${validationResult.errors.join(', ')}
          Warnings: ${validationResult.warnings.join(', ')}
          Current files: ${Array.from(this.generatedFiles.keys()).join(', ')}
          Dependencies: ${this.installedDependencies.join(', ')}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const fixes = JSON.parse(response.choices[0].message.content);
    
    // Apply fixes to generated files
    for (const fix of fixes.fixes || []) {
      if (fix.filename && fix.newContent) {
        this.generatedFiles.set(fix.filename, fix.newContent);
        console.log(`Applied fix to ${fix.filename}`);
      }
    }

    // Install additional dependencies if needed
    if (fixes.newDependencies?.length > 0) {
      this.installedDependencies.push(...fixes.newDependencies);
      console.log(`Added dependencies: ${fixes.newDependencies.join(', ')}`);
    }

    console.log(`Applied ${fixes.fixes?.length || 0} fixes`);
  }

  // Helper methods
  private getExistingCodeContext(): string {
    return Array.from(this.generatedFiles.values()).join('\n\n');
  }

  private validateDependencies(): string[] {
    const required = ['react', 'typescript'];
    return required.filter(dep => !this.installedDependencies.includes(dep));
  }

  private async executePhase<T>(phase: string, fn: () => Promise<T>): Promise<T> {
    this.emit('phase:start', phase);
    
    try {
      const result = await Promise.race([
        fn(),
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(new Error(`Phase ${phase} timed out`)), this.config.validationTimeout)
        )
      ]);
      
      this.emit('phase:complete', phase);
      return result;
    } catch (error) {
      this.emit('error', error, phase);
      throw error;
    }
  }

  // Main execution loop
  public async execute(userPrompt: string): Promise<{
    success: boolean;
    generatedFiles: Map<string, string>;
    metrics: any;
  }> {
    console.log("Starting Self-Healing Multi-Agent Loop");
    const startTime = Date.now();

    try {
      // Step 1: Create comprehensive plan
      this.currentPlan = await this.executePhase('planning', () => 
        this.runPlannerAgent(userPrompt)
      );

      // Main loop with retry mechanism
      while (this.retries < this.config.maxRetries) {
        try {
          console.log(`Loop Iteration #${this.retries + 1}`);

          // Step 2: Generate code
          await this.executePhase('code-generation', () =>
            this.runCodeWriterAgent(this.currentPlan!)
          );

          // Step 3: Manage dependencies
          await this.executePhase('dependency-management', () =>
            this.runDependencyAgent(this.currentPlan!)
          );

          // Step 4: Generate database schema
          await this.executePhase('db-schema', () =>
            this.runDBSchemaAgent(this.currentPlan!)
          );

          // Step 5: Create deployment configs
          await this.executePhase('deployment', () =>
            this.runDeploymentAgent(this.currentPlan!)
          );

          // Step 6: Generate comprehensive tests
          await this.executePhase('test-generation', () =>
            this.runTestWriterAgent(this.currentPlan!)
          );

          // Step 7: Execute validation
          const validationResult = await this.executePhase('validation', () =>
            this.runTestExecutor()
          );

          if (validationResult.passed) {
            console.log("All validations passed - project complete!");
            return {
              success: true,
              generatedFiles: this.generatedFiles,
              metrics: {
                duration: Date.now() - startTime,
                iterations: this.retries + 1,
                filesGenerated: this.generatedFiles.size,
                dependenciesInstalled: this.installedDependencies.length
              }
            };
          }

          // Step 8: Resolve errors and retry
          await this.executePhase('error-resolution', () =>
            this.runErrorResolverAgent(validationResult)
          );

        } catch (error) {
          console.error(`Loop iteration ${this.retries + 1} failed:`, (error as Error).message);
          if (this.retries === this.config.maxRetries - 1) {
            throw error;
          }
        }

        this.retries++;
        this.emit('retry', this.retries);
      }

      console.error(`Max retries (${this.config.maxRetries}) reached`);
      return {
        success: false,
        generatedFiles: this.generatedFiles,
        metrics: {
          duration: Date.now() - startTime,
          iterations: this.retries,
          filesGenerated: this.generatedFiles.size,
          dependenciesInstalled: this.installedDependencies.length,
          failure: 'Max retries exceeded'
        }
      };

    } catch (error) {
      console.error("Critical error in self-healing loop:", (error as Error).message);
      return {
        success: false,
        generatedFiles: this.generatedFiles,
        metrics: {
          duration: Date.now() - startTime,
          iterations: this.retries,
          filesGenerated: this.generatedFiles.size,
          dependenciesInstalled: this.installedDependencies.length,
          error: (error as Error).message
        }
      };
    }
  }
}

export default SelfHealingLoop;