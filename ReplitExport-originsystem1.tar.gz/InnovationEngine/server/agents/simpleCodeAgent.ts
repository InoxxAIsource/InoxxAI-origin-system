import OpenAI from "openai";

// Simple, reliable OpenAI code generation
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const generateCode = async (prompt: string, projectType: string = 'react', existingCode?: string): Promise<{
  code: string;
  type: string;
  dependencies: string[];
  description: string;
}> => {
  try {
    console.log(`Generating ${projectType} code for: ${prompt}`);
    
    // Detect if this is a modification request
    const isModification = prompt.toLowerCase().includes('add') && 
                          (prompt.toLowerCase().includes('to this') || 
                           prompt.toLowerCase().includes('to the page') ||
                           prompt.toLowerCase().includes('to current'));
    
    let systemPrompt = `You are an expert fullstack developer. `;
    
    if (isModification && existingCode) {
      systemPrompt += `The user wants to modify an existing React component. Here is the current code:

\`\`\`typescript
${existingCode}
\`\`\`

Please enhance this existing component by adding the requested feature. Keep all existing functionality and styling intact, only add the new feature the user requested. Do not create a completely new component or replace the existing one.

REQUIREMENTS:
- Preserve all existing components and their styling
- Add the requested feature seamlessly to the existing code
- Maintain the current layout and design
- Enhance, don't replace
- Keep the same component structure
- Use the same styling patterns already present`;
    } else {
      systemPrompt += `Generate complete, production-ready code based on the user's request.

REQUIREMENTS:
- Write fully functional, complete code - no placeholders or TODOs
- Use modern TypeScript and React patterns
- Include all necessary imports and dependencies
- Make the code self-contained and runnable
- Add proper error handling and validation
- Use responsive design with Tailwind CSS
- Generate clean, maintainable code structure

For React projects:
- Use functional components with hooks
- Include proper TypeScript types
- Add responsive styling with Tailwind
- Make components interactive and functional

For HTML projects:
- Create complete HTML documents
- Add inline CSS for styling
- Make it responsive and modern
- Include interactive JavaScript if needed`;
    }
    
    systemPrompt += `

Return only the code, no explanations or markdown formatting.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Generate a ${projectType} project: ${prompt}` }
      ],
      temperature: 0.15,
      max_tokens: 8192,
    });

    const code = response.choices[0]?.message?.content;
    
    if (!code) {
      throw new Error('No code generated');
    }

    console.log('Code generation successful');

    // Extract dependencies from imports
    const dependencies = extractDependencies(code);
    
    // Determine project type
    const type = detectProjectType(code, projectType);

    return {
      code: code.trim(),
      type,
      dependencies,
      description: `Generated ${type} project for: ${prompt}`
    };

  } catch (error) {
    console.error('Code generation error:', error);
    throw new Error(`Failed to generate code: ${error.message}`);
  }
};

// Extract dependencies from code
function extractDependencies(code: string): string[] {
  const dependencies: string[] = [];
  const importRegex = /import.*from\s+['"]([^'"]+)['"]/g;
  let match;
  
  while ((match = importRegex.exec(code)) !== null) {
    const dep = match[1];
    if (!dep.startsWith('./') && !dep.startsWith('../')) {
      dependencies.push(dep);
    }
  }
  
  return [...new Set(dependencies)];
}

// Detect project type from code content
function detectProjectType(code: string, requestedType: string): string {
  if (code.includes('import React') || code.includes('useState') || code.includes('useEffect')) {
    return 'react';
  }
  if (code.includes('<!DOCTYPE html>') || code.includes('<html')) {
    return 'html';
  }
  if (code.includes('<template>') || code.includes('Vue')) {
    return 'vue';
  }
  if (code.includes('<script>') && code.includes('Svelte')) {
    return 'svelte';
  }
  
  return requestedType;
}

export const healthCheck = async (): Promise<{ status: string; model: string }> => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: "Hello" }],
      max_tokens: 10,
    });
    
    return {
      status: response.choices[0]?.message?.content ? 'healthy' : 'error',
      model: 'gpt-4o'
    };
  } catch (error) {
    console.error('Health check failed:', error);
    return { status: 'error', model: 'gpt-4o' };
  }
};