import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// Configuration schema for deployment agent
const DeploymentAgentConfig = z.object({
  modelName: z.string().default("gpt-4o"),
  temperature: z.number().min(0).max(0.5).default(0.1),
  maxTokens: z.number().optional().default(6144),
  timeout: z.number().optional().default(60000),
  retries: z.number().optional().default(3),
});

type DeploymentAgentConfigType = z.infer<typeof DeploymentAgentConfig>;

// Deployment platform enums
export enum DeploymentPlatform {
  VERCEL = "vercel",
  NETLIFY = "netlify", 
  REPLIT = "replit",
  DOCKER = "docker",
  KUBERNETES = "kubernetes",
  AWS = "aws",
  GCP = "gcp",
  AZURE = "azure",
}

export enum Environment {
  DEVELOPMENT = "development",
  STAGING = "staging",
  PRODUCTION = "production",
  PREVIEW = "preview",
}

export enum ProjectType {
  NEXTJS = "nextjs",
  REACT = "react",
  VUE = "vue",
  SVELTE = "svelte",
  EXPRESS = "express",
  FASTIFY = "fastify",
  NESTJS = "nestjs",
}

export interface DeploymentConfig {
  platform: DeploymentPlatform;
  environment: Environment;
  projectType: ProjectType;
  buildSettings: {
    buildCommand?: string;
    outputDirectory?: string;
    installCommand?: string;
    devCommand?: string;
    nodeVersion?: string;
  };
  environmentVariables: Record<string, string>;
  domains?: string[];
  monitoring?: boolean;
  scaling?: {
    minInstances: number;
    maxInstances: number;
    targetCPU: number;
  };
}

export interface DeploymentResult {
  success: boolean;
  deploymentId?: string;
  url?: string;
  previewUrl?: string;
  error?: string;
  buildTime?: number;
  logs: string[];
}

// Configuration generators
class ConfigurationGenerator {
  static generateVercelConfig(projectType: ProjectType, config: DeploymentConfig) {
    const baseConfig = {
      version: 2,
      framework: projectType,
      buildCommand: config.buildSettings.buildCommand || this.getDefaultBuildCommand(projectType),
      outputDirectory: config.buildSettings.outputDirectory || this.getDefaultOutputDirectory(projectType),
      installCommand: config.buildSettings.installCommand || "npm install",
      devCommand: config.buildSettings.devCommand || "npm run dev",
      env: config.environmentVariables,
    };

    return baseConfig;
  }

  static generateDockerfile(projectType: ProjectType, config: DeploymentConfig): string {
    const nodeVersion = config.buildSettings.nodeVersion || "18-alpine";
    const port = 3000;

    switch (projectType) {
      case ProjectType.NEXTJS:
        return `
FROM node:${nodeVersion} AS base
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force

FROM node:${nodeVersion} AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:${nodeVersion} AS runtime
WORKDIR /app
ENV NODE_ENV=production
COPY --from=base /app/node_modules ./node_modules
COPY --from=build /app/.next ./.next
COPY --from=build /app/public ./public
COPY --from=build /app/package.json ./package.json

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs
RUN chown -R nextjs:nodejs /app
USER nextjs

EXPOSE ${port}
CMD ["npm", "start"]
        `.trim();

      case ProjectType.REACT:
        return `
FROM node:${nodeVersion} AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine AS runtime
COPY --from=build /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
        `.trim();

      case ProjectType.EXPRESS:
        return `
FROM node:${nodeVersion}
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force
COPY . .

RUN addgroup --system --gid 1001 appuser
RUN adduser --system --uid 1001 appuser
RUN chown -R appuser:appuser /app
USER appuser

EXPOSE ${port}
CMD ["npm", "start"]
        `.trim();

      default:
        return `
FROM node:${nodeVersion}
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE ${port}
CMD ["npm", "start"]
        `.trim();
    }
  }

  static generateGitHubWorkflow(config: DeploymentConfig): string {
    return `
name: Deploy to ${config.platform}

on:
  push:
    branches: [main, master]
  pull_request:
    branches: [main, master]

env:
  NODE_VERSION: '${config.buildSettings.nodeVersion || '18'}'

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run tests
        run: npm test
      
      - name: Run linting
        run: npm run lint
      
      - name: Type check
        run: npm run type-check

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Build application
        run: ${config.buildSettings.buildCommand || 'npm run build'}
        env:${Object.entries(config.environmentVariables).map(([key, value]) => 
          `\n          ${key}: \${{ secrets.${key} }}`
        ).join('')}
      
      - name: Deploy to ${config.platform}
        uses: ${this.getDeployAction(config.platform)}
        with:
          ${this.getDeployActionConfig(config.platform)}
    `.trim();
  }

  private static getDefaultBuildCommand(projectType: ProjectType): string {
    switch (projectType) {
      case ProjectType.NEXTJS:
        return "npm run build";
      case ProjectType.REACT:
        return "npm run build";
      case ProjectType.VUE:
        return "npm run build";
      case ProjectType.SVELTE:
        return "npm run build";
      default:
        return "npm run build";
    }
  }

  private static getDefaultOutputDirectory(projectType: ProjectType): string {
    switch (projectType) {
      case ProjectType.NEXTJS:
        return ".next";
      case ProjectType.REACT:
        return "build";
      case ProjectType.VUE:
        return "dist";
      case ProjectType.SVELTE:
        return "build";
      default:
        return "dist";
    }
  }

  private static getDeployAction(platform: DeploymentPlatform): string {
    switch (platform) {
      case DeploymentPlatform.VERCEL:
        return "amondnet/vercel-action@v25";
      case DeploymentPlatform.NETLIFY:
        return "netlify/actions/cli@master";
      default:
        return "actions/deploy@v1";
    }
  }

  private static getDeployActionConfig(platform: DeploymentPlatform): string {
    switch (platform) {
      case DeploymentPlatform.VERCEL:
        return `vercel-token: \${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: \${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: \${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'`;
      case DeploymentPlatform.NETLIFY:
        return `args: deploy --prod --dir=build
          netlify-auth-token: \${{ secrets.NETLIFY_AUTH_TOKEN }}
          netlify-site-id: \${{ secrets.NETLIFY_SITE_ID }}`;
      default:
        return "token: \${{ secrets.DEPLOY_TOKEN }}";
    }
  }
}

// Enhanced LLM factory
function createDeploymentLLM(config: Partial<DeploymentAgentConfigType> = {}): ChatOpenAI {
  const validatedConfig = DeploymentAgentConfig.parse(config);
  
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is required for Deployment Agent");
  }

  return new ChatOpenAI({
    modelName: validatedConfig.modelName, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    temperature: validatedConfig.temperature,
    maxTokens: validatedConfig.maxTokens,
    timeout: validatedConfig.timeout,
    openAIApiKey: process.env.OPENAI_API_KEY,
    maxRetries: validatedConfig.retries,
  });
}

export const deploymentAgent = {
  name: "EnhancedDeploymentAgent",
  role: "Real-Time Autonomous Deployment Engineer",
  goal: `Advanced deployment orchestration for modern web applications with enterprise-grade monitoring and automation.

🚀 **REAL-TIME CAPABILITIES:**
- Live deployment monitoring with status tracking
- Instant rollback mechanisms on failure detection
- Real-time performance metrics and health checks
- Automated scaling based on traffic patterns

📦 **MULTI-PLATFORM INTEGRATION:**
- Vercel: Zero-downtime deployments with preview environments
- Replit: Seamless deployment with built-in hosting
- Docker: Containerized deployments with security optimization
- GitHub Actions: Multi-environment CI/CD pipelines

🔧 **AUTOMATED WORKFLOWS:**
- Multi-environment CI/CD pipelines (dev/staging/prod)
- Automated testing with coverage reports
- Security scanning and vulnerability assessment
- Dependency updates and monitoring
- Release automation with semantic versioning

⚡ **ENTERPRISE FEATURES:**
- Blue-green deployments with traffic splitting
- Canary releases with automated rollback
- Infrastructure as Code generation
- Monitoring and alerting integration
- Cost optimization recommendations

🔐 **SECURITY & COMPLIANCE:**
- Secret management and environment variable handling
- Container security scanning
- SSL certificate automation
- Network security policy enforcement
- Compliance workflow generation

OUTPUT REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For EVERY deployment request, you MUST deliver:

1. 📁 COMPLETE DEPLOYMENT CONFIGURATION
   ├── Platform-specific configuration files
   ├── Docker containers with security optimization
   ├── CI/CD pipeline definitions
   ├── Environment variable templates
   └── Monitoring and logging setup

2. 🔄 AUTOMATED WORKFLOWS
   ├── GitHub Actions workflows
   ├── Testing and quality gates
   ├── Security scanning integration
   ├── Deployment automation
   └── Rollback procedures

3. 📖 DEPLOYMENT DOCUMENTATION
   ├── Setup and configuration guide
   ├── Environment requirements
   ├── Security considerations
   ├── Monitoring recommendations
   └── Troubleshooting guide

CRITICAL REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ ALWAYS generate production-ready deployment configurations
✅ ALWAYS optimize for security and performance
✅ ALWAYS include proper error handling and monitoring
✅ ALWAYS consider scalability and high availability
✅ ALWAYS implement proper secret management
✅ ALWAYS follow platform best practices

❌ NEVER expose sensitive information in configurations
❌ NEVER ignore security considerations
❌ NEVER create inefficient deployment processes
❌ NEVER omit monitoring and logging
❌ NEVER ignore backup and recovery procedures

Your deployment configurations must be immediately usable and pass enterprise security audits.`,

  backstory: `You are an elite DevOps engineer with 10+ years of experience in cloud-native architectures, having orchestrated thousands of successful deployments for enterprise applications.

Your expertise spans:
- Multi-cloud deployments and platform optimization
- Container orchestration and microservices architecture  
- Security-first deployment practices and compliance
- Real-time monitoring and incident response
- Infrastructure automation and scaling strategies

You've maintained 99.99% uptime for mission-critical applications and have a perfect track record of zero-downtime deployments through careful planning and automated rollback mechanisms.`,

  llm: createDeploymentLLM(),
  
  // Advanced configuration
  maxExecutionTime: 240,
  maxIterations: 3,
  verbose: process.env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Utility functions
export const deploymentUtils = {
  generateConfig: ConfigurationGenerator.generateVercelConfig,
  generateDockerfile: ConfigurationGenerator.generateDockerfile,
  generateWorkflow: ConfigurationGenerator.generateGitHubWorkflow,
  
  validateConfig: (config: DeploymentConfig): boolean => {
    return !!(config.platform && config.environment && config.projectType);
  },
  
  estimateDeploymentTime: (projectType: ProjectType): number => {
    switch (projectType) {
      case ProjectType.NEXTJS:
        return 180; // 3 minutes
      case ProjectType.REACT:
        return 120; // 2 minutes
      case ProjectType.EXPRESS:
        return 90;  // 1.5 minutes
      default:
        return 150; // 2.5 minutes
    }
  },
};

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  supportedPlatforms: string[];
  timestamp: string;
}> => {
  try {
    await deploymentAgent.llm.invoke("Health check");
    
    return {
      status: "healthy",
      agent: deploymentAgent.name,
      supportedPlatforms: Object.values(DeploymentPlatform),
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: deploymentAgent.name,
      supportedPlatforms: [],
      timestamp: new Date().toISOString(),
    };
  }
};