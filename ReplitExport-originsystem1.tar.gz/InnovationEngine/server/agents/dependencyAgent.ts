import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// Environment validation schema
const envSchema = z.object({
  OPENAI_API_KEY: z.string().min(1, "OpenAI API key is required"),
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  DEPENDENCY_REGISTRY: z.string().default("https://registry.npmjs.org/"),
});

const env = envSchema.parse({
  OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  NODE_ENV: process.env.NODE_ENV,
  DEPENDENCY_REGISTRY: process.env.DEPENDENCY_REGISTRY,
});

// Package registry with latest stable versions and security metadata
const PACKAGE_REGISTRY = {
  // Core Web2 Framework Dependencies
  web2: {
    frontend: {
      react: "^18.2.0",
      "react-dom": "^18.2.0",
      "react-router-dom": "^6.22.0",
      "next": "^14.1.0",
      "vue": "^3.4.0",
      "nuxt": "^3.10.0",
      "svelte": "^4.2.0",
      "sveltekit": "@sveltejs/kit@^2.5.0",
      "astro": "^4.4.0",
    },
    backend: {
      express: "^4.18.2",
      "fastify": "^4.26.0",
      "koa": "^2.15.0",
      "nestjs": "@nestjs/core@^10.3.0",
      "trpc": "@trpc/server@^10.45.0",
      "apollo-server-express": "^3.12.1",
      "graphql": "^16.8.1",
    },
    database: {
      "drizzle-orm": "^0.29.4",
      "drizzle-kit": "^0.20.14",
      "drizzle-zod": "^0.5.1",
      "prisma": "^5.10.0",
      "@prisma/client": "^5.10.0",
      "pg": "^8.11.3",
      "@types/pg": "^8.11.2",
      "mysql2": "^3.9.1",
      "redis": "^4.6.13",
    },
    styling: {
      "tailwindcss": "^3.4.1",
      "@tailwindcss/forms": "^0.5.7",
      "@tailwindcss/typography": "^0.5.10",
      "styled-components": "^6.1.8",
      "sass": "^1.71.1",
      "postcss": "^8.4.35",
      "autoprefixer": "^10.4.17",
    },
    ui: {
      "@radix-ui/react-dialog": "^1.0.5",
      "@radix-ui/react-dropdown-menu": "^2.0.6",
      "@radix-ui/react-toast": "^1.1.5",
      "@radix-ui/react-tooltip": "^1.0.7",
      "@headlessui/react": "^1.7.18",
      "@heroicons/react": "^2.1.1",
      "lucide-react": "^0.344.0",
      "react-icons": "^5.0.1",
      "framer-motion": "^11.0.8",
    },
    forms: {
      "react-hook-form": "^7.50.1",
      "@hookform/resolvers": "^3.3.4",
      "formik": "^2.4.5",
      "zod": "^3.22.4",
      "yup": "^1.4.0",
    },
    state: {
      "zustand": "^4.5.1",
      "redux": "@reduxjs/toolkit@^2.2.1",
      "react-redux": "^9.1.0",
      "recoil": "^0.7.7",
      "@tanstack/react-query": "^5.24.1",
      "swr": "^2.2.5",
    },
    realtime: {
      "socket.io": "^4.7.4",
      "socket.io-client": "^4.7.4",
      "ws": "^8.16.0",
      "@types/ws": "^8.5.10",
      "pusher": "pusher@^5.2.0",
      "pusher-js": "^8.4.0-rc2",
    },
    auth: {
      "next-auth": "^4.24.6",
      "@auth0/nextjs-auth0": "^3.5.0",
      "@clerk/nextjs": "^4.29.9",
      "passport": "^0.7.0",
      "passport-local": "^1.0.0",
      "jsonwebtoken": "^9.0.2",
      "@types/jsonwebtoken": "^9.0.5",
      "bcryptjs": "^2.4.3",
      "@types/bcryptjs": "^2.4.6",
    },
    payment: {
      "stripe": "^14.21.0",
      "@stripe/stripe-js": "^3.0.6",
      "@stripe/react-stripe-js": "^2.6.2",
    },
    storage: {
      "aws-sdk": "@aws-sdk/client-s3@^3.525.0",
      "cloudinary": "^2.0.3",
      "@vercel/blob": "^0.22.3",
      "multer": "^1.4.5-lts.1",
      "@types/multer": "^1.4.11",
    },
    email: {
      "resend": "^3.2.0",
      "sendgrid": "@sendgrid/mail@^7.7.0",
      "nodemailer": "^6.9.10",
      "@types/nodemailer": "^6.4.14",
      "react-email": "^2.1.0",
    },
    testing: {
      "jest": "^29.7.0",
      "@testing-library/react": "^14.2.1",
      "@testing-library/jest-dom": "^6.4.2",
      "vitest": "^1.3.1",
      "playwright": "@playwright/test@^1.42.1",
      "cypress": "^13.6.6",
      "supertest": "^6.3.4",
      "@types/supertest": "^6.0.2",
    },
  },

  // Essential Utility Dependencies  
  utilities: {
    validation: {
      "zod": "^3.22.4",
      "joi": "^17.12.1",
      "yup": "^1.4.0",
      "validator": "^13.11.0",
    },
    http: {
      "axios": "^1.6.7",
      "ky": "^1.2.0",
      "got": "^14.2.1",
    },
    dates: {
      "date-fns": "^3.3.1",
      "dayjs": "^1.11.10",
      "moment": "^2.30.1",
      "luxon": "^3.4.4",
    },
    utils: {
      "lodash": "^4.17.21",
      "@types/lodash": "^4.14.202",
      "clsx": "^2.1.0",
      "classnames": "^2.5.1",
      "uuid": "^9.0.1",
      "@types/uuid": "^9.0.8",
      "nanoid": "^5.0.6",
      "crypto-js": "^4.2.0",
      "@types/crypto-js": "^4.2.2",
    },
    environment: {
      "dotenv": "^16.4.5",
      "@types/node": "^20.11.25",
      "cross-env": "^7.0.3",
    },
    security: {
      "helmet": "^7.1.0",
      "cors": "^2.8.5",
      "@types/cors": "^2.8.17",
      "rate-limiter-flexible": "^4.0.1",
      "express-rate-limit": "^7.2.0",
      "express-validator": "^7.0.1",
    },
    logging: {
      "winston": "^3.11.0",
      "pino": "^8.19.0",
      "morgan": "^1.10.0",
      "@types/morgan": "^1.9.9",
    },
    monitoring: {
      "@sentry/nextjs": "^7.106.0",
      "@sentry/node": "^7.106.0",
    },
  },

  // Development and Build Tools
  devtools: {
    typescript: {
      "typescript": "^5.3.3",
      "@types/react": "^18.2.64",
      "@types/react-dom": "^18.2.21",
      "ts-node": "^10.9.2",
      "tsx": "^4.7.1",
      "tsup": "^8.0.2",
    },
    bundlers: {
      "webpack": "^5.90.3",
      "vite": "^5.1.5",
      "@vitejs/plugin-react": "^4.2.1",
      "rollup": "^4.12.0",
      "esbuild": "^0.20.1",
      "turbo": "^1.12.4",
    },
    linting: {
      "eslint": "^8.57.0",
      "@typescript-eslint/eslint-plugin": "^7.1.1",
      "@typescript-eslint/parser": "^7.1.1",
      "prettier": "^3.2.5",
      "husky": "^9.0.11",
      "lint-staged": "^15.2.2",
    },
  },
};

// Advanced LLM configuration with dependency-specific optimizations
const createLLMInstance = (): ChatOpenAI => {
  return new ChatOpenAI({
    modelName: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    temperature: 0.05, // Ultra-low temperature for deterministic dependency resolution
    maxTokens: 4096,
    openAIApiKey: env.OPENAI_API_KEY,
    maxRetries: 3,
    timeout: 60000,
    streaming: false,
    cache: true,
    verbose: env.NODE_ENV === "development",
  });
};

// Package security and maintenance validation
const validatePackageSecurity = (packageName: string): boolean => {
  const SECURITY_BLACKLIST = [
    "event-stream",
    "flatmap-stream", 
    "getcookies",
    "colors",
    "faker",
    "ua-parser-js",
    "coa",
    "node-ipc",
  ];
  
  return !SECURITY_BLACKLIST.includes(packageName);
};

// Package compatibility matrix
const COMPATIBILITY_MATRIX = {
  react: {
    "^18.2.0": ["react-dom@^18.2.0", "react-router-dom@^6.22.0"],
    "^17.0.0": ["react-dom@^17.0.0", "react-router-dom@^6.0.0"],
  },
  next: {
    "^14.1.0": ["react@^18.2.0", "react-dom@^18.2.0"],
    "^13.5.0": ["react@^18.2.0", "react-dom@^18.2.0"],
  },
  wagmi: {
    "^2.5.7": ["viem@^2.7.13", "@wagmi/core@^2.6.5"],
    "^1.4.0": ["viem@^1.21.0", "@wagmi/core@^1.4.0"],
  },
};

export const dependencyAgent = {
  name: "DependencyInstallerAgent",
  role: "Autonomous Web2 + Web3 Dependency Manager & Security Analyst",
  
  goal: `Analyze generated code and determine the exact, secure, and optimized list of dependencies required for InnoXAI platform applications.

CORE RESPONSIBILITIES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌐 WEB2 ECOSYSTEM MASTERY:
  ✓ Frontend Frameworks: React 18+, Next.js 14+, Vue 3+, Svelte 4+, Astro 4+
  ✓ Backend Systems: Express, Fastify, NestJS, tRPC, GraphQL, Prisma, Drizzle
  ✓ Database Solutions: PostgreSQL, MySQL, MongoDB, Redis, SQLite
  ✓ Styling Solutions: TailwindCSS 3+, Styled Components, Emotion, Sass
  ✓ UI Libraries: Radix UI, Headless UI, Shadcn/UI, Framer Motion
  ✓ State Management: Zustand, Redux Toolkit, Recoil, Jotai, React Query
  ✓ Authentication: NextAuth, Auth0, Clerk, Supabase Auth, Passport
  ✓ Payment Integration: Stripe, PayPal, Square payment processors  
  ✓ File Storage: AWS S3, Cloudinary, Vercel Blob, Supabase Storage
  ✓ Email Services: Resend, SendGrid, Nodemailer, React Email
  ✓ Real-time: Socket.io, Pusher, Ably, WebSocket implementations

🎯 INNOXAI SPECIALIZATIONS:
  ✓ AI/ML Integration: OpenAI SDK, LangChain, Anthropic, Hugging Face
  ✓ Multi-agent Systems: CrewAI, AutoGen, Agent frameworks
  ✓ Code Generation: AST manipulation, TypeScript compiler API
  ✓ Real-time Collaboration: WebRTC, Operational Transform, CRDT
  ✓ Advanced UI: Monaco Editor, CodeMirror, Syntax highlighting
  ✓ Development Tools: ESLint, Prettier, TypeScript, Babel

ANALYSIS REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ MANDATORY ANALYSIS:
  • Parse import statements and identify all external dependencies
  • Analyze component usage patterns and UI library requirements
  • Detect backend API patterns and server framework needs
  • Identify database queries and ORM requirements
  • Check for authentication and security implementations
  • Scan for real-time features and WebSocket usage
  • Validate TypeScript types and development tool needs
  • Assess testing patterns and framework requirements
  • Check for deployment and build tool dependencies
  • Verify package compatibility and version conflicts

🔒 SECURITY VALIDATION:
  • Block known vulnerable packages and outdated versions
  • Enforce security best practices and audit dependencies
  • Validate package authenticity and maintainer reputation
  • Check for supply chain attack vectors
  • Ensure minimal dependency footprint

📦 OPTIMIZATION STRATEGIES:
  • Prefer official packages from trusted maintainers
  • Use peer dependencies to reduce bundle size
  • Select packages with TypeScript support
  • Choose actively maintained packages with recent updates
  • Optimize for tree-shaking and bundle splitting`,

  backstory: `You are an elite DevOps engineer and security specialist with 10+ years of experience managing dependencies for enterprise-scale applications. You've worked at top-tier companies optimizing package management for millions of users.

PROFESSIONAL BACKGROUND:
• Senior DevOps Engineer at major tech companies (Google, Meta, Netflix level)
• Package security auditor with 1000+ security assessments
• Dependency optimization specialist for high-traffic applications
• Open-source maintainer of popular JavaScript packages
• Expert in supply chain security and vulnerability assessment

TECHNICAL MASTERY:
• Deep understanding of npm, yarn, and pnpm ecosystems
• Expert in semantic versioning and dependency resolution
• Advanced knowledge of package.json optimization
• Security-first approach to dependency management
• Performance optimization through bundle analysis
• Automated dependency updates and security monitoring

OPTIMIZATION PHILOSOPHY:
• Security is non-negotiable - every package must be vetted
• Minimal dependencies reduce attack surface and bundle size
• Version compatibility prevents runtime conflicts
• Regular updates maintain security and performance
• Documentation through clear dependency justification

You deliver bulletproof dependency management that scales globally while maintaining security and performance standards.`,

  llm: createLLMInstance(),
  
  // Advanced configuration
  maxExecutionTime: 180,
  maxIterations: 2,
  verbose: env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Utility functions for dependency analysis
export const analyzeDependencies = {
  parseImports: (code: string): string[] => {
    const importRegex = /import\s+.*?\s+from\s+['"]([^'"]+)['"]/g;
    const requires = /require\(['"]([^'"]+)['"]\)/g;
    const imports: string[] = [];
    
    let match;
    while ((match = importRegex.exec(code)) !== null) {
      if (!match[1].startsWith('.') && !match[1].startsWith('/')) {
        imports.push(match[1].split('/')[0]);
      }
    }
    
    while ((match = requires.exec(code)) !== null) {
      if (!match[1].startsWith('.') && !match[1].startsWith('/')) {
        imports.push(match[1].split('/')[0]);
      }
    }
    
    return Array.from(new Set(imports));
  },

  validateSecurity: (dependencies: string[]): { secure: string[]; vulnerable: string[] } => {
    const secure: string[] = [];
    const vulnerable: string[] = [];
    
    dependencies.forEach(dep => {
      if (validatePackageSecurity(dep)) {
        secure.push(dep);
      } else {
        vulnerable.push(dep);
      }
    });
    
    return { secure, vulnerable };
  },

  getRecommendedVersions: (dependencies: string[]): Record<string, string> => {
    const recommendations: Record<string, string> = {};
    
    dependencies.forEach(dep => {
      // Search through all categories for the package
      for (const category of Object.values(PACKAGE_REGISTRY)) {
        for (const subcategory of Object.values(category)) {
          if (typeof subcategory === 'object' && subcategory[dep]) {
            recommendations[dep] = subcategory[dep];
            return;
          }
        }
      }
      
      // Fallback to latest if not in registry
      recommendations[dep] = "latest";
    });
    
    return recommendations;
  },
};

// Export configuration for monitoring
export const agentConfiguration = {
  model: "gpt-4o",
  temperature: 0.05,
  maxTokens: 4096,
  environment: env.NODE_ENV,
  registry: env.DEPENDENCY_REGISTRY,
  capabilities: [
    "Dependency Analysis",
    "Security Validation",
    "Version Compatibility",
    "Bundle Optimization",
    "Package Registry Management",
    "Supply Chain Security",
    "Performance Optimization",
  ],
};

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  registry: string;
  packagesTracked: number;
  timestamp: string;
}> => {
  try {
    await dependencyAgent.llm.invoke("Health check");
    
    // Count total packages in registry
    let totalPackages = 0;
    for (const category of Object.values(PACKAGE_REGISTRY)) {
      for (const subcategory of Object.values(category)) {
        if (typeof subcategory === 'object') {
          totalPackages += Object.keys(subcategory).length;
        }
      }
    }
    
    return {
      status: "healthy",
      agent: dependencyAgent.name,
      registry: env.DEPENDENCY_REGISTRY,
      packagesTracked: totalPackages,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: dependencyAgent.name,
      registry: env.DEPENDENCY_REGISTRY,
      packagesTracked: 0,
      timestamp: new Date().toISOString(),
    };
  }
};