import fs from 'fs/promises';
import path from 'path';

const PROJECT_ROOT = path.resolve(__dirname, '../../');
const SANDBOX_ROOT = path.join(PROJECT_ROOT, 'sandbox/src');

// File system operation queue to prevent race conditions
const operationQueue = new Map<string, Promise<void>>();

// Logger utility
class Logger {
  static success(message: string) {
    console.log(`[SUCCESS] ${new Date().toISOString()} - ${message}`);
  }

  static debug(message: string) {
    console.log(`[DEBUG] ${new Date().toISOString()} - ${message}`);
  }

  static info(message: string) {
    console.log(`[INFO] ${new Date().toISOString()} - ${message}`);
  }

  static error(message: string, error?: any) {
    console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error);
  }

  static warn(message: string, error?: any) {
    console.warn(`[WARN] ${new Date().toISOString()} - ${message}`, error);
  }
}

// File system monitor for tracking operations
class FileSystemMonitor {
  private static operations: Array<{
    type: 'read' | 'write' | 'delete' | 'error';
    path: string;
    timestamp: Date;
    error?: any;
  }> = [];

  static recordRead(filePath: string) {
    this.operations.push({
      type: 'read',
      path: filePath,
      timestamp: new Date()
    });
  }

  static recordWrite(filePath: string) {
    this.operations.push({
      type: 'write',
      path: filePath,
      timestamp: new Date()
    });
  }

  static recordDelete(filePath: string) {
    this.operations.push({
      type: 'delete',
      path: filePath,
      timestamp: new Date()
    });
  }

  static recordError(filePath: string, error: any) {
    this.operations.push({
      type: 'error',
      path: filePath,
      timestamp: new Date(),
      error
    });
  }

  static getOperations() {
    return this.operations;
  }
}

// Content validator for different file types
class ContentValidator {
  static async validate(content: string, fileExtension: string): Promise<void> {
    switch (fileExtension) {
      case '.tsx':
      case '.ts':
        await this.validateTypeScript(content);
        break;
      case '.js':
      case '.jsx':
        await this.validateJavaScript(content);
        break;
      case '.json':
        await this.validateJSON(content);
        break;
      case '.css':
        await this.validateCSS(content);
        break;
      default:
        await this.validateBasic(content);
    }
  }

  private static async validateTypeScript(content: string): Promise<void> {
    // Basic TypeScript validation
    if (content.includes('import') && !content.includes('export')) {
      Logger.warn('TypeScript file has imports but no exports');
    }
    
    // Check for basic syntax issues
    const openBraces = (content.match(/\{/g) || []).length;
    const closeBraces = (content.match(/\}/g) || []).length;
    if (openBraces !== closeBraces) {
      throw new Error('Unmatched braces in TypeScript content');
    }
  }

  private static async validateJavaScript(content: string): Promise<void> {
    // Basic JavaScript validation - check for common syntax issues
    const openBraces = (content.match(/\{/g) || []).length;
    const closeBraces = (content.match(/\}/g) || []).length;
    if (openBraces !== closeBraces) {
      throw new Error('Unmatched braces in JavaScript content');
    }
  }

  private static async validateJSON(content: string): Promise<void> {
    try {
      JSON.parse(content);
    } catch (error) {
      throw new Error(`Invalid JSON: ${(error as Error).message}`);
    }
  }

  private static async validateCSS(content: string): Promise<void> {
    // Basic CSS validation
    const openBraces = (content.match(/\{/g) || []).length;
    const closeBraces = (content.match(/\}/g) || []).length;
    if (openBraces !== closeBraces) {
      throw new Error('Unmatched braces in CSS content');
    }
  }

  private static async validateBasic(content: string): Promise<void> {
    if (content.length === 0) {
      throw new Error('File content is empty');
    }
  }
}

// Enhanced path resolution with additional safety checks
function resolveFilePath(relativePath: string): { safePath: string; relativePath: string } {
  // Normalize and clean the path
  const cleanedPath = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/g, '');
  const safePath = path.join(SANDBOX_ROOT, cleanedPath);

  // Verify the path stays within sandbox
  if (!safePath.startsWith(SANDBOX_ROOT + path.sep) && safePath !== SANDBOX_ROOT) {
    throw new Error(`Potential directory traversal attempt detected: ${relativePath}`);
  }

  return { 
    safePath,
    relativePath: path.relative(SANDBOX_ROOT, safePath)
  };
}

export async function writeGeneratedFile(
  relativePath: string, 
  content: string,
  options: {
    validateContent?: boolean;
    overwrite?: boolean;
    backup?: boolean;
  } = {}
): Promise<void> {
  const { safePath, relativePath: validatedRelativePath } = resolveFilePath(relativePath);
  const queueKey = safePath;

  // Check if there's already an operation for this file
  if (operationQueue.has(queueKey)) {
    await operationQueue.get(queueKey);
  }

  try {
    // Create a new operation promise for the queue
    const operationPromise = (async () => {
      try {
        await performFileWrite();
      } finally {
        operationQueue.delete(queueKey);
      }
    })();

    operationQueue.set(queueKey, operationPromise);
    await operationPromise;

    async function performFileWrite() {
      const dir = path.dirname(safePath);
      
      // Validate content if enabled
      if (options.validateContent !== false) {
        await ContentValidator.validate(content, path.extname(safePath));
      }

      // Create directory if needed
      await fs.mkdir(dir, { recursive: true });

      // Backup existing file if needed
      if (options.backup && await fileExists(safePath)) {
        const backupPath = `${safePath}.bak`;
        await fs.copyFile(safePath, backupPath);
        Logger.debug(`Created backup: ${backupPath}`);
      }

      // Check if file exists when overwrite is false
      if (!options.overwrite && await fileExists(safePath)) {
        throw new Error(`File already exists and overwrite is disabled: ${validatedRelativePath}`);
      }

      // Atomic write using temporary file
      const tempPath = `${safePath}.tmp`;
      await fs.writeFile(tempPath, content, 'utf-8');
      await fs.rename(tempPath, safePath);

      Logger.success(`File written: ${validatedRelativePath}`);
      FileSystemMonitor.recordWrite(validatedRelativePath);

      // Notify preview system of updated file
      await notifyPreviewUpdate([validatedRelativePath]);
    }
  } catch (error) {
    Logger.error(`Failed to write file ${validatedRelativePath}: ${(error as Error).message}`);
    FileSystemMonitor.recordError(validatedRelativePath, error);
    throw error;
  }
}

async function fileExists(path: string): Promise<boolean> {
  try {
    await fs.access(path);
    return true;
  } catch {
    return false;
  }
}

// Preview notification
async function notifyPreviewUpdate(filePaths: string[]): Promise<void> {
  Logger.debug(`Preview update notification sent for: ${filePaths.join(', ')}`);
}

// Additional utility functions
export async function readGeneratedFile(relativePath: string): Promise<string> {
  const { safePath, relativePath: validatedRelativePath } = resolveFilePath(relativePath);
  try {
    const content = await fs.readFile(safePath, 'utf-8');
    FileSystemMonitor.recordRead(validatedRelativePath);
    return content;
  } catch (error) {
    Logger.error(`Failed to read file ${validatedRelativePath}: ${(error as Error).message}`);
    throw error;
  }
}

export async function deleteGeneratedFile(relativePath: string): Promise<void> {
  const { safePath, relativePath: validatedRelativePath } = resolveFilePath(relativePath);
  try {
    await fs.unlink(safePath);
    Logger.info(`File deleted: ${validatedRelativePath}`);
    FileSystemMonitor.recordDelete(validatedRelativePath);
  } catch (error) {
    Logger.error(`Failed to delete file ${validatedRelativePath}: ${(error as Error).message}`);
    throw error;
  }
}

export async function listGeneratedFiles(directoryPath: string = ''): Promise<string[]> {
  const { safePath } = resolveFilePath(directoryPath);
  try {
    const items = await fs.readdir(safePath, { withFileTypes: true });
    const files = items
      .filter(item => item.isFile())
      .map(item => path.join(directoryPath, item.name));
    return files;
  } catch (error) {
    Logger.error(`Failed to list files in ${directoryPath}: ${(error as Error).message}`);
    throw error;
  }
}

export function getFileSystemOperations() {
  return FileSystemMonitor.getOperations();
}

export { Logger, FileSystemMonitor, ContentValidator };