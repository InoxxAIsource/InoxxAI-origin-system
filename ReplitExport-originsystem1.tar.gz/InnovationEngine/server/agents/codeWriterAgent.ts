import OpenAI from "openai";
import { z } from "zod";

// Environment validation schema
const envSchema = z.object({
  OPENAI_API_KEY: z.string().min(1, "OpenAI API key is required"),
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
});

// Validate environment variables
const env = envSchema.parse({
  OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  NODE_ENV: process.env.NODE_ENV,
});

// Direct OpenAI API client for reliable code generation
const createOpenAIClient = (): OpenAI => {
  return new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });
};

// Code quality validation patterns
const CODE_QUALITY_PATTERNS = {
  typescript: {
    imports: /^import\s+.*\s+from\s+['"].*['"];?$/gm,
    exports: /^export\s+(default\s+)?(class|function|const|interface|type)/gm,
    types: /:\s*[A-Z][a-zA-Z0-9<>[\]|&,\s]*[^;]/g,
  },
  react: {
    components: /^(export\s+)?(default\s+)?function\s+[A-Z]\w*\s*\(/gm,
    hooks: /const\s+\[\w+,\s*set\w+\]\s*=\s*useState/gm,
    jsx: /<[A-Z]\w*[\s\S]*?\/?>|<\/[A-Z]\w*>/gm,
  },
};

// Real code generation function using OpenAI API
export const generateCode = async (prompt: string, projectType: string = 'react'): Promise<{
  code: string;
  type: string;
  dependencies: string[];
  description: string;
}> => {
  const openai = createOpenAIClient();
  
  const systemPrompt = `You are an expert fullstack developer. Generate complete, production-ready code based on the user's request.

REQUIREMENTS:
- Write fully functional, complete code - no placeholders or TODOs
- Use modern TypeScript and React patterns
- Include proper error handling and validation
- Make code responsive and accessible
- Return only the code without explanations

For React components:
- Use functional components with hooks
- Include proper TypeScript types
- Use modern CSS or Tailwind classes
- Handle loading and error states

For HTML projects:
- Include complete HTML structure
- Add inline CSS for styling
- Make it responsive and modern
- Include interactive JavaScript if needed`;

  try {
    console.log(`Starting OpenAI code generation for: ${prompt}`);
    
    const openai = createOpenAIClient();
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Generate a ${projectType} project: ${prompt}` }
      ],
      temperature: 0.15,
      max_tokens: 8192,
    });

    console.log('OpenAI response received successfully');
    const code = response.choices[0]?.message?.content;
    
    if (!code || code.trim().length === 0) {
      throw new Error('OpenAI returned empty response');
    }
    
    // Extract dependencies from imports
    const dependencies = extractDependencies(code);
    
    // Determine project type
    const detectedType = detectProjectType(code);
    
    return {
      code: code.trim(),
      type: detectedType,
      dependencies,
      description: `Generated ${detectedType} project for: ${prompt}`
    };
  } catch (error) {
    console.error('Code generation error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    throw new Error(`Failed to generate code: ${errorMessage}`);
  }
};

// Extract dependencies from code
const extractDependencies = (code: string): string[] => {
  const dependencies = new Set<string>();
  
  // Extract from import statements
  const importMatches = code.match(/import.*from\s+['"`]([^'"`]+)['"`]/g);
  if (importMatches) {
    importMatches.forEach(match => {
      const dep = match.match(/from\s+['"`]([^'"`]+)['"`]/)?.[1];
      if (dep && !dep.startsWith('.') && !dep.startsWith('/')) {
        dependencies.add(dep);
      }
    });
  }
  
  return Array.from(dependencies);
};

// Detect project type from code content
const detectProjectType = (code: string): string => {
  if (code.includes('import React') || code.includes('useState') || code.includes('useEffect')) {
    return 'react';
  }
  if (code.includes('<!DOCTYPE html>') || code.includes('<html')) {
    return 'html';
  }
  if (code.includes('<template>') && code.includes('<script>')) {
    return 'vue';
  }
  if (code.includes('<script>') && code.includes('export default')) {
    return 'svelte';
  }
  return 'html';
};

export const codeWriterAgent = {
  name: "CodeWriterAgent",
  role: "Ultra-Advanced Fullstack AI Engineer",
  goal: `Write full production-grade code for the InnoXAI platform with expertise in modern web development.

CORE CAPABILITIES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 FULLSTACK DEVELOPMENT:
  ✓ React 18+ with TypeScript, hooks, and modern patterns
  ✓ Next.js 14+ with App Router and Server Components
  ✓ TailwindCSS 3+ with responsive design and dark mode
  ✓ Node.js/Express.js with middleware and error handling
  ✓ PostgreSQL with Drizzle ORM and type-safe queries
  ✓ Authentication systems and session management
  ✓ Real-time features with WebSockets and Socket.io
  ✓ File uploads, payment processing, and email services
  ✓ API design with OpenAPI documentation

🎯 INNOXAI SPECIALIZATIONS:
  ✓ AI-powered code generation interfaces
  ✓ Multi-agent collaboration systems
  ✓ Real-time preview and rendering components
  ✓ Advanced dashboard and analytics interfaces
  ✓ File management and project organization
  ✓ Code editor integrations and syntax highlighting
  ✓ Collaborative development environments

OUTPUT REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ MANDATORY INCLUSIONS:
  • Complete, production-ready code implementations
  • Type-safe TypeScript with strict mode compliance
  • Proper import paths with alias resolution (@/, ~/)
  • Error handling and edge case management
  • Responsive design and accessibility features
  • Performance optimizations and caching
  • Security implementations and validation
  • Environment variable configuration
  • Database schemas with proper relationships
  • API endpoints with request/response typing
  • Unit test coverage for critical functions
  • Documentation through clear code structure

🚫 STRICTLY FORBIDDEN:
  • Placeholder or TODO implementations
  • Insecure patterns or vulnerabilities
  • Hard-coded credentials or sensitive data
  • Deprecated library usage
  • Non-responsive UI components
  • Unhandled errors or promise rejections
  • Performance bottlenecks or memory leaks`,

  backstory: `You are an elite software engineer specializing in the InnoXAI platform development. With 10+ years of experience building production-grade applications, you excel at creating sophisticated AI-powered development tools.

PROFESSIONAL BACKGROUND:
• Lead Engineer at top-tier tech companies building developer tools
• Expert in React ecosystem, TypeScript, and modern web frameworks
• Specialist in AI/ML integration and multi-agent systems
• Full-stack architect for applications serving millions of users
• Open-source contributor to major web development frameworks

TECHNICAL MASTERY:
• Advanced React patterns, state management, and performance optimization
• Expert TypeScript usage with complex type definitions
• Database design, query optimization, and ORM integration
• Real-time systems, WebSocket implementation, and collaborative features
• Security-first development with comprehensive input validation
• Testing strategies including unit, integration, and E2E testing

CODING PHILOSOPHY:
• Write self-documenting, maintainable code
• Security and performance are non-negotiable
• User experience drives technical decisions
• Comprehensive error handling prevents production issues
• Type safety eliminates entire classes of bugs
• Clean architecture enables long-term maintainability

You deliver enterprise-grade solutions that power the next generation of AI development platforms.`,

  openai: createOpenAIClient(),
  
  // Advanced configuration
  maxExecutionTime: 300,
  maxIterations: 3,
  verbose: env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Utility functions for code validation and quality assurance
export const validateCode = {
  typescript: (code: string): boolean => {
    const { imports, exports, types } = CODE_QUALITY_PATTERNS.typescript;
    return imports.test(code) && exports.test(code);
  },
  
  react: (code: string): boolean => {
    const { components, hooks, jsx } = CODE_QUALITY_PATTERNS.react;
    return components.test(code) || hooks.test(code) || jsx.test(code);
  },
};

// Export configuration for monitoring
export const agentConfiguration = {
  model: "gpt-4o",
  temperature: 0.15,
  maxTokens: 8192,
  environment: env.NODE_ENV,
  capabilities: [
    "React/TypeScript Development",
    "Full-stack Web Applications", 
    "Database Architecture",
    "API Design & Implementation",
    "Real-time Systems",
    "AI Integration",
    "Security Implementation",
    "Performance Optimization",
    "Testing & Quality Assurance",
  ],
};

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  model: string;
  timestamp: string;
}> => {
  try {
    await codeWriterAgent.llm.invoke("Health check");
    return {
      status: "healthy",
      agent: codeWriterAgent.name,
      model: "gpt-4o",
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: codeWriterAgent.name,
      model: "gpt-4o",
      timestamp: new Date().toISOString(),
    };
  }
};