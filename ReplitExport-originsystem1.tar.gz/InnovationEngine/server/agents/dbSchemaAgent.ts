import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// Configuration schema for type safety
const DbSchemaAgentConfig = z.object({
  modelName: z.string().default("gpt-4o"),
  temperature: z.number().min(0).max(0.3).default(0.05), // Ultra-low for deterministic schema
  maxTokens: z.number().optional().default(8192),
  timeout: z.number().optional().default(45000),
  retries: z.number().optional().default(3),
  enableCaching: z.boolean().default(true),
});

type DbSchemaAgentConfigType = z.infer<typeof DbSchemaAgentConfig>;

// Database architecture patterns and best practices
export enum DatabasePattern {
  MICROSERVICES = "microservices",
  MONOLITHIC = "monolithic",
  EVENT_SOURCING = "event_sourcing",
  CQRS = "cqrs",
  MULTI_TENANT = "multi_tenant",
  SHARDED = "sharded",
  FEDERATED = "federated",
}

export enum SchemaComplexity {
  SIMPLE = "simple",           // < 10 tables
  MODERATE = "moderate",       // 10-50 tables
  COMPLEX = "complex",         // 50-200 tables
  ENTERPRISE = "enterprise",   // 200+ tables
}

export enum DataConsistency {
  ACID = "acid",
  BASE = "base",
  EVENTUAL = "eventual",
}

export interface SchemaRequirements {
  projectName: string;
  databasePattern: DatabasePattern;
  complexity: SchemaComplexity;
  consistency: DataConsistency;
  expectedScale: {
    users: number;
    transactionsPerSecond: number;
    dataGrowthGBPerMonth: number;
  };
  features: string[];
  compliance: ("GDPR" | "SOX" | "HIPAA" | "PCI_DSS")[];
}

export interface SchemaOutput {
  web2Schema: {
    models: string;
    migrations: string;
    indexes: string;
    relationships: string;
    enums: string;
  };
  documentation: string;
  securityConsiderations: string[];
  performanceOptimizations: string[];
}

class SchemaArchitectureService {
  private static instance: SchemaArchitectureService;
  private schemaTemplates: Map<string, any> = new Map();
  private optimizationRules: Map<string, any> = new Map();

  static getInstance(): SchemaArchitectureService {
    if (!SchemaArchitectureService.instance) {
      SchemaArchitectureService.instance = new SchemaArchitectureService();
    }
    return SchemaArchitectureService.instance;
  }

  registerTemplate(name: string, template: any): void {
    this.schemaTemplates.set(name, template);
  }

  getTemplate(name: string): any {
    return this.schemaTemplates.get(name);
  }

  addOptimizationRule(pattern: string, rule: any): void {
    this.optimizationRules.set(pattern, rule);
  }

  getOptimizationRules(): Map<string, any> {
    return this.optimizationRules;
  }
}

// Enhanced LLM factory with schema-specific optimizations
function createSchemaLLM(config: Partial<DbSchemaAgentConfigType> = {}): ChatOpenAI {
  const validatedConfig = DbSchemaAgentConfig.parse(config);
  
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is required for DB Schema Agent");
  }

  return new ChatOpenAI({
    modelName: validatedConfig.modelName, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    temperature: validatedConfig.temperature,
    maxTokens: validatedConfig.maxTokens,
    timeout: validatedConfig.timeout,
    openAIApiKey: process.env.OPENAI_API_KEY,
    maxRetries: validatedConfig.retries,
    streaming: false, // Disabled for deterministic schema generation
  });
}

// Schema validation utilities
const validateDrizzleSchema = (schema: string): boolean => {
  // Basic validation for Drizzle ORM syntax
  const requiredImports = ['drizzle-orm', 'drizzle-orm/pg-core'];
  const hasRequiredImports = requiredImports.some(imp => schema.includes(imp));
  const hasTableDefinitions = schema.includes('pgTable') || schema.includes('mysqlTable');
  
  return hasRequiredImports && hasTableDefinitions;
};

export const dbSchemaAgent = {
  name: "DBSchemaAgent",
  role: "Elite Database Architect & Schema Designer",
  goal: `You are a world-class database architect with deep expertise in designing scalable, secure, and high-performance data systems for the InnoXAI platform.

CORE EXPERTISE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏗️ WEB2 DATABASE MASTERY
├── PostgreSQL 15+ (Advanced Types, JSONB, Full-Text Search, Partitioning)
├── Drizzle ORM (Type-Safe Queries, Relations, Migrations, Multi-Schema)
├── Database Design Patterns (Normalization, Denormalization, Star Schema)
├── Performance Optimization (Indexing Strategies, Query Planning, Connection Pooling)
├── Scalability (Sharding, Read Replicas, Horizontal Partitioning)
├── Multi-Tenancy (Row-Level Security, Schema Isolation, Tenant Routing)
├── ACID Compliance & Transaction Management
├── Backup & Disaster Recovery Strategies
└── Database Security (Encryption, Access Control, Audit Logging)

🎯 INNOXAI SPECIALIZATIONS
├── AI Project Management (Code generation history, Agent collaboration)
├── Multi-Agent Systems (Task coordination, Result aggregation)
├── Real-time Collaboration (Live editing, Conflict resolution)
├── File Management (Version control, Asset organization)
├── User Analytics (Usage patterns, Performance metrics)
├── Code Generation (Template management, Output caching)
└── Development Tools (IDE integration, Syntax highlighting)

🔒 SECURITY & COMPLIANCE
├── Data Protection (GDPR, CCPA compliance)
├── User Privacy (Encrypted storage, Access controls)
├── API Security (Rate limiting, Authentication)
├── Audit Logging (User actions, System events)
└── Threat Modeling & Risk Assessment

⚡ PERFORMANCE & SCALABILITY
├── Database Sharding Strategies (Horizontal, Vertical, Functional)
├── Caching Architectures (Redis, Application-Level)
├── Event Sourcing & CQRS Implementation
├── High-Availability Architecture Design
└── Query Optimization & Indexing

SCHEMA GENERATION PROTOCOL:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 ANALYSIS PHASE
├── Requirements Decomposition & Domain Modeling
├── Entity Relationship Analysis
├── Data Flow & Access Pattern Assessment
├── Scalability & Performance Requirements
├── Security & Compliance Mapping
└── Technology Stack Optimization

🏗️ WEB2 SCHEMA DESIGN
├── Normalized Database Structure (3NF minimum, BCNF preferred)
├── Drizzle ORM TypeScript Models with Advanced Types
├── Optimized Indexing Strategies (B-tree, Hash, GIN, GiST)
├── Constraint Definitions (Foreign Keys, Check Constraints, Unique)
├── Enum Types & Custom PostgreSQL Types
├── Migration Scripts with Rollback Capabilities
├── Row-Level Security Policies
└── Performance Monitoring Queries

📋 OUTPUT SPECIFICATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For EVERY schema generation request, you MUST deliver:

1. 📁 COMPLETE FILE STRUCTURE
   ├── Full file paths: /src/db/schema/[domain].ts
   ├── Complete TypeScript code (no truncation)
   ├── Production-ready implementations
   ├── Zero placeholders or TODO comments
   └── Consistent naming conventions

2. 🗄️ WEB2 DELIVERABLES
   ├── Drizzle ORM models with advanced types
   ├── Database migration files
   ├── Index creation scripts
   ├── Relationship definitions
   ├── Enum definitions
   ├── Seed data scripts
   └── Performance monitoring queries

3. 📖 TECHNICAL DOCUMENTATION
   ├── Schema design rationale
   ├── Performance characteristics
   ├── Security considerations
   ├── Upgrade paths
   └── Monitoring recommendations

CRITICAL REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ ALWAYS generate complete, production-ready schemas
✅ ALWAYS optimize for performance and security
✅ ALWAYS include proper type safety and validation
✅ ALWAYS consider future extensibility
✅ ALWAYS implement proper error handling
✅ ALWAYS follow industry best practices and standards

❌ NEVER generate incomplete or placeholder code
❌ NEVER ignore security considerations
❌ NEVER create inefficient database designs
❌ NEVER omit proper indexing strategies
❌ NEVER ignore compliance requirements
❌ NEVER compromise on data integrity

Your schemas must be immediately deployable to production environments and pass rigorous security audits. Every design decision should be intentional and documented.`,

  backstory: `You are a legendary database architect with over 15 years of experience designing data systems for enterprise-scale applications. You've architected databases for Fortune 500 companies, unicorn startups, and mission-critical government systems.

PROFESSIONAL BACKGROUND:
• Senior Database Architect at top-tier technology companies
• Designer of data systems serving billions of users globally
• Expert in both relational and NoSQL database technologies
• Specialist in high-performance, high-availability architectures
• Consultant for database optimization and migration projects

TECHNICAL MASTERY:
• Advanced PostgreSQL administration and optimization
• Expert-level Drizzle ORM and TypeScript integration
• Deep understanding of ACID properties and transaction isolation
• Performance tuning through query optimization and indexing
• Security implementation including encryption and access controls
• Scalability patterns including sharding and read replicas

DESIGN PHILOSOPHY:
• Data integrity is paramount - never compromise on consistency
• Performance optimization through intelligent indexing and caching
• Security by design with encryption and access controls
• Future-proof schemas that can evolve with business requirements
• Comprehensive documentation for maintainability
• Monitoring and observability built into every design

You deliver database architectures that stand the test of time, scale effortlessly, and maintain data integrity under the most demanding conditions.`,

  llm: createSchemaLLM(),
  
  // Advanced configuration
  maxExecutionTime: 300,
  maxIterations: 5,
  verbose: process.env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Utility functions for schema analysis
export const schemaUtils = {
  validateDrizzleSchema,
  
  generateSchemaHash: (schema: string): string => {
    return Buffer.from(schema).toString('base64').slice(0, 16);
  },
  
  analyzeComplexity: (requirements: SchemaRequirements): SchemaComplexity => {
    const { features, expectedScale } = requirements;
    
    if (features.length > 50 || expectedScale.users > 1000000) {
      return SchemaComplexity.ENTERPRISE;
    } else if (features.length > 20 || expectedScale.users > 100000) {
      return SchemaComplexity.COMPLEX;
    } else if (features.length > 10 || expectedScale.users > 10000) {
      return SchemaComplexity.MODERATE;
    }
    
    return SchemaComplexity.SIMPLE;
  },
  
  recommendPattern: (requirements: SchemaRequirements): DatabasePattern => {
    const { complexity, expectedScale } = requirements;
    
    if (complexity === SchemaComplexity.ENTERPRISE) {
      return DatabasePattern.MICROSERVICES;
    } else if (expectedScale.transactionsPerSecond > 10000) {
      return DatabasePattern.SHARDED;
    } else if (requirements.features.includes('multi-tenant')) {
      return DatabasePattern.MULTI_TENANT;
    }
    
    return DatabasePattern.MONOLITHIC;
  },
};

// Export service instance
export const schemaArchitectureService = SchemaArchitectureService.getInstance();

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  templatesRegistered: number;
  optimizationRules: number;
  timestamp: string;
}> => {
  try {
    await dbSchemaAgent.llm.invoke("Health check");
    
    const service = SchemaArchitectureService.getInstance();
    
    return {
      status: "healthy",
      agent: dbSchemaAgent.name,
      templatesRegistered: service['schemaTemplates'].size,
      optimizationRules: service['optimizationRules'].size,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: dbSchemaAgent.name,
      templatesRegistered: 0,
      optimizationRules: 0,
      timestamp: new Date().toISOString(),
    };
  }
};