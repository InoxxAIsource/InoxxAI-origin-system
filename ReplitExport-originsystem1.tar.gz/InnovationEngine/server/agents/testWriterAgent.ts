import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// Configuration schema for test writer agent
const TestWriterAgentConfig = z.object({
  modelName: z.string().default("gpt-4o"),
  temperature: z.number().min(0).max(0.3).default(0.1),
  maxTokens: z.number().optional().default(6144),
  timeout: z.number().optional().default(45000),
  retries: z.number().optional().default(3),
});

type TestWriterAgentConfigType = z.infer<typeof TestWriterAgentConfig>;

// Test analysis and security types
export enum VulnerabilityType {
  REENTRANCY = "reentrancy",
  INTEGER_OVERFLOW = "integerOverflow",
  ACCESS_CONTROL = "accessControl",
  FRONT_RUNNING = "frontRunning",
  GAS_LIMIT = "gasLimit",
}

export interface VulnerabilityReport {
  type: VulnerabilityType;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  locations: string[];
  recommendation: string;
}

export interface SecurityAnalysis {
  riskScore: number;
  vulnerabilities: VulnerabilityReport[];
  testCoverage: number;
  gasOptimization: GasAnalysis;
}

export interface GasAnalysis {
  estimatedGas: number;
  optimizationSuggestions: string[];
}

export interface TestSuite {
  unitTests: string[];
  integrationTests: string[];
  e2eTests: string[];
  securityTests: string[];
  performanceTests: string[];
  accessibilityTests: string[];
}

// AI-Powered Test Analysis Engine
class TestAnalysisEngine {
  private static vulnerabilityPatterns = {
    reentrancy: /external.*call.*before.*state/gi,
    integerOverflow: /unchecked.*arithmetic|SafeMath/gi,
    accessControl: /onlyOwner|require.*msg\.sender/gi,
    frontRunning: /block\.timestamp|block\.number/gi,
    gasLimit: /\.call\{gas:/gi
  };

  static analyzeContract(code: string): SecurityAnalysis {
    const vulnerabilities: VulnerabilityReport[] = [];
    
    for (const [type, pattern] of Object.entries(this.vulnerabilityPatterns)) {
      const matches = code.match(pattern);
      if (matches) {
        vulnerabilities.push({
          type: type as VulnerabilityType,
          severity: this.getSeverity(type),
          locations: matches,
          recommendation: this.getRecommendation(type)
        });
      }
    }

    return {
      riskScore: this.calculateRiskScore(vulnerabilities),
      vulnerabilities,
      testCoverage: this.estimateTestCoverage(code),
      gasOptimization: this.analyzeGasUsage(code)
    };
  }

  private static getSeverity(type: string): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    const severityMap: Record<string, 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'> = {
      reentrancy: 'CRITICAL',
      integerOverflow: 'HIGH',
      accessControl: 'HIGH',
      frontRunning: 'MEDIUM',
      gasLimit: 'LOW'
    };
    return severityMap[type] || 'LOW';
  }

  private static getRecommendation(type: string): string {
    const recommendations: Record<string, string> = {
      reentrancy: 'Implement ReentrancyGuard from OpenZeppelin',
      integerOverflow: 'Use SafeMath library or Solidity 0.8+ built-in overflow protection',
      accessControl: 'Implement proper role-based access control',
      frontRunning: 'Use commit-reveal scheme or other MEV protection',
      gasLimit: 'Optimize gas usage and implement proper error handling'
    };
    return recommendations[type] || 'Review and implement security best practices';
  }

  private static calculateRiskScore(vulnerabilities: VulnerabilityReport[]): number {
    const weights = { CRITICAL: 10, HIGH: 7, MEDIUM: 4, LOW: 1 };
    return vulnerabilities.reduce((score, vuln) => score + weights[vuln.severity], 0);
  }

  private static estimateTestCoverage(code: string): number {
    const functionCount = (code.match(/function\s+\w+/g) || []).length;
    const testableLines = code.split('\n').filter(line => 
      line.includes('require') || line.includes('assert') || line.includes('emit')
    ).length;
    return Math.min(95, (testableLines / functionCount) * 20);
  }

  private static analyzeGasUsage(code: string): GasAnalysis {
    const expensiveOperations = code.match(/SSTORE|SLOAD|CREATE|CALL/gi) || [];
    return {
      estimatedGas: expensiveOperations.length * 5000,
      optimizationSuggestions: [
        'Use packed structs to reduce storage slots',
        'Batch operations where possible',
        'Consider using libraries for common operations'
      ]
    };
  }
}

// Advanced Test Generator
class AdvancedTestGenerator {
  static generateReactComponentTest(componentPath: string, componentName: string): string {
    return `
import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { MockedProvider } from '@apollo/client/testing';
import { ${componentName} } from '${componentPath}';

// Mock providers and dependencies
const mockQueryClient = new QueryClient({
  defaultOptions: { queries: { retry: false }, mutations: { retry: false } }
});

const TestWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <QueryClientProvider client={mockQueryClient}>
    <BrowserRouter>
      <MockedProvider mocks={[]} addTypename={false}>
        {children}
      </MockedProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

describe('${componentName}', () => {
  let user: ReturnType<typeof userEvent.setup>;

  beforeEach(() => {
    user = userEvent.setup();
    jest.clearAllMocks();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('Rendering', () => {
    it('renders without crashing', () => {
      render(<${componentName} />, { wrapper: TestWrapper });
      expect(screen.getByTestId('${componentName.toLowerCase()}')).toBeInTheDocument();
    });

    it('displays loading state correctly', () => {
      render(<${componentName} loading={true} />, { wrapper: TestWrapper });
      expect(screen.getByTestId('loading-spinner')).toBeInTheDocument();
    });

    it('handles error states gracefully', () => {
      const error = new Error('Test error');
      render(<${componentName} error={error} />, { wrapper: TestWrapper });
      expect(screen.getByText(/test error/i)).toBeInTheDocument();
    });
  });

  describe('User Interactions', () => {
    it('handles click events correctly', async () => {
      const mockOnClick = jest.fn();
      render(<${componentName} onClick={mockOnClick} />, { wrapper: TestWrapper });
      
      const button = screen.getByRole('button');
      await user.click(button);
      
      expect(mockOnClick).toHaveBeenCalledTimes(1);
    });

    it('handles form submissions', async () => {
      const mockOnSubmit = jest.fn();
      render(<${componentName} onSubmit={mockOnSubmit} />, { wrapper: TestWrapper });
      
      const form = screen.getByRole('form');
      await user.type(screen.getByLabelText(/input/i), 'test value');
      await user.click(screen.getByRole('button', { name: /submit/i }));
      
      await waitFor(() => {
        expect(mockOnSubmit).toHaveBeenCalledWith(
          expect.objectContaining({ input: 'test value' })
        );
      });
    });
  });

  describe('Accessibility', () => {
    it('has proper ARIA labels', () => {
      render(<${componentName} />, { wrapper: TestWrapper });
      
      const elements = screen.getAllByRole('button');
      elements.forEach(element => {
        expect(element).toHaveAttribute('aria-label');
      });
    });

    it('supports keyboard navigation', async () => {
      render(<${componentName} />, { wrapper: TestWrapper });
      
      const firstFocusable = screen.getAllByRole('button')[0];
      firstFocusable.focus();
      
      await user.keyboard('{Tab}');
      expect(document.activeElement).not.toBe(firstFocusable);
    });
  });

  describe('Performance', () => {
    it('does not cause unnecessary re-renders', () => {
      const renderSpy = jest.fn();
      const TestComponent = () => {
        renderSpy();
        return <${componentName} />;
      };
      
      const { rerender } = render(<TestComponent />, { wrapper: TestWrapper });
      rerender(<TestComponent />);
      
      expect(renderSpy).toHaveBeenCalledTimes(2);
    });
  });
});
    `.trim();
  }

  static generateAPITest(apiPath: string, routeName: string): string {
    return `
import request from 'supertest';
import { app } from '@/server/app';
import { db } from '@/lib/db';
import { users, posts } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

describe('${routeName} API', () => {
  let authToken: string;
  let testUser: any;

  beforeAll(async () => {
    // Setup test database
    await db.delete(users);
    await db.delete(posts);
  });

  beforeEach(async () => {
    // Create test user
    const hashedPassword = await bcrypt.hash('testpassword', 10);
    const [user] = await db.insert(users).values({
      email: 'test@example.com',
      password: hashedPassword,
      name: 'Test User'
    }).returning();
    
    testUser = user;
    authToken = jwt.sign({ userId: user.id }, process.env.JWT_SECRET!);
  });

  afterEach(async () => {
    // Cleanup test data
    await db.delete(users);
    await db.delete(posts);
  });

  describe('Authentication', () => {
    it('requires valid authentication token', async () => {
      const response = await request(app)
        .get('${apiPath}')
        .expect(401);

      expect(response.body.error).toBe('Unauthorized');
    });

    it('accepts valid authentication token', async () => {
      const response = await request(app)
        .get('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .expect(200);

      expect(response.body).toBeDefined();
    });

    it('rejects malformed tokens', async () => {
      const response = await request(app)
        .get('${apiPath}')
        .set('Authorization', 'Bearer invalid-token')
        .expect(401);

      expect(response.body.error).toBe('Invalid token');
    });
  });

  describe('CRUD Operations', () => {
    it('creates new resource successfully', async () => {
      const testData = {
        title: 'Test Title',
        content: 'Test Content',
        authorId: testUser.id
      };

      const response = await request(app)
        .post('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .send(testData)
        .expect(201);

      expect(response.body).toMatchObject({
        id: expect.any(Number),
        title: testData.title,
        content: testData.content,
        authorId: testData.authorId
      });
    });

    it('retrieves resources with pagination', async () => {
      // Create test data
      const testPosts = Array.from({ length: 15 }, (_, i) => ({
        title: \`Post \${i + 1}\`,
        content: \`Content \${i + 1}\`,
        authorId: testUser.id
      }));

      await db.insert(posts).values(testPosts);

      const response = await request(app)
        .get(\`\${apiPath}?page=1&limit=10\`)
        .set('Authorization', \`Bearer \${authToken}\`)
        .expect(200);

      expect(response.body.data).toHaveLength(10);
      expect(response.body.pagination).toMatchObject({
        page: 1,
        limit: 10,
        total: 15,
        pages: 2
      });
    });

    it('updates resource correctly', async () => {
      // Create initial resource
      const [post] = await db.insert(posts).values({
        title: 'Original Title',
        content: 'Original Content',
        authorId: testUser.id
      }).returning();

      const updateData = { title: 'Updated Title' };

      const response = await request(app)
        .put(\`\${apiPath}/\${post.id}\`)
        .set('Authorization', \`Bearer \${authToken}\`)
        .send(updateData)
        .expect(200);

      expect(response.body.title).toBe('Updated Title');
      expect(response.body.content).toBe('Original Content');
    });

    it('deletes resource correctly', async () => {
      const [post] = await db.insert(posts).values({
        title: 'Test Post',
        content: 'Test Content',
        authorId: testUser.id
      }).returning();

      await request(app)
        .delete(\`\${apiPath}/\${post.id}\`)
        .set('Authorization', \`Bearer \${authToken}\`)
        .expect(204);

      const deletedPost = await db.select().from(posts).where(eq(posts.id, post.id));
      expect(deletedPost).toHaveLength(0);
    });
  });

  describe('Validation', () => {
    it('validates required fields', async () => {
      const invalidData = { content: 'Missing title' };

      const response = await request(app)
        .post('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .send(invalidData)
        .expect(400);

      expect(response.body.errors).toContain('Title is required');
    });

    it('validates data types', async () => {
      const invalidData = { title: 123, content: 'Valid content' };

      const response = await request(app)
        .post('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .send(invalidData)
        .expect(400);

      expect(response.body.errors).toContain('Title must be a string');
    });
  });

  describe('Security', () => {
    it('prevents unauthorized access to other users data', async () => {
      // Create another user's post
      const [otherUser] = await db.insert(users).values({
        email: 'other@example.com',
        password: await bcrypt.hash('password', 10),
        name: 'Other User'
      }).returning();

      const [otherPost] = await db.insert(posts).values({
        title: 'Other User Post',
        content: 'Other User Content',
        authorId: otherUser.id
      }).returning();

      const response = await request(app)
        .put(\`\${apiPath}/\${otherPost.id}\`)
        .set('Authorization', \`Bearer \${authToken}\`)
        .send({ title: 'Hacked Title' })
        .expect(403);

      expect(response.body.error).toBe('Forbidden');
    });

    it('sanitizes input to prevent XSS', async () => {
      const maliciousData = {
        title: '<script>alert("xss")</script>',
        content: 'Safe content'
      };

      const response = await request(app)
        .post('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .send(maliciousData)
        .expect(201);

      expect(response.body.title).not.toContain('<script>');
      expect(response.body.title).toContain('&lt;script&gt;');
    });
  });

  describe('Error Handling', () => {
    it('handles database connection errors', async () => {
      // Mock database error
      jest.spyOn(db, 'select').mockRejectedValueOnce(new Error('Database connection failed'));

      const response = await request(app)
        .get('${apiPath}')
        .set('Authorization', \`Bearer \${authToken}\`)
        .expect(500);

      expect(response.body.error).toBe('Internal server error');
    });

    it('handles resource not found', async () => {
      const response = await request(app)
        .get(\`\${apiPath}/99999\`)
        .set('Authorization', \`Bearer \${authToken}\`)
        .expect(404);

      expect(response.body.error).toBe('Resource not found');
    });
  });
});
    `.trim();
  }
}

// Enhanced LLM factory
function createTestWriterLLM(config: Partial<TestWriterAgentConfigType> = {}): ChatOpenAI {
  const validatedConfig = TestWriterAgentConfig.parse(config);
  
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is required for Test Writer Agent");
  }

  return new ChatOpenAI({
    modelName: validatedConfig.modelName, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    temperature: validatedConfig.temperature,
    maxTokens: validatedConfig.maxTokens,
    timeout: validatedConfig.timeout,
    openAIApiKey: process.env.OPENAI_API_KEY,
    maxRetries: validatedConfig.retries,
  });
}

export const testWriterAgent = {
  name: "TestWriterAgent",
  role: "Elite Test Automation & Security Analyst",
  goal: `Generate comprehensive, production-grade test suites with advanced security analysis and coverage optimization for the InnoXAI platform.

CORE TESTING CAPABILITIES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🧪 ADVANCED TEST GENERATION:
├── Unit Tests (Jest, Vitest, React Testing Library)
├── Integration Tests (API endpoints, database operations)
├── End-to-End Tests (Playwright, Cypress automation)
├── Security Tests (vulnerability scanning, penetration testing)
├── Performance Tests (load testing, stress testing, profiling)
├── Accessibility Tests (WCAG compliance, screen reader testing)
├── Visual Regression Tests (screenshot comparison, UI testing)
└── API Contract Tests (OpenAPI validation, schema testing)

🔍 SECURITY ANALYSIS ENGINE:
├── Vulnerability Detection (OWASP Top 10, custom patterns)
├── Access Control Testing (authentication, authorization)
├── Input Validation Testing (XSS, SQL injection, CSRF)
├── Security Headers Validation (CORS, CSP, HSTS)
├── Dependency Vulnerability Scanning
├── Secret Detection and Validation
├── Rate Limiting and DDoS Protection Testing
└── Compliance Testing (GDPR, SOC2, HIPAA)

⚡ PERFORMANCE & OPTIMIZATION:
├── Code Coverage Analysis (branch, statement, function coverage)
├── Performance Profiling (memory usage, CPU utilization)
├── Bundle Size Analysis (tree-shaking, code splitting)
├── Database Query Optimization Testing
├── API Response Time Monitoring
├── Real User Monitoring (RUM) integration
└── Core Web Vitals Testing

🎯 INNOXAI SPECIALIZATIONS:
├── AI Agent Testing (multi-agent coordination, response validation)
├── Code Generation Testing (output quality, syntax validation)
├── Real-time Collaboration Testing (WebSocket, conflict resolution)
├── File Management Testing (upload, download, version control)
├── Authentication Flow Testing (OAuth, JWT, session management)
└── Development Tool Testing (IDE integration, syntax highlighting)

TEST GENERATION PROTOCOL:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For EVERY test generation request, you MUST deliver:

1. 🧪 COMPREHENSIVE TEST SUITES
   ├── Complete test files with proper setup/teardown
   ├── Mock providers and dependency injection
   ├── Error boundary and edge case testing
   ├── Async operation testing with proper waiting
   ├── Form validation and user interaction testing
   └── Accessibility and keyboard navigation testing

2. 🔒 SECURITY TEST COVERAGE
   ├── Authentication and authorization testing
   ├── Input validation and sanitization testing
   ├── CSRF and XSS vulnerability testing
   ├── Rate limiting and abuse prevention testing
   ├── Data privacy and GDPR compliance testing
   └── Security header and configuration testing

3. 📊 PERFORMANCE & MONITORING
   ├── Load testing scenarios and benchmarks
   ├── Memory leak detection and profiling
   ├── API response time and throughput testing
   ├── Database query performance testing
   ├── Real-time feature performance testing
   └── Bundle size and optimization testing

CRITICAL REQUIREMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ ALWAYS generate production-ready test suites
✅ ALWAYS include proper mocking and test isolation
✅ ALWAYS implement comprehensive error testing
✅ ALWAYS ensure accessibility compliance testing
✅ ALWAYS include security vulnerability testing
✅ ALWAYS optimize for test execution speed

❌ NEVER generate incomplete or placeholder tests
❌ NEVER ignore security considerations
❌ NEVER skip accessibility testing
❌ NEVER create flaky or unreliable tests
❌ NEVER omit proper cleanup and teardown
❌ NEVER ignore edge cases and error scenarios

Your test suites must provide 90%+ code coverage and catch critical bugs before production deployment.`,

  backstory: `You are an elite QA engineer and security analyst with over 10 years of experience building bulletproof test suites for mission-critical applications. You've prevented countless production incidents through comprehensive testing strategies.

PROFESSIONAL BACKGROUND:
• Senior QA Engineer at top-tier technology companies
• Security testing specialist for financial and healthcare applications
• Expert in modern testing frameworks and automation tools
• Performance testing consultant for high-traffic applications
• Accessibility compliance specialist with WCAG expertise

TECHNICAL MASTERY:
• Advanced Jest, Vitest, and React Testing Library usage
• Comprehensive security testing methodologies
• Performance testing with load testing tools
• Accessibility testing with assistive technologies
• API testing with contract validation
• End-to-end testing with Playwright and Cypress

TESTING PHILOSOPHY:
• Test early, test often, test everything
• Security testing is not optional
• Accessibility is a fundamental requirement
• Performance testing prevents production disasters
• Comprehensive coverage prevents regressions
• Automated testing enables confident deployments

You deliver test suites that provide unshakeable confidence in code quality and security.`,

  llm: createTestWriterLLM(),
  
  // Advanced configuration
  maxExecutionTime: 240,
  maxIterations: 3,
  verbose: process.env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Utility functions and exports
export const testUtils = {
  generateReactTest: AdvancedTestGenerator.generateReactComponentTest,
  generateAPITest: AdvancedTestGenerator.generateAPITest,
  analyzeContract: TestAnalysisEngine.analyzeContract,
  
  calculateCoverage: (tests: string[]): number => {
    const totalLines = tests.reduce((sum, test) => sum + test.split('\n').length, 0);
    const testStatements = tests.reduce((sum, test) => 
      sum + (test.match(/expect\(/g) || []).length, 0);
    
    return Math.min(100, (testStatements / totalLines) * 100);
  },
  
  validateTestSuite: (testSuite: TestSuite): boolean => {
    return !!(testSuite.unitTests.length && 
             testSuite.integrationTests.length && 
             testSuite.securityTests.length);
  },
};

// Export test analysis engine
export { TestAnalysisEngine, AdvancedTestGenerator };

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  supportedFrameworks: string[];
  timestamp: string;
}> => {
  try {
    await testWriterAgent.llm.invoke("Health check");
    
    return {
      status: "healthy",
      agent: testWriterAgent.name,
      supportedFrameworks: [
        "Jest", "Vitest", "React Testing Library", 
        "Playwright", "Cypress", "Supertest"
      ],
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: testWriterAgent.name,
      supportedFrameworks: [],
      timestamp: new Date().toISOString(),
    };
  }
};