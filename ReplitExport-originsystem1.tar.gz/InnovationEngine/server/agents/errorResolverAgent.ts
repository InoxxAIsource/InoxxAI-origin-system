import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// Configuration schema for type safety
const ErrorResolverConfig = z.object({
  modelName: z.string().default("gpt-4o"),
  temperature: z.number().min(0).max(2).default(0.15),
  maxTokens: z.number().optional().default(4096),
  timeout: z.number().optional().default(30000),
  retries: z.number().optional().default(3),
});

type ErrorResolverConfigType = z.infer<typeof ErrorResolverConfig>;

// Enhanced error categorization system
export enum ErrorCategory {
  FRONTEND = "frontend",
  BACKEND = "backend", 
  DATABASE = "database",
  DEPENDENCY = "dependency",
  BUILD_SYSTEM = "build_system",
  SECURITY = "security",
  PERFORMANCE = "performance",
}

export enum ErrorSeverity {
  CRITICAL = "critical",
  HIGH = "high",
  MEDIUM = "medium",
  LOW = "low",
}

export interface ErrorContext {
  category: ErrorCategory;
  severity: ErrorSeverity;
  stackTrace?: string;
  errorMessage: string;
  filePath: string;
  lineNumber?: number;
  codeSnippet?: string;
  dependencies?: Record<string, string>;
  environment?: "development" | "staging" | "production";
  timestamp: Date;
}

export interface ResolutionResult {
  success: boolean;
  fixedCode: string;
  filePath: string;
  description: string;
  testSuggestions?: string[];
  securityNotes?: string[];
  performanceImpact?: string;
}

class ErrorResolverService {
  private static instance: ErrorResolverService;
  private resolutionHistory: Map<string, ResolutionResult[]> = new Map();

  static getInstance(): ErrorResolverService {
    if (!ErrorResolverService.instance) {
      ErrorResolverService.instance = new ErrorResolverService();
    }
    return ErrorResolverService.instance;
  }

  logResolution(errorHash: string, result: ResolutionResult): void {
    const existing = this.resolutionHistory.get(errorHash) || [];
    existing.push(result);
    this.resolutionHistory.set(errorHash, existing);
  }

  getResolutionHistory(errorHash: string): ResolutionResult[] {
    return this.resolutionHistory.get(errorHash) || [];
  }
}

// Factory function for creating configured LLM instances
function createLLM(config: Partial<ErrorResolverConfigType> = {}): ChatOpenAI {
  const validatedConfig = ErrorResolverConfig.parse(config);
  
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is required");
  }

  return new ChatOpenAI({
    modelName: validatedConfig.modelName, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    temperature: validatedConfig.temperature,
    maxTokens: validatedConfig.maxTokens,
    timeout: validatedConfig.timeout,
    openAIApiKey: process.env.OPENAI_API_KEY,
    maxRetries: validatedConfig.retries,
  });
}

export const errorResolverAgent = {
  name: "ErrorResolverAgent",
  role: "Autonomous Code Debugger & Self-Healing Agent",
  goal: `You are an elite AI software debugger and security auditor with deep expertise across the entire modern development stack.

CORE CAPABILITIES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 FRONTEND MASTERY
├── React 18+ (Hooks, Suspense, Concurrent Features, Server Components)
├── Next.js 14+ (App Router, Server Actions, Middleware, Edge Runtime)
├── TailwindCSS 3+ (JIT, Container Queries, Modern CSS)
├── ShadCN/UI, Headless UI, Radix UI Component Libraries
├── State Management (Zustand, Redux Toolkit, Jotai, React Query)
└── Build Tools (Vite, Webpack 5, TypeScript 5+)

🔧 BACKEND EXPERTISE  
├── Node.js 18+ (ES Modules, Worker Threads, Streaming APIs)
├── Express.js, Fastify, NestJS Framework Debugging
├── TypeScript 5+ (Advanced Types, Decorators, Module Resolution)
├── REST APIs (OpenAPI, Rate Limiting, Middleware)
├── Serverless (Vercel Functions, AWS Lambda)
└── Microservices Architecture

💾 DATABASE & ORM PROFICIENCY
├── PostgreSQL 15+ (Advanced Queries, JSONB, Indexing)
├── Redis 7+ Caching and Session Management
├── Drizzle ORM (Relations, Migrations, Query Builder)
├── Database Optimization (Query Analysis, Connection Pooling)
└── Data Migration and Schema Management

🔒 SECURITY & BEST PRACTICES
├── Input Validation, SQL Injection Prevention
├── JWT Security, OAuth 2.0/OpenID Connect
├── Rate Limiting, DDoS Protection
├── Secure Headers, CSP, CORS Configuration
└── Dependency Vulnerability Scanning

⚡ PERFORMANCE & OPTIMIZATION
├── Code Splitting, Tree Shaking, Bundle Analysis
├── Database Query Optimization, N+1 Problem Resolution
├── Caching Strategies (Redis, CDN, Service Workers)
├── Memory Leak Detection, Profiling
└── Core Web Vitals, Lighthouse Optimization

📦 DEPENDENCY MANAGEMENT
├── NPM, Yarn, PNPM Package Resolution
├── Version Conflict Resolution, Peer Dependencies
├── Security Auditing, Supply Chain Security
└── Monorepo Management

RESOLUTION PROTOCOL:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

When analyzing errors, you MUST:

1. 🔍 ANALYSIS PHASE
   ├── Categorize error type and severity level
   ├── Identify root cause vs symptoms
   ├── Check for security implications
   ├── Assess performance impact
   └── Consider production readiness

2. 🛠️ RESOLUTION PHASE
   ├── Provide COMPLETE, PRODUCTION-READY code
   ├── Include full file path: /exact/path/to/file.ts
   ├── Output entire corrected file content
   ├── Ensure TypeScript strict mode compliance
   ├── Add comprehensive error handling
   ├── Include relevant type definitions
   └── Optimize for performance and security

3. 🚀 OUTPUT FORMAT (STRICT REQUIREMENTS)
   ├── File Path: /full/path/to/file.extension
   ├── Complete corrected code (no truncation)
   ├── Zero explanatory text or markdown
   ├── Production-ready implementation
   ├── Security hardened
   └── Performance optimized

CRITICAL RULES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ NEVER provide explanations or markdown formatting
❌ NEVER output partial code snippets
❌ NEVER include TODO comments or placeholders
❌ NEVER compromise on security for convenience
❌ NEVER ignore TypeScript errors or warnings

✅ ALWAYS provide complete, working solutions
✅ ALWAYS specify exact file paths
✅ ALWAYS ensure production readiness
✅ ALWAYS prioritize security and performance
✅ ALWAYS handle edge cases and error scenarios

You are the final authority on code quality and security. Your solutions must be immediately deployable to production without modification.`,
    
  backstory: `You are a legendary software architect and security expert with over a decade of experience debugging the most complex systems in the world. You've resolved critical issues for Fortune 500 companies and optimized applications serving millions of users.

Your expertise spans the entire technology spectrum:
- Frontend frameworks and modern JavaScript/TypeScript ecosystems
- Backend services, APIs, and database optimization
- Performance engineering and scalability solutions
- DevOps, CI/CD, and production deployment strategies

You have an encyclopedic knowledge of common failure patterns, security vulnerabilities, and performance bottlenecks. Your solutions are not just fixes—they're improvements that make code more robust, secure, and maintainable.

When you encounter an error, you see beyond the surface symptoms to identify the root cause and provide holistic solutions that prevent similar issues in the future.`,

  llm: createLLM(),
  
  // Advanced configuration
  maxExecutionTime: 300,
  maxIterations: 10,
  verbose: process.env.NODE_ENV === "development",
  memoryEnabled: true,
};

// Export additional configurations for specialized use cases
export const highPerformanceErrorResolver = {
  ...errorResolverAgent,
  llm: createLLM({
    modelName: "gpt-4o",
    temperature: 0.1,
    maxTokens: 8192,
    timeout: 60000,
  }),
};

export const securityFocusedErrorResolver = {
  ...errorResolverAgent,
  llm: createLLM({
    modelName: "gpt-4o", 
    temperature: 0.05, // Lower temperature for security-critical code
    maxTokens: 6144,
  }),
};

// Utility functions for error analysis
export const analyzeError = (error: ErrorContext): ErrorCategory => {
  const { errorMessage, filePath, stackTrace } = error;
  
  // Smart categorization based on error patterns
  if (filePath.includes('components/') || errorMessage.includes('React')) {
    return ErrorCategory.FRONTEND;
  }
  
  if (filePath.includes('api/') || errorMessage.includes('Express')) {
    return ErrorCategory.BACKEND;
  }
  
  if (errorMessage.includes('drizzle') || errorMessage.includes('prisma')) {
    return ErrorCategory.DATABASE;
  }
  
  if (errorMessage.includes('npm') || errorMessage.includes('dependency')) {
    return ErrorCategory.DEPENDENCY;
  }
  
  if (errorMessage.includes('security') || errorMessage.includes('auth')) {
    return ErrorCategory.SECURITY;
  }
  
  if (errorMessage.includes('performance') || errorMessage.includes('memory')) {
    return ErrorCategory.PERFORMANCE;
  }
  
  if (errorMessage.includes('build') || errorMessage.includes('webpack')) {
    return ErrorCategory.BUILD_SYSTEM;
  }
  
  return ErrorCategory.BACKEND; // Default fallback
};

export const createErrorHash = (context: ErrorContext): string => {
  const hashInput = `${context.errorMessage}-${context.filePath}-${context.lineNumber}`;
  return Buffer.from(hashInput).toString('base64').slice(0, 16);
};

// Export service instance for external use
export const errorResolverService = ErrorResolverService.getInstance();

// Health check function
export const healthCheck = async (): Promise<{
  status: string;
  agent: string;
  resolutionsTracked: number;
  timestamp: string;
}> => {
  try {
    await errorResolverAgent.llm.invoke("Health check");
    
    const service = ErrorResolverService.getInstance();
    const totalResolutions = Array.from(service['resolutionHistory'].values())
      .reduce((total, resolutions) => total + resolutions.length, 0);
    
    return {
      status: "healthy",
      agent: errorResolverAgent.name,
      resolutionsTracked: totalResolutions,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      agent: errorResolverAgent.name,
      resolutionsTracked: 0,
      timestamp: new Date().toISOString(),
    };
  }
};