import path from 'path';
import { 
  writeGeneratedFile, 
  readGeneratedFile,
  deleteGeneratedFile,
  Logger 
} from "./fileWriter";
import OpenAI from "openai";

// Code formatter utility
class CodeFormatter {
  static async format(code: string, filePath: string): Promise<string> {
    const extension = path.extname(filePath);
    
    switch (extension) {
      case '.tsx':
      case '.ts':
        return this.formatTypeScript(code);
      case '.js':
      case '.jsx':
        return this.formatJavaScript(code);
      case '.css':
        return this.formatCSS(code);
      case '.json':
        return this.formatJSON(code);
      default:
        return code;
    }
  }

  private static formatTypeScript(code: string): string {
    // Basic TypeScript formatting
    let formatted = code
      .replace(/;\s*}/g, ';\n}')
      .replace(/{\s*/g, '{\n  ')
      .replace(/}\s*/g, '\n}\n')
      .replace(/,\s*/g, ',\n  ');
    
    return formatted.trim();
  }

  private static formatJavaScript(code: string): string {
    // Basic JavaScript formatting
    return this.formatTypeScript(code);
  }

  private static formatCSS(code: string): string {
    // Basic CSS formatting
    return code
      .replace(/{\s*/g, ' {\n  ')
      .replace(/;\s*/g, ';\n  ')
      .replace(/}\s*/g, '\n}\n');
  }

  private static formatJSON(code: string): string {
    try {
      return JSON.stringify(JSON.parse(code), null, 2);
    } catch {
      return code;
    }
  }
}

// Code validator utility
class CodeValidator {
  static async validateTypeScript(code: string): Promise<void> {
    // Basic TypeScript validation
    const issues: string[] = [];
    
    // Check for missing imports
    if (code.includes('React') && !code.includes("import React") && !code.includes("import { ")) {
      issues.push("Missing React import");
    }
    
    // Check for unmatched brackets
    const openBrackets = (code.match(/\[/g) || []).length;
    const closeBrackets = (code.match(/\]/g) || []).length;
    if (openBrackets !== closeBrackets) {
      issues.push("Unmatched square brackets");
    }
    
    // Check for unmatched parentheses
    const openParens = (code.match(/\(/g) || []).length;
    const closeParens = (code.match(/\)/g) || []).length;
    if (openParens !== closeParens) {
      issues.push("Unmatched parentheses");
    }
    
    if (issues.length > 0) {
      throw new Error(`TypeScript validation failed: ${issues.join(', ')}`);
    }
  }
}

export class EnhancedCodeWriterAgent {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  public async generateComponent(
    componentPath: string,
    componentCode: string,
    options: {
      overwrite?: boolean;
      formatCode?: boolean;
      validate?: boolean;
    } = {}
  ): Promise<void> {
    const finalOptions = {
      overwrite: true,
      formatCode: true,
      validate: true,
      ...options
    };

    try {
      Logger.info(`Generating component: ${componentPath}`);

      // 1. Format the code if enabled
      let processedCode = finalOptions.formatCode
        ? await CodeFormatter.format(componentCode, componentPath)
        : componentCode;

      // 2. Validate the code if enabled
      if (finalOptions.validate) {
        await CodeValidator.validateTypeScript(processedCode);
      }

      // 3. Write the file with enhanced options
      await writeGeneratedFile(componentPath, processedCode, {
        overwrite: finalOptions.overwrite,
        backup: true,
        validateContent: finalOptions.validate
      });

      Logger.success(`Successfully generated ${componentPath}`);
      
      // 4. Post-generation hook
      await this.postGenerationHook(componentPath);

    } catch (error) {
      Logger.error(`Failed to generate ${componentPath}:`, error);
      throw new Error(`Component generation failed: ${(error as Error).message}`);
    }
  }

  private async postGenerationHook(filePath: string): Promise<void> {
    try {
      // Update the component index if it's a component
      if (filePath.includes('components/') && filePath.endsWith('.tsx')) {
        await this.updateComponentsIndex(filePath);
      }
    } catch (hookError) {
      Logger.warn(`Post-generation hook failed for ${filePath}:`, hookError);
    }
  }

  private async updateComponentsIndex(newComponentPath: string): Promise<void> {
    const indexPath = 'components/index.ts';
    const componentName = path.basename(newComponentPath, '.tsx');
    
    try {
      // Read existing index file
      let indexContent = '';
      try {
        indexContent = await readGeneratedFile(indexPath);
      } catch (readError: any) {
        if (readError.code === 'ENOENT') {
          indexContent = '// Auto-generated components index\n\n';
        } else {
          throw readError;
        }
      }

      // Add new export if not already present
      if (!indexContent.includes(`from './${componentName}'`)) {
        const newExport = `export { default as ${componentName} } from './${componentName}';\n`;
        await writeGeneratedFile(indexPath, indexContent + newExport, {
          backup: true
        });
        Logger.debug(`Updated components index with ${componentName}`);
      }
    } catch (error) {
      Logger.error(`Failed to update components index:`, error);
      throw error;
    }
  }

  // AI-powered code generation
  public async generateCodeWithAI(
    prompt: string,
    fileType: 'component' | 'utility' | 'hook' | 'service' = 'component'
  ): Promise<string> {
    try {
      const systemPrompt = this.getSystemPrompt(fileType);
      
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 2000
      });

      const generatedCode = response.choices[0].message.content || '';
      Logger.debug(`Generated ${fileType} code: ${generatedCode.length} characters`);
      
      return generatedCode;
    } catch (error) {
      Logger.error(`AI code generation failed:`, error);
      throw new Error(`Failed to generate code: ${(error as Error).message}`);
    }
  }

  private getSystemPrompt(fileType: string): string {
    const basePrompt = `You are an expert software developer. Generate clean, production-ready code that follows best practices.`;
    
    switch (fileType) {
      case 'component':
        return `${basePrompt} Generate React TypeScript components using modern patterns. Include proper TypeScript types, error handling, and accessibility features. Use functional components with hooks.`;
      
      case 'utility':
        return `${basePrompt} Generate utility functions and helper modules. Include proper error handling, TypeScript types, and comprehensive JSDoc documentation.`;
      
      case 'hook':
        return `${basePrompt} Generate custom React hooks following hooks rules and patterns. Include proper TypeScript types and error handling.`;
      
      case 'service':
        return `${basePrompt} Generate service modules for API calls, data processing, or business logic. Include proper error handling, TypeScript types, and async/await patterns.`;
      
      default:
        return basePrompt;
    }
  }

  // Template-based generation
  public async processComponentGeneration(task: {
    componentName: string;
    template: string;
    props: Record<string, string>;
  }): Promise<void> {
    const componentPath = `components/${task.componentName}.tsx`;
    let generatedCode = task.template;

    // Replace template variables
    for (const [key, value] of Object.entries(task.props)) {
      generatedCode = generatedCode.replace(new RegExp(`{{${key}}}`, 'g'), value);
    }

    // Generate the component file
    await this.generateComponent(componentPath, generatedCode, {
      overwrite: false, // Don't overwrite existing components
      formatCode: true
    });
  }

  // Batch file generation with rollback capability
  public async generateMultipleFiles(
    files: Array<{
      path: string;
      content: string;
      options?: any;
    }>
  ): Promise<void> {
    const createdFiles: string[] = [];
    
    try {
      for (const file of files) {
        await this.generateComponent(file.path, file.content, file.options);
        createdFiles.push(file.path);
      }
      
      Logger.success(`Successfully generated ${files.length} files`);
    } catch (error) {
      Logger.error(`Batch generation failed, rolling back created files`);
      
      // Rollback created files
      for (const filePath of createdFiles.reverse()) {
        try {
          await deleteGeneratedFile(filePath);
          Logger.debug(`Rolled back: ${filePath}`);
        } catch (rollbackError) {
          Logger.error(`Failed to rollback ${filePath}:`, rollbackError);
        }
      }
      
      throw error;
    }
  }

  // Project structure generation
  public async generateProjectStructure(
    projectType: 'react-app' | 'node-api' | 'fullstack'
  ): Promise<void> {
    const structures = {
      'react-app': [
        { path: 'components/index.ts', content: '// Components index\n' },
        { path: 'hooks/index.ts', content: '// Custom hooks index\n' },
        { path: 'utils/index.ts', content: '// Utilities index\n' },
        { path: 'types/index.ts', content: '// Type definitions\n' },
        { path: 'services/api.ts', content: '// API service layer\n' }
      ],
      'node-api': [
        { path: 'controllers/index.ts', content: '// Controllers\n' },
        { path: 'models/index.ts', content: '// Data models\n' },
        { path: 'middleware/index.ts', content: '// Middleware\n' },
        { path: 'routes/index.ts', content: '// API routes\n' },
        { path: 'utils/index.ts', content: '// Utilities\n' }
      ],
      'fullstack': [
        { path: 'client/components/index.ts', content: '// Client components\n' },
        { path: 'client/pages/index.ts', content: '// Client pages\n' },
        { path: 'server/controllers/index.ts', content: '// Server controllers\n' },
        { path: 'server/models/index.ts', content: '// Server models\n' },
        { path: 'shared/types/index.ts', content: '// Shared types\n' }
      ]
    };

    const structure = structures[projectType];
    if (!structure) {
      throw new Error(`Unknown project type: ${projectType}`);
    }

    await this.generateMultipleFiles(structure);
    Logger.success(`Generated ${projectType} project structure`);
  }

  // Code analysis and improvement suggestions
  public async analyzeCode(filePath: string): Promise<{
    issues: string[];
    suggestions: string[];
    metrics: any;
  }> {
    try {
      const content = await readGeneratedFile(filePath);
      const lines = content.split('\n');
      
      const issues: string[] = [];
      const suggestions: string[] = [];
      
      // Basic code analysis
      if (content.length > 10000) {
        issues.push('File is very large, consider splitting into smaller modules');
      }
      
      if (lines.length > 300) {
        issues.push('File has many lines, consider refactoring');
      }
      
      if (!content.includes('export')) {
        issues.push('No exports found, file may not be reusable');
      }
      
      // Suggestions based on patterns
      if (content.includes('useState') && !content.includes('useCallback')) {
        suggestions.push('Consider using useCallback for event handlers');
      }
      
      return {
        issues,
        suggestions,
        metrics: {
          lines: lines.length,
          characters: content.length,
          functions: (content.match(/function\s+\w+/g) || []).length,
          imports: (content.match(/^import\s+/gm) || []).length
        }
      };
    } catch (error) {
      Logger.error(`Code analysis failed for ${filePath}:`, error);
      throw error;
    }
  }
}

// Singleton instance for convenience
export const enhancedCodeWriterAgent = new EnhancedCodeWriterAgent();