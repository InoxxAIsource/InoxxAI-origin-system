import fs from "fs";
import path from "path";
import crypto from "crypto";
import { promisify } from "util";

const PROJECT_ROOT = path.resolve(__dirname, "../../..");

// Configuration for file loading
const CONFIG = {
  // Maximum file size in bytes (10MB default)
  MAX_FILE_SIZE: 10 * 1024 * 1024,
  
  // Cache settings
  CACHE_TTL: 5 * 60 * 1000, // 5 minutes
  MAX_CACHE_SIZE: 100, // Maximum number of files to cache
  
  // Encoding detection patterns
  BINARY_EXTENSIONS: [
    '.exe', '.dll', '.so', '.dylib', '.bin', '.img', '.iso',
    '.zip', '.tar', '.gz', '.rar', '.7z', '.bz2',
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.ico', '.svg',
    '.mp3', '.mp4', '.avi', '.mov', '.wmv', '.flv',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'
  ],
  
  // Text file encodings to try
  ENCODINGS: ['utf8', 'latin1', 'ascii', 'utf16le'] as const,
  
  // Maximum lines to load (for very large files)
  MAX_LINES: 10000,
  
  // Retry configuration
  MAX_RETRIES: 3,
  RETRY_DELAY: 100
};

export interface FileContent {
  content: string;
  encoding: string;
  size: number;
  lines: number;
  truncated: boolean;
  hash: string;
  lastModified: Date;
  relativePath: string;
  absolutePath: string;
}

export interface LoadOptions {
  encoding?: BufferEncoding | 'auto';
  maxSize?: number;
  maxLines?: number;
  useCache?: boolean;
  stripBOM?: boolean;
  preserveLineEndings?: boolean;
  includeMetadata?: boolean;
  timeout?: number;
}

export interface LoadResult {
  success: boolean;
  content?: FileContent;
  error?: string;
  cached?: boolean;
}

interface CacheEntry {
  content: FileContent;
  timestamp: number;
  accessCount: number;
}

class FileContentCache {
  private cache = new Map<string, CacheEntry>();
  private maxSize: number;
  private ttl: number;
  
  constructor(maxSize: number = CONFIG.MAX_CACHE_SIZE, ttl: number = CONFIG.CACHE_TTL) {
    this.maxSize = maxSize;
    this.ttl = ttl;
  }
  
  get(filePath: string, lastModified: Date): FileContent | null {
    const entry = this.cache.get(filePath);
    if (!entry) return null;
    
    // Check if entry is expired
    if (Date.now() - entry.timestamp > this.ttl) {
      this.cache.delete(filePath);
      return null;
    }
    
    // Check if file was modified since cache
    if (lastModified > new Date(entry.timestamp)) {
      this.cache.delete(filePath);
      return null;
    }
    
    entry.accessCount++;
    return entry.content;
  }
  
  set(filePath: string, content: FileContent): void {
    // Evict oldest entries if cache is full
    if (this.cache.size >= this.maxSize) {
      const oldestKey = this.findOldestEntry();
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }
    
    this.cache.set(filePath, {
      content,
      timestamp: Date.now(),
      accessCount: 1
    });
  }
  
  private findOldestEntry(): string | null {
    let oldestKey: string | null = null;
    let oldestTime = Date.now();
    
    const entries = Array.from(this.cache.entries());
    for (const [key, entry] of entries) {
      if (entry.timestamp < oldestTime) {
        oldestTime = entry.timestamp;
        oldestKey = key;
      }
    }
    
    return oldestKey;
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  getStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      hitRate: this.calculateHitRate()
    };
  }
  
  private calculateHitRate(): number {
    if (this.cache.size === 0) return 0;
    const totalAccess = Array.from(this.cache.values())
      .reduce((sum, entry) => sum + entry.accessCount, 0);
    return totalAccess / this.cache.size;
  }
}

class FileContentLoader {
  private cache: FileContentCache;
  private readFileAsync = promisify(fs.readFile);
  private statAsync = promisify(fs.stat);
  
  constructor() {
    this.cache = new FileContentCache();
  }
  
  private async sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  private detectEncoding(buffer: Buffer): BufferEncoding {
    // Check for BOM markers
    if (buffer.length >= 3 && buffer[0] === 0xEF && buffer[1] === 0xBB && buffer[2] === 0xBF) {
      return 'utf8';
    }
    if (buffer.length >= 2 && buffer[0] === 0xFF && buffer[1] === 0xFE) {
      return 'utf16le';
    }
    if (buffer.length >= 2 && buffer[0] === 0xFE && buffer[1] === 0xFF) {
      return 'utf16le'; // Will need byte swapping, but Node.js handles this
    }
    
    // Simple heuristic: check for null bytes (likely binary)
    for (let i = 0; i < Math.min(buffer.length, 8192); i++) {
      if (buffer[i] === 0) {
        return 'latin1'; // Fallback for binary-like content
      }
    }
    
    // Default to UTF-8 for text files
    return 'utf8';
  }
  
  private isBinaryFile(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return CONFIG.BINARY_EXTENSIONS.includes(ext);
  }
  
  private stripBOM(content: string): string {
    if (content.charCodeAt(0) === 0xFEFF) {
      return content.slice(1);
    }
    return content;
  }
  
  private normalizeLineEndings(content: string, preserve: boolean): string {
    if (preserve) return content;
    return content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  }
  
  private truncateContent(content: string, maxLines: number): { content: string; truncated: boolean } {
    const lines = content.split('\n');
    if (lines.length <= maxLines) {
      return { content, truncated: false };
    }
    
    const truncatedContent = lines.slice(0, maxLines).join('\n');
    return { content: truncatedContent, truncated: true };
  }
  
  private generateHash(content: string): string {
    return crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
  }
  
  private async loadWithRetry(filePath: string, options: LoadOptions): Promise<LoadResult> {
    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= CONFIG.MAX_RETRIES; attempt++) {
      try {
        return await this.loadFileInternal(filePath, options);
      } catch (error) {
        lastError = error as Error;
        
        if (attempt < CONFIG.MAX_RETRIES) {
          await this.sleep(CONFIG.RETRY_DELAY * attempt);
        }
      }
    }
    
    return {
      success: false,
      error: `Failed after ${CONFIG.MAX_RETRIES} attempts: ${lastError?.message}`
    };
  }
  
  private async loadFileInternal(filePath: string, options: LoadOptions): Promise<LoadResult> {
    const fullPath = path.join(PROJECT_ROOT, filePath);
    
    // Check if file exists
    if (!fs.existsSync(fullPath)) {
      return {
        success: false,
        error: `File not found: ${filePath}`
      };
    }
    
    // Get file stats
    const stats = await this.statAsync(fullPath);
    
    // Check file size
    const maxSize = options.maxSize ?? CONFIG.MAX_FILE_SIZE;
    if (stats.size > maxSize) {
      return {
        success: false,
        error: `File too large: ${stats.size} bytes (max: ${maxSize})`
      };
    }
    
    // Check cache if enabled
    if (options.useCache) {
      const cached = this.cache.get(filePath, stats.mtime);
      if (cached) {
        return {
          success: true,
          content: cached,
          cached: true
        };
      }
    }
    
    // Check if file is binary
    if (this.isBinaryFile(fullPath)) {
      return {
        success: false,
        error: `Binary file not supported: ${filePath}`
      };
    }
    
    // Read file content
    let buffer: Buffer;
    if (options.timeout) {
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('File read timeout')), options.timeout);
      });
      buffer = await Promise.race([this.readFileAsync(fullPath), timeoutPromise]);
    } else {
      buffer = await this.readFileAsync(fullPath);
    }
    
    // Detect or use specified encoding
    let encoding: BufferEncoding;
    if (options.encoding === 'auto' || !options.encoding) {
      encoding = this.detectEncoding(buffer);
    } else {
      encoding = options.encoding as BufferEncoding;
    }
    
    // Convert to string
    let content = buffer.toString(encoding);
    
    // Strip BOM if requested
    if (options.stripBOM !== false) {
      content = this.stripBOM(content);
    }
    
    // Normalize line endings
    content = this.normalizeLineEndings(content, options.preserveLineEndings ?? false);
    
    // Truncate if needed
    const maxLines = options.maxLines ?? CONFIG.MAX_LINES;
    const { content: finalContent, truncated } = this.truncateContent(content, maxLines);
    
    // Create file content object
    const fileContent: FileContent = {
      content: finalContent,
      encoding,
      size: stats.size,
      lines: finalContent.split('\n').length,
      truncated,
      hash: this.generateHash(finalContent),
      lastModified: stats.mtime,
      relativePath: filePath,
      absolutePath: fullPath
    };
    
    // Cache if enabled
    if (options.useCache) {
      this.cache.set(filePath, fileContent);
    }
    
    return {
      success: true,
      content: fileContent
    };
  }
  
  async loadFile(filePath: string, options: LoadOptions = {}): Promise<LoadResult> {
    try {
      return await this.loadWithRetry(filePath, options);
    } catch (error) {
      return {
        success: false,
        error: (error as Error).message
      };
    }
  }
  
  async loadMultipleFiles(filePaths: string[], options: LoadOptions = {}): Promise<LoadResult[]> {
    const promises = filePaths.map(filePath => this.loadFile(filePath, options));
    return Promise.all(promises);
  }
  
  async loadFileContent(filePath: string, options: LoadOptions = {}): Promise<string> {
    const result = await this.loadFile(filePath, options);
    if (!result.success || !result.content) {
      throw new Error(result.error || 'Failed to load file');
    }
    return result.content.content;
  }
  
  clearCache(): void {
    this.cache.clear();
  }
  
  getCacheStats() {
    return this.cache.getStats();
  }
}

// Singleton instance for convenience
const defaultLoader = new FileContentLoader();

// Backward compatible function
export function loadFileContent(relativeFilePath: string): string {
  try {
    const fullPath = path.join(PROJECT_ROOT, relativeFilePath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${relativeFilePath}`);
    }
    return fs.readFileSync(fullPath, "utf-8");
  } catch (error) {
    throw new Error(`Failed to load file ${relativeFilePath}: ${(error as Error).message}`);
  }
}

// Enhanced async functions
export async function loadFileContentAsync(
  filePath: string, 
  options: LoadOptions = {}
): Promise<string> {
  return defaultLoader.loadFileContent(filePath, options);
}

export async function loadFileWithMetadata(
  filePath: string, 
  options: LoadOptions = {}
): Promise<LoadResult> {
  return defaultLoader.loadFile(filePath, options);
}

export async function loadMultipleFiles(
  filePaths: string[], 
  options: LoadOptions = {}
): Promise<LoadResult[]> {
  return defaultLoader.loadMultipleFiles(filePaths, options);
}

// Utility functions
export function isTextFile(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return !CONFIG.BINARY_EXTENSIONS.includes(ext);
}

export function getFileEncoding(filePath: string): BufferEncoding {
  const fullPath = path.join(PROJECT_ROOT, filePath);
  const buffer = fs.readFileSync(fullPath);
  const loader = new FileContentLoader();
  return loader['detectEncoding'](buffer);
}

export function clearFileCache(): void {
  defaultLoader.clearCache();
}

export function getFileCacheStats() {
  return defaultLoader.getCacheStats();
}

// Advanced file operations
export class FileContentBatch {
  private loader: FileContentLoader;
  private files: string[] = [];
  private options: LoadOptions = {};
  
  constructor(options: LoadOptions = {}) {
    this.loader = new FileContentLoader();
    this.options = options;
  }
  
  add(filePath: string): this {
    this.files.push(filePath);
    return this;
  }
  
  addMultiple(filePaths: string[]): this {
    this.files.push(...filePaths);
    return this;
  }
  
  async load(): Promise<Map<string, FileContent>> {
    const results = await this.loader.loadMultipleFiles(this.files, this.options);
    const map = new Map<string, FileContent>();
    
    results.forEach((result, index) => {
      if (result.success && result.content) {
        map.set(this.files[index], result.content);
      }
    });
    
    return map;
  }
  
  async loadSuccessful(): Promise<Map<string, FileContent>> {
    const results = await this.loader.loadMultipleFiles(this.files, this.options);
    const map = new Map<string, FileContent>();
    
    results.forEach((result, index) => {
      if (result.success && result.content) {
        map.set(this.files[index], result.content);
      }
    });
    
    return map;
  }
  
  async getErrors(): Promise<Map<string, string>> {
    const results = await this.loader.loadMultipleFiles(this.files, this.options);
    const errors = new Map<string, string>();
    
    results.forEach((result, index) => {
      if (!result.success && result.error) {
        errors.set(this.files[index], result.error);
      }
    });
    
    return errors;
  }
}

// Export the main classes and utility functions
export { FileContentLoader, FileContentCache };