import { indexProjectFiles, FileMetadata, queryFiles } from "./fileIndexer";
import { loadFileContent, loadFileContentAsync, FileContent } from "./fileContentLoader";

interface FileSnapshot {
  file: string;
  content: string;
  lastModified?: Date;
  size?: number;
  type?: string;
}

interface ProjectMetadata {
  totalFiles: number;
  totalSize: number;
  lastIndexed: Date;
  fileTypes: Record<string, number>;
}

interface MemoryCache {
  content: Map<string, { data: string; timestamp: number; size: number }>;
  metadata: Map<string, { data: any; timestamp: number }>;
  maxSize: number;
  currentSize: number;
  ttl: number; // Time to live in milliseconds
}

export class MemoryManager {
  private static cache: MemoryCache = {
    content: new Map(),
    metadata: new Map(),
    maxSize: 50 * 1024 * 1024, // 50MB cache limit
    currentSize: 0,
    ttl: 5 * 60 * 1000, // 5 minutes TTL
  };

  private static readonly SUPPORTED_EXTENSIONS = new Set([
    '.ts', '.js', '.tsx', '.jsx', '.json', '.md', '.txt', '.yml', '.yaml',
    '.css', '.scss', '.less', '.html', '.vue', '.svelte', '.py', '.java',
    '.cpp', '.c', '.h', '.hpp', '.rs', '.go', '.php', '.rb', '.sh'
  ]);

  /**
   * Get list of all project files with optional filtering
   */
  static getFileList(options?: {
    extensions?: string[];
    excludePatterns?: RegExp[];
    includeHidden?: boolean;
  }): string[] {
    try {
      const files = indexProjectFiles();
      const filePaths = files.map(file => file.relativePath);
      
      if (!options) return filePaths;

      return filePaths.filter(file => {
        // Filter by extensions
        if (options.extensions?.length) {
          const ext = this.getFileExtension(file);
          if (!options.extensions.includes(ext)) return false;
        }

        // Exclude patterns
        if (options.excludePatterns?.length) {
          if (options.excludePatterns.some(pattern => pattern.test(file))) {
            return false;
          }
        }

        // Hidden files
        if (!options.includeHidden && file.includes('/.')) {
          return false;
        }

        return true;
      });
    } catch (error) {
      console.error('Error getting file list:', error);
      return [];
    }
  }

  /**
   * Get file content with caching and error handling
   */
  static getFileContent(filePath: string, useCache: boolean = true): string {
    try {
      const cacheKey = filePath;
      const now = Date.now();

      // Check cache first
      if (useCache && this.cache.content.has(cacheKey)) {
        const cached = this.cache.content.get(cacheKey)!;
        if (now - cached.timestamp < this.cache.ttl) {
          return cached.data;
        } else {
          // Remove expired cache entry
          this.removeCacheEntry(cacheKey);
        }
      }

      const content = loadFileContent(filePath);
      
      // Cache the content if using cache
      if (useCache) {
        this.setCacheEntry(cacheKey, content);
      }

      return content;
    } catch (error) {
      console.error(`Error loading file content for ${filePath}:`, error);
      return '';
    }
  }

  /**
   * Get enhanced project snapshot with metadata
   */
  static getProjectSnapshot(options?: {
    includeMetadata?: boolean;
    excludePatterns?: RegExp[];
    maxFileSize?: number;
  }): FileSnapshot[] {
    try {
      const files = this.getFileList({
        excludePatterns: options?.excludePatterns,
      });

      const snapshots: FileSnapshot[] = [];

      for (const file of files) {
        try {
          const content = this.getFileContent(file);
          
          // Skip large files if maxFileSize is specified
          if (options?.maxFileSize && content.length > options.maxFileSize) {
            continue;
          }

          const snapshot: FileSnapshot = {
            file,
            content,
          };

          if (options?.includeMetadata) {
            snapshot.size = content.length;
            snapshot.type = this.getFileType(file);
            // Note: lastModified would need file system access
          }

          snapshots.push(snapshot);
        } catch (error) {
          console.warn(`Skipping file ${file} due to error:`, error);
        }
      }

      return snapshots;
    } catch (error) {
      console.error('Error creating project snapshot:', error);
      return [];
    }
  }

  /**
   * Get project metadata and statistics
   */
  static getProjectMetadata(): ProjectMetadata {
    try {
      const cacheKey = 'project_metadata';
      const cached = this.cache.metadata.get(cacheKey);
      const now = Date.now();

      if (cached && now - cached.timestamp < this.cache.ttl) {
        return cached.data;
      }

      const files = this.getFileList();
      const fileTypes: Record<string, number> = {};
      let totalSize = 0;

      for (const file of files) {
        const type = this.getFileType(file);
        fileTypes[type] = (fileTypes[type] || 0) + 1;
        
        try {
          const content = this.getFileContent(file);
          totalSize += content.length;
        } catch {
          // Skip files that can't be read
        }
      }

      const metadata: ProjectMetadata = {
        totalFiles: files.length,
        totalSize,
        lastIndexed: new Date(),
        fileTypes,
      };

      this.cache.metadata.set(cacheKey, {
        data: metadata,
        timestamp: now,
      });

      return metadata;
    } catch (error) {
      console.error('Error getting project metadata:', error);
      return {
        totalFiles: 0,
        totalSize: 0,
        lastIndexed: new Date(),
        fileTypes: {},
      };
    }
  }

  /**
   * Search for files containing specific content
   */
  static searchFiles(query: string, options?: {
    caseSensitive?: boolean;
    wholeWord?: boolean;
    fileTypes?: string[];
    maxResults?: number;
  }): Array<{ file: string; matches: number; lines: Array<{ number: number; content: string }> }> {
    try {
      const files = this.getFileList({
        extensions: options?.fileTypes,
      });

      const results: Array<{ file: string; matches: number; lines: Array<{ number: number; content: string }> }> = [];
      const maxResults = options?.maxResults || 100;

      for (const file of files) {
        if (results.length >= maxResults) break;

        try {
          const content = this.getFileContent(file);
          const lines = content.split('\n');
          const matchingLines: Array<{ number: number; content: string }> = [];
          
          let searchQuery = query;
          if (!options?.caseSensitive) {
            searchQuery = searchQuery.toLowerCase();
          }

          if (options?.wholeWord) {
            searchQuery = `\\b${searchQuery}\\b`;
          }

          const regex = new RegExp(searchQuery, options?.caseSensitive ? 'g' : 'gi');

          lines.forEach((line, index) => {
            if (regex.test(line)) {
              matchingLines.push({
                number: index + 1,
                content: line.trim(),
              });
            }
          });

          if (matchingLines.length > 0) {
            results.push({
              file,
              matches: matchingLines.length,
              lines: matchingLines,
            });
          }
        } catch (error) {
          console.warn(`Error searching in file ${file}:`, error);
        }
      }

      return results;
    } catch (error) {
      console.error('Error searching files:', error);
      return [];
    }
  }

  /**
   * Get files by type/extension
   */
  static getFilesByType(type: string): string[] {
    return this.getFileList({ extensions: [type] });
  }

  /**
   * Advanced file querying using FileIndexer
   */
  static queryProjectFiles(): ReturnType<typeof queryFiles> {
    const files = indexProjectFiles();
    return queryFiles(files);
  }

  /**
   * Get file metadata without loading content
   */
  static getFileMetadata(filePath: string): FileMetadata | null {
    try {
      const files = indexProjectFiles();
      return files.find(file => file.relativePath === filePath) || null;
    } catch (error) {
      console.error(`Error getting metadata for ${filePath}:`, error);
      return null;
    }
  }

  /**
   * Async file content loading with advanced options
   */
  static async getFileContentAsync(filePath: string, options?: {
    useCache?: boolean;
    maxSize?: number;
    timeout?: number;
  }): Promise<string> {
    try {
      const cacheKey = filePath;
      const now = Date.now();

      // Check cache first
      if (options?.useCache !== false && this.cache.content.has(cacheKey)) {
        const cached = this.cache.content.get(cacheKey)!;
        if (now - cached.timestamp < this.cache.ttl) {
          return cached.data;
        } else {
          this.removeCacheEntry(cacheKey);
        }
      }

      const content = await loadFileContentAsync(filePath, {
        maxSize: options?.maxSize,
        timeout: options?.timeout,
        useCache: options?.useCache !== false,
      });

      // Cache the content if using cache
      if (options?.useCache !== false) {
        this.setCacheEntry(cacheKey, content);
      }

      return content;
    } catch (error) {
      console.error(`Error loading file content async for ${filePath}:`, error);
      return '';
    }
  }

  /**
   * Clear memory cache
   */
  static clearCache(): void {
    this.cache.content.clear();
    this.cache.metadata.clear();
    this.cache.currentSize = 0;
  }

  /**
   * Get cache statistics
   */
  static getCacheStats(): {
    entries: number;
    size: number;
    maxSize: number;
    hitRate?: number;
  } {
    return {
      entries: this.cache.content.size + this.cache.metadata.size,
      size: this.cache.currentSize,
      maxSize: this.cache.maxSize,
    };
  }

  /**
   * Set cache configuration
   */
  static setCacheConfig(config: Partial<Pick<MemoryCache, 'maxSize' | 'ttl'>>): void {
    if (config.maxSize !== undefined) {
      this.cache.maxSize = config.maxSize;
    }
    if (config.ttl !== undefined) {
      this.cache.ttl = config.ttl;
    }
  }

  /**
   * Get project statistics and insights
   */
  static getProjectInsights(): {
    metadata: ProjectMetadata;
    topFileTypes: Array<{ type: string; count: number; percentage: number }>;
    largestFiles: Array<{ file: string; size: number }>;
    recentFiles: Array<{ file: string; lastModified: Date }>;
  } {
    try {
      const metadata = this.getProjectMetadata();
      const files = indexProjectFiles();

      // Top file types
      const topFileTypes = Object.entries(metadata.fileTypes)
        .map(([type, count]) => ({
          type,
          count,
          percentage: (count / metadata.totalFiles) * 100
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Largest files
      const largestFiles = files
        .sort((a, b) => b.size - a.size)
        .slice(0, 10)
        .map(file => ({
          file: file.relativePath,
          size: file.size
        }));

      // Recent files
      const recentFiles = files
        .sort((a, b) => b.modified.getTime() - a.modified.getTime())
        .slice(0, 10)
        .map(file => ({
          file: file.relativePath,
          lastModified: file.modified
        }));

      return {
        metadata,
        topFileTypes,
        largestFiles,
        recentFiles
      };
    } catch (error) {
      console.error('Error getting project insights:', error);
      return {
        metadata: this.getProjectMetadata(),
        topFileTypes: [],
        largestFiles: [],
        recentFiles: []
      };
    }
  }

  // Private helper methods
  private static getFileExtension(filePath: string): string {
    const match = filePath.match(/\.([^.]+)$/);
    return match ? `.${match[1].toLowerCase()}` : '';
  }

  private static getFileType(filePath: string): string {
    const ext = this.getFileExtension(filePath);
    return ext || 'unknown';
  }

  private static setCacheEntry(key: string, content: string): void {
    const size = content.length * 2; // Rough estimate for string size in bytes
    
    // Check if adding this entry would exceed cache size
    if (this.cache.currentSize + size > this.cache.maxSize) {
      this.evictOldestEntries(size);
    }

    this.cache.content.set(key, {
      data: content,
      timestamp: Date.now(),
      size,
    });

    this.cache.currentSize += size;
  }

  private static removeCacheEntry(key: string): void {
    const entry = this.cache.content.get(key);
    if (entry) {
      this.cache.content.delete(key);
      this.cache.currentSize -= entry.size;
    }
  }

  private static evictOldestEntries(sizeNeeded: number): void {
    const entries = Array.from(this.cache.content.entries())
      .sort(([, a], [, b]) => a.timestamp - b.timestamp);

    let freedSize = 0;
    for (const [key] of entries) {
      if (freedSize >= sizeNeeded) break;
      const entry = this.cache.content.get(key);
      if (entry) {
        freedSize += entry.size;
        this.removeCacheEntry(key);
      }
    }
  }
}

// Export convenience functions for backward compatibility
export function getProjectFiles(): string[] {
  return MemoryManager.getFileList();
}

export function getFileContent(filePath: string): string {
  return MemoryManager.getFileContent(filePath);
}

export function searchInFiles(query: string, options?: Parameters<typeof MemoryManager.searchFiles>[1]) {
  return MemoryManager.searchFiles(query, options);
}

export function getProjectSnapshot(options?: Parameters<typeof MemoryManager.getProjectSnapshot>[0]) {
  return MemoryManager.getProjectSnapshot(options);
}

export function clearMemoryCache(): void {
  MemoryManager.clearCache();
}

// Export types for external use
export type { FileSnapshot, ProjectMetadata, MemoryCache };