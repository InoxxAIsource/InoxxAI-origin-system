import fs from "fs";
import path from "path";
import crypto from "crypto";

const PROJECT_ROOT = path.resolve(__dirname, "../../..");

// Enhanced configuration for file indexing
const CONFIG = {
  // Core code file extensions
  ALLOWED_EXTENSIONS: [
    ".ts", ".tsx", ".js", ".jsx", 
    ".json", ".sol", ".rs", ".py", 
    ".go", ".java", ".cpp", ".c", 
    ".h", ".hpp", ".cs", ".php",
    ".rb", ".swift", ".kt", ".scala",
    ".vue", ".svelte", ".astro"
  ],
  
  // Configuration and documentation files
  CONFIG_EXTENSIONS: [
    ".yml", ".yaml", ".toml", ".ini", 
    ".env", ".md", ".txt", ".lock"
  ],
  
  // Directories to always skip
  SKIP_DIRS: [
    "node_modules", ".git", "dist", "build", 
    "out", ".next", ".nuxt", "coverage", 
    ".nyc_output", "target", "bin", "obj",
    ".vscode", ".idea", "tmp", "temp"
  ],
  
  // File patterns to skip (regex)
  SKIP_PATTERNS: [
    /\.min\.(js|css)$/,
    /\.map$/,
    /\.d\.ts$/,
    /\.test\.(js|ts|jsx|tsx)$/,
    /\.spec\.(js|ts|jsx|tsx)$/,
    /^\.env\./,
    /\.log$/
  ],
  
  // Maximum file size in bytes (1MB default)
  MAX_FILE_SIZE: 1024 * 1024,
  
  // Maximum directory depth
  MAX_DEPTH: 20
};

export interface FileMetadata {
  relativePath: string;
  absolutePath: string;
  size: number;
  modified: Date;
  extension: string;
  hash: string;
  type: 'code' | 'config' | 'doc';
  language?: string;
}

export interface IndexingOptions {
  includeConfig?: boolean;
  includeDocs?: boolean;
  maxFileSize?: number;
  maxDepth?: number;
  customExtensions?: string[];
  additionalSkipDirs?: string[];
  generateHashes?: boolean;
  filterCallback?: (file: FileMetadata) => boolean;
}

export interface IndexingStats {
  totalFiles: number;
  totalSize: number;
  filesByType: Record<string, number>;
  filesByLanguage: Record<string, number>;
  skippedFiles: number;
  indexingTime: number;
  errors: string[];
}

class FileIndexer {
  private options: Required<IndexingOptions>;
  private stats: IndexingStats;
  
  constructor(options: IndexingOptions = {}) {
    this.options = {
      includeConfig: options.includeConfig ?? false,
      includeDocs: options.includeDocs ?? false,
      maxFileSize: options.maxFileSize ?? CONFIG.MAX_FILE_SIZE,
      maxDepth: options.maxDepth ?? CONFIG.MAX_DEPTH,
      customExtensions: options.customExtensions ?? [],
      additionalSkipDirs: options.additionalSkipDirs ?? [],
      generateHashes: options.generateHashes ?? false,
      filterCallback: options.filterCallback ?? (() => true)
    };
    
    this.stats = this.initializeStats();
  }
  
  private initializeStats(): IndexingStats {
    return {
      totalFiles: 0,
      totalSize: 0,
      filesByType: {},
      filesByLanguage: {},
      skippedFiles: 0,
      indexingTime: 0,
      errors: []
    };
  }
  
  private getAllowedExtensions(): string[] {
    const extensions = [...CONFIG.ALLOWED_EXTENSIONS, ...this.options.customExtensions];
    
    if (this.options.includeConfig) {
      extensions.push(...CONFIG.CONFIG_EXTENSIONS);
    }
    
    if (this.options.includeDocs) {
      extensions.push(".md", ".txt", ".rst", ".adoc");
    }
    
    return Array.from(new Set(extensions));
  }
  
  private getSkipDirs(): string[] {
    return [...CONFIG.SKIP_DIRS, ...this.options.additionalSkipDirs];
  }
  
  private shouldSkipFile(filePath: string, stats: fs.Stats): boolean {
    const fileName = path.basename(filePath);
    
    // Check file patterns
    if (CONFIG.SKIP_PATTERNS.some(pattern => pattern.test(fileName))) {
      return true;
    }
    
    // Check file size
    if (stats.size > this.options.maxFileSize) {
      return true;
    }
    
    return false;
  }
  
  private detectLanguage(extension: string, fileName: string): string {
    const languageMap: Record<string, string> = {
      '.ts': 'typescript',
      '.tsx': 'typescript',
      '.js': 'javascript',
      '.jsx': 'javascript',
      '.py': 'python',
      '.go': 'go',
      '.rs': 'rust',
      '.java': 'java',
      '.cpp': 'cpp',
      '.c': 'c',
      '.cs': 'csharp',
      '.php': 'php',
      '.rb': 'ruby',
      '.swift': 'swift',
      '.kt': 'kotlin',
      '.scala': 'scala',
      '.sol': 'solidity',
      '.vue': 'vue',
      '.svelte': 'svelte',
      '.astro': 'astro'
    };
    
    return languageMap[extension] || extension.slice(1);
  }
  
  private getFileType(extension: string): 'code' | 'config' | 'doc' {
    if (CONFIG.ALLOWED_EXTENSIONS.includes(extension)) return 'code';
    if (CONFIG.CONFIG_EXTENSIONS.includes(extension)) return 'config';
    return 'doc';
  }
  
  private generateFileHash(filePath: string): string {
    if (!this.options.generateHashes) return '';
    
    try {
      const content = fs.readFileSync(filePath);
      return crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
    } catch (error) {
      this.stats.errors.push(`Failed to hash ${filePath}: ${error}`);
      return '';
    }
  }
  
  private createFileMetadata(filePath: string, stats: fs.Stats): FileMetadata | null {
    try {
      const relativePath = path.relative(PROJECT_ROOT, filePath);
      const extension = path.extname(filePath);
      const fileName = path.basename(filePath);
      
      const metadata: FileMetadata = {
        relativePath,
        absolutePath: filePath,
        size: stats.size,
        modified: stats.mtime,
        extension,
        hash: this.generateFileHash(filePath),
        type: this.getFileType(extension),
        language: this.detectLanguage(extension, fileName)
      };
      
      // Apply custom filter if provided
      if (!this.options.filterCallback(metadata)) {
        this.stats.skippedFiles++;
        return null;
      }
      
      // Update statistics
      this.stats.totalFiles++;
      this.stats.totalSize += stats.size;
      this.stats.filesByType[metadata.type] = (this.stats.filesByType[metadata.type] || 0) + 1;
      if (metadata.language) {
        this.stats.filesByLanguage[metadata.language] = (this.stats.filesByLanguage[metadata.language] || 0) + 1;
      }
      
      return metadata;
    } catch (error) {
      this.stats.errors.push(`Failed to process ${filePath}: ${error}`);
      return null;
    }
  }
  
  private walk(dir: string, depth: number = 0): FileMetadata[] {
    if (depth > this.options.maxDepth) return [];
    
    const files: FileMetadata[] = [];
    const allowedExtensions = this.getAllowedExtensions();
    const skipDirs = this.getSkipDirs();
    
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        
        if (entry.isDirectory()) {
          if (skipDirs.includes(entry.name) || entry.name.startsWith('.')) {
            continue;
          }
          files.push(...this.walk(fullPath, depth + 1));
        } else {
          const extension = path.extname(entry.name);
          
          if (!allowedExtensions.includes(extension)) {
            continue;
          }
          
          try {
            const stats = fs.statSync(fullPath);
            
            if (this.shouldSkipFile(fullPath, stats)) {
              this.stats.skippedFiles++;
              continue;
            }
            
            const metadata = this.createFileMetadata(fullPath, stats);
            if (metadata) {
              files.push(metadata);
            }
          } catch (error) {
            this.stats.errors.push(`Failed to stat ${fullPath}: ${error}`);
          }
        }
      }
    } catch (error) {
      this.stats.errors.push(`Failed to read directory ${dir}: ${error}`);
    }
    
    return files;
  }
  
  public indexFiles(): FileMetadata[] {
    const startTime = Date.now();
    this.stats = this.initializeStats();
    
    const files = this.walk(PROJECT_ROOT);
    
    this.stats.indexingTime = Date.now() - startTime;
    return files;
  }
  
  public getStats(): IndexingStats {
    return { ...this.stats };
  }
}

// Convenience functions for backward compatibility and simple usage
export function indexProjectFiles(options?: IndexingOptions): FileMetadata[] {
  const indexer = new FileIndexer(options);
  return indexer.indexFiles();
}

export function indexProjectFilePaths(options?: IndexingOptions): string[] {
  const files = indexProjectFiles(options);
  return files.map(file => file.relativePath);
}

export function getProjectStats(options?: IndexingOptions): IndexingStats {
  const indexer = new FileIndexer(options);
  indexer.indexFiles();
  return indexer.getStats();
}

// Advanced filtering and querying utilities
export class FileQuery {
  private files: FileMetadata[];
  
  constructor(files: FileMetadata[]) {
    this.files = files;
  }
  
  byExtension(extensions: string[]): FileQuery {
    return new FileQuery(
      this.files.filter(file => extensions.includes(file.extension))
    );
  }
  
  byLanguage(languages: string[]): FileQuery {
    return new FileQuery(
      this.files.filter(file => file.language && languages.includes(file.language))
    );
  }
  
  byType(types: ('code' | 'config' | 'doc')[]): FileQuery {
    return new FileQuery(
      this.files.filter(file => types.includes(file.type))
    );
  }
  
  byPath(pattern: RegExp): FileQuery {
    return new FileQuery(
      this.files.filter(file => pattern.test(file.relativePath))
    );
  }
  
  modifiedAfter(date: Date): FileQuery {
    return new FileQuery(
      this.files.filter(file => file.modified > date)
    );
  }
  
  largerThan(bytes: number): FileQuery {
    return new FileQuery(
      this.files.filter(file => file.size > bytes)
    );
  }
  
  sortBy(field: keyof FileMetadata, ascending: boolean = true): FileQuery {
    const sorted = [...this.files].sort((a, b) => {
      const aVal = a[field];
      const bVal = b[field];
      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return ascending ? 1 : -1;
      if (bVal == null) return ascending ? -1 : 1;
      if (aVal < bVal) return ascending ? -1 : 1;
      if (aVal > bVal) return ascending ? 1 : -1;
      return 0;
    });
    return new FileQuery(sorted);
  }
  
  limit(count: number): FileQuery {
    return new FileQuery(this.files.slice(0, count));
  }
  
  toArray(): FileMetadata[] {
    return [...this.files];
  }
  
  toPaths(): string[] {
    return this.files.map(file => file.relativePath);
  }
}

export function queryFiles(files: FileMetadata[]): FileQuery {
  return new FileQuery(files);
}

// Export the main class for advanced usage
export { FileIndexer };