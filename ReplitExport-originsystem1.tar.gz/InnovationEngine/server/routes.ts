import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { insertProjectSchema, insertFileSchema, insertAiGenerationSchema } from "@shared/schema";
import { aiService } from "./lib/ai-service";
import { packageManager } from "./lib/package-manager";
import { fileSystem } from "./lib/file-system";
import { previewServer } from "./lib/preview-server";
import { coreAgent } from "./lib/core-agent";
import { backendPreviewManager } from "./lib/backend-preview-manager";
import { errorHandler } from "./lib/error-handler";
import { multiAgentSystem } from "./lib/multi-agent-system";
import { runMultiAgentTask } from "./agents";
import { generateCode } from "./agents/simpleCodeAgent";
import { promises as fs } from 'fs';
import path from 'path';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Projects API
  app.get("/api/projects", async (req, res) => {
    try {
      const userId = req.query.userId as string || "user1";
      const projects = await storage.getProjectsByUser(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      // Add default userId if not provided
      const projectData = {
        ...req.body,
        userId: req.body.userId || "user1"
      };
      
      const validation = insertProjectSchema.safeParse(projectData);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid project data", details: validation.error });
      }

      const project = await storage.createProject(validation.data);
      res.status(201).json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const project = await storage.updateProject(id, updates);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  // Files API
  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const files = await storage.getFilesByProject(projectId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch files" });
    }
  });

  app.get("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch file" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const validation = insertFileSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid file data", details: validation.error });
      }

      const file = await storage.createFile(validation.data);
      
      // Emit real-time update
      io.emit("fileCreated", file);
      
      res.status(201).json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to create file" });
    }
  });

  app.put("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const file = await storage.updateFile(id, updates);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      // Emit real-time update
      io.emit("fileUpdated", file);
      
      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to update file" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFile(id);
      if (!success) {
        return res.status(404).json({ error: "File not found" });
      }

      // Emit real-time update
      io.emit("fileDeleted", { id });
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  // Enhanced Self-Healing Multi-Agent Loop with Service Layer
  app.use("/api/v1/self-healing", (await import('./routes/selfHealing.route')).default);

  // Self-Healing Multi-Agent Loop API
  app.post("/api/ai/self-healing-loop", async (req, res) => {
    try {
      const { prompt, config } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log(`Starting Self-Healing Loop for: ${prompt}`);
      
      const { SelfHealingLoop } = await import('./agents/selfHealingLoop');
      const loop = new SelfHealingLoop(config);
      
      // Execute the multi-agent loop
      const result = await loop.execute(prompt);
      
      if (result.success) {
        // Create project with all generated files
        const project = await storage.createProject({
          name: `Multi-Agent: ${prompt.substring(0, 50)}...`,
          description: `Generated using Self-Healing Multi-Agent Loop`,
          userId: "multi-agent-loop",
        });

        // Store all generated files
        const filePromises = Array.from(result.generatedFiles.entries()).map(([filename, content]) => 
          storage.createFile({
            projectId: project.id,
            path: filename,
            content: content
          })
        );
        
        await Promise.all(filePromises);

        // Save generation record
        await storage.createAiGeneration({
          projectId: project.id,
          prompt,
          generatedCode: Array.from(result.generatedFiles.values()).join('\n\n'),
          framework: 'multi-agent',
          styling: 'comprehensive',
        });

        res.json({
          project,
          result,
          metrics: result.metrics,
          filesGenerated: result.generatedFiles.size
        });
      } else {
        res.status(500).json({
          error: "Self-healing loop failed to complete successfully",
          metrics: result.metrics,
          partialFiles: result.generatedFiles.size
        });
      }
    } catch (error) {
      console.error('Self-healing loop error:', error);
      res.status(500).json({ error: "Failed to execute self-healing loop" });
    }
  });

  // Real AI Code Generation API using OpenAI
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, projectType = "react" } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log(`Generating ${projectType} project for prompt: ${prompt}`);
      
      // Check if there's existing code in the sandbox to provide context
      let existingCode = '';
      const isModificationRequest = prompt.toLowerCase().includes('add') && 
                                   (prompt.toLowerCase().includes('to this') || 
                                    prompt.toLowerCase().includes('to the page') ||
                                    prompt.toLowerCase().includes('to current'));
      
      if (isModificationRequest) {
        try {
          const sandboxAppPath = path.join(process.cwd(), 'sandbox', 'src', 'App.tsx');
          existingCode = await fs.readFile(sandboxAppPath, 'utf8');
          console.log('Found existing code for context, length:', existingCode.length);
        } catch (error) {
          console.log('No existing code found for modification request');
        }
      }
      
      // Use real OpenAI API with enhanced context handling
      const result = await generateCode(prompt, projectType, existingCode);
      
      // Create a new project with the generated code
      const project = await storage.createProject({
        name: `AI Generated: ${prompt.substring(0, 50)}...`,
        description: result.description,
        userId: "ai-generated",
      });

      // Create the main file with generated code
      await storage.createFile({
        projectId: project.id,
        path: result.type === 'react' ? 'src/App.tsx' : 'index.html',
        content: result.code
      });

      // Save AI generation record
      await storage.createAiGeneration({
        projectId: project.id,
        prompt,
        generatedCode: result.code,
        framework: result.type,
        styling: 'tailwind',
      });

      // Emit real-time update to sandbox
      io.emit("projectGenerated", {
        id: project.id.toString(),
        content: result.code,
        type: result.type,
        timestamp: Date.now()
      });

      res.json({
        project,
        generatedCode: result.code,
        type: result.type,
        dependencies: result.dependencies,
        description: result.description
      });
    } catch (error) {
      console.error("AI generation error:", error);
      res.status(500).json({ error: "Failed to generate code" });
    }
  });

  // Write generated code to sandbox filesystem for proper Vite compilation
  app.post("/api/sandbox/write", async (req, res) => {
    try {
      const { code, filename = "App.tsx" } = req.body;
      
      if (!code) {
        return res.status(400).json({ error: "Code is required" });
      }

      // Write to sandbox/src directory for Vite compilation
      const sandboxPath = path.join(process.cwd(), 'sandbox', 'src', filename);
      await fs.writeFile(sandboxPath, code, 'utf8');
      
      // Notify preview iframe to reload
      io.emit("sandboxUpdated", { filename, timestamp: Date.now() });
      
      res.json({ success: true, path: sandboxPath });
    } catch (error) {
      console.error("Sandbox write error:", error);
      res.status(500).json({ error: "Failed to write code to sandbox" });
    }
  });

  // Multi-Agent Collaborative Generation
  app.post("/api/ai/multi-agent", async (req, res) => {
    try {
      const { prompt, projectId } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log('Starting multi-agent collaboration for:', prompt);
      const result = await multiAgentSystem.processProject(prompt);
      
      // Save generation history
      if (projectId) {
        await storage.createAiGeneration({
          projectId: parseInt(projectId),
          prompt,
          generatedCode: result.code,
          framework: "react",
          styling: "tailwind",
        });
      }

      res.json({
        code: result.code,
        architecture: result.architecture,
        quality: result.quality,
        iterations: result.iterations,
        framework: "react",
        styling: "tailwind"
      });
    } catch (error) {
      console.error("Multi-agent generation error:", error);
      res.status(500).json({ error: "Failed to generate code with multi-agent system" });
    }
  });

  // Full-Stack Multi-Agent Generation
  app.post("/api/ai/fullstack", async (req, res) => {
    try {
      const { prompt, projectId } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log('Starting full-stack multi-agent generation for:', prompt);
      const result = await multiAgentSystem.generateFullStack(prompt);
      
      // Save generation history
      if (projectId) {
        await storage.createAiGeneration({
          projectId: parseInt(projectId),
          prompt,
          generatedCode: result.frontend.code,
          framework: "react",
          styling: "tailwind",
        });
      }

      res.json({
        frontend: result.frontend,
        backend: result.backend,
        quality: result.quality,
        isFullStack: true
      });
    } catch (error) {
      console.error("Full-stack generation error:", error);
      res.status(500).json({ error: "Failed to generate full-stack project" });
    }
  });

  // Specialized Multi-Agent Generation API
  app.post("/api/ai/specialized-agents", async (req, res) => {
    try {
      const { prompt, projectId } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log('Starting specialized multi-agent task for:', prompt);
      const result = await runMultiAgentTask(prompt);
      
      // Save generation history
      if (projectId) {
        await storage.createAiGeneration({
          projectId: parseInt(projectId),
          prompt,
          generatedCode: result.code?.code || '',
          framework: "react",
          styling: "tailwind",
        });
      }

      res.json({
        plan: result.plan,
        code: result.code,
        dependencies: result.dependencies,
        preview: result.preview,
        schema: result.schema,
        framework: "react",
        styling: "tailwind"
      });
    } catch (error) {
      console.error("Specialized multi-agent generation error:", error);
      res.status(500).json({ error: "Failed to generate code with specialized agents" });
    }
  });

  // Enhanced Project Generation API
  app.post("/api/ai/generate-project", async (req, res) => {
    try {
      const { prompt, projectName } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      // Generate full project using CoreAgent
      const generationResult = await coreAgent.generate(prompt);
      
      // Create project
      const project = await storage.createProject({
        name: projectName || `AI Generated Project`,
        userId: 'default-user',
        description: `Generated from prompt: ${prompt}`,
        dependencies: generationResult.dependencies.reduce((acc, dep) => {
          acc[dep] = 'latest';
          return acc;
        }, {} as Record<string, string>)
      });

      // Create all generated files
      const createdFiles = [];
      for (const file of generationResult.files) {
        const createdFile = await storage.createFile({
          projectId: project.id,
          path: file.path,
          content: file.content,
          language: file.path.endsWith('.js') || file.path.endsWith('.jsx') ? 'javascript' : 
                   file.path.endsWith('.ts') || file.path.endsWith('.tsx') ? 'typescript' :
                   file.path.endsWith('.css') ? 'css' :
                   file.path.endsWith('.json') ? 'json' : 'text',
          isOpen: file.path.includes('App.')
        });
        createdFiles.push(createdFile);
      }

      // Generate backend routes if applicable
      const projectType = prompt.toLowerCase().includes('dashboard') ? 'dashboard' :
                         prompt.toLowerCase().includes('api') ? 'api' :
                         prompt.toLowerCase().includes('form') ? 'form' : 'general';
      
      const backendRoutes = await backendPreviewManager.generateSampleRoutes(projectType);

      res.json({
        project,
        files: createdFiles,
        dependencies: generationResult.dependencies,
        backendRoutes,
        previewUrl: backendPreviewManager.getPreviewUrl()
      });
    } catch (error) {
      console.error("Project generation error:", error);
      res.status(500).json({ error: "Failed to generate project" });
    }
  });

  // Project Validation and Error Handling API
  app.post("/api/ai/validate-project", async (req, res) => {
    try {
      const { files, dependencies, framework = "react" } = req.body;
      
      if (!files || !Array.isArray(files)) {
        return res.status(400).json({ error: "Files array is required" });
      }

      const context = {
        dependencies: dependencies || [],
        files,
        framework,
        projectType: 'validation'
      };

      const validationResult = await errorHandler.validateAndFix(files, context);
      
      res.json({
        isValid: validationResult.fixes.length === 0,
        fixes: validationResult.fixes,
        updatedFiles: validationResult.files,
        updatedDependencies: validationResult.dependencies,
        message: validationResult.fixes.length === 0 
          ? "Project validation successful" 
          : `Found and fixed ${validationResult.fixes.length} issues`
      });
    } catch (error) {
      console.error("Project validation error:", error);
      res.status(500).json({ error: "Failed to validate project" });
    }
  });

  // Error Handling API
  app.post("/api/ai/handle-error", async (req, res) => {
    try {
      const { error, context } = req.body;
      
      if (!error || !error.message) {
        return res.status(400).json({ error: "Error message is required" });
      }

      const errorObj = new Error(error.message);
      const result = await errorHandler.handle(errorObj, context);
      
      res.json(result);
    } catch (error) {
      console.error("Error handling failed:", error);
      res.status(500).json({ error: "Failed to handle error" });
    }
  });

  // Package Management API
  app.post("/api/packages/install", async (req, res) => {
    try {
      const { packageName, projectId } = req.body;
      
      if (!packageName || !projectId) {
        return res.status(400).json({ error: "Package name and project ID are required" });
      }

      const result = await packageManager.installPackage(packageName, parseInt(projectId));
      
      // Update project dependencies
      const project = await storage.getProject(parseInt(projectId));
      if (project) {
        const updatedDependencies = { ...project.dependencies, [packageName]: result.version };
        await storage.updateProject(parseInt(projectId), { dependencies: updatedDependencies });
      }

      // Emit real-time update
      io.emit("packageInstalled", { projectId, packageName, version: result.version });
      
      res.json(result);
    } catch (error) {
      console.error("Package installation error:", error);
      res.status(500).json({ error: "Failed to install package" });
    }
  });

  app.get("/api/packages/search", async (req, res) => {
    try {
      const { query } = req.query;
      if (!query || typeof query !== "string") {
        return res.status(400).json({ error: "Search query is required" });
      }

      const results = await packageManager.searchPackages(query);
      res.json(results);
    } catch (error) {
      console.error("Package search error:", error);
      res.status(500).json({ error: "Failed to search packages" });
    }
  });

  // File System Operations API
  app.post("/api/filesystem/create-folder", async (req, res) => {
    try {
      const { path, projectId } = req.body;
      
      if (!path || !projectId) {
        return res.status(400).json({ error: "Path and project ID are required" });
      }

      const result = await fileSystem.createFolder(path, parseInt(projectId));
      
      // Emit real-time update
      io.emit("folderCreated", { projectId, path });
      
      res.json(result);
    } catch (error) {
      console.error("Folder creation error:", error);
      res.status(500).json({ error: "Failed to create folder" });
    }
  });

  // Preview Server API
  app.get("/api/preview/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const previewUrl = await previewServer.getPreviewUrl(projectId);
      res.json({ url: previewUrl });
    } catch (error) {
      console.error("Preview error:", error);
      res.status(500).json({ error: "Failed to get preview URL" });
    }
  });

  // Serve live preview content
  app.get("/preview/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const content = await previewServer.getPreviewContent(projectId);
      res.setHeader('Content-Type', 'text/html');
      res.send(content);
    } catch (error) {
      console.error("Preview content error:", error);
      res.status(500).send("Preview error");
    }
  });

  // Sandbox API endpoints
  app.get("/api/sandbox/project/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      // Get the latest AI generation for this project
      const generations = await storage.getAiGenerationsByProject(projectId);
      const latestGeneration = generations[generations.length - 1];

      if (!latestGeneration) {
        return res.json({
          id: projectId.toString(),
          content: getDefaultSandboxContent(),
          type: "html",
          timestamp: Date.now()
        });
      }

      res.json({
        id: projectId.toString(),
        content: latestGeneration.generatedCode || getDefaultSandboxContent(),
        type: detectContentType(latestGeneration.generatedCode),
        timestamp: latestGeneration.createdAt ? new Date(latestGeneration.createdAt).getTime() : Date.now()
      });
    } catch (error) {
      console.error("Sandbox project error:", error);
      res.status(500).json({ error: "Failed to get project data" });
    }
  });

  app.post("/api/preview/:projectId/refresh", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      await previewServer.refreshPreview(projectId);
      
      // Emit real-time update
      io.emit("previewRefreshed", { projectId });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Preview refresh error:", error);
      res.status(500).json({ error: "Failed to refresh preview" });
    }
  });

  // Real-time AI Generation API with OpenAI
  app.post("/api/generate-live", async (req, res) => {
    try {
      const { prompt, projectType = "react" } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      // Generate real code using OpenAI
      const result = await generateCode(prompt, projectType);
      
      // Emit real-time update to connected clients
      io.emit("projectGenerated", {
        id: Date.now().toString(),
        content: result.code,
        type: result.type,
        timestamp: Date.now()
      });

      res.json({
        success: true,
        generatedCode: result.code,
        type: result.type,
        dependencies: result.dependencies
      });
    } catch (error) {
      console.error("Live generation error:", error);
      res.status(500).json({ error: "Failed to generate code" });
    }
  });

  // Sandbox communication endpoints
  app.get("/api/sandbox/project/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      
      // Get the latest AI generation for this project
      const generations = await storage.getAiGenerationsByProject(projectId);
      const latestGeneration = generations[generations.length - 1];

      if (!latestGeneration) {
        return res.json({
          id: projectId.toString(),
          content: getDefaultSandboxContent(),
          type: "html",
          timestamp: Date.now()
        });
      }

      res.json({
        id: projectId.toString(),
        content: latestGeneration.generatedCode,
        type: detectContentType(latestGeneration.generatedCode),
        timestamp: latestGeneration.createdAt ? new Date(latestGeneration.createdAt).getTime() : Date.now()
      });
    } catch (error) {
      console.error("Sandbox project error:", error);
      res.status(500).json({ error: "Failed to get project data" });
    }
  });

  // WebSocket connections for real-time collaboration
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("joinProject", (projectId) => {
      socket.join(`project-${projectId}`);
      socket.to(`project-${projectId}`).emit("userJoined", { socketId: socket.id });
    });

    socket.on("requestProject", async (projectId) => {
      try {
        const generations = await storage.getAiGenerationsByProject(parseInt(projectId));
        const latestGeneration = generations[generations.length - 1];
        
        if (latestGeneration) {
          socket.emit("projectGenerated", {
            id: projectId,
            content: latestGeneration.generatedCode,
            type: detectContentType(latestGeneration.generatedCode),
            timestamp: Date.now()
          });
        }
      } catch (error) {
        console.error("Request project error:", error);
        socket.emit("error", { message: "Failed to load project" });
      }
    });

    socket.on("leaveProject", (projectId) => {
      socket.leave(`project-${projectId}`);
      socket.to(`project-${projectId}`).emit("userLeft", { socketId: socket.id });
    });

    socket.on("codeChange", (data) => {
      socket.to(`project-${data.projectId}`).emit("codeChanged", data);
    });

    socket.on("cursorMove", (data) => {
      socket.to(`project-${data.projectId}`).emit("cursorMoved", data);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  return httpServer;
}

// Helper functions for sandbox
function getDefaultSandboxContent(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InnoXAI Project</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            margin: 0;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            padding: 3rem;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        h1 { font-size: 2.5rem; margin-bottom: 1rem; }
        p { font-size: 1.2rem; opacity: 0.9; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to InnoXAI</h1>
        <p>Your AI-generated project will appear here</p>
        <p>Start building with our multi-agent system</p>
    </div>
</body>
</html>`;
}

function detectContentType(content: string | null): "react" | "html" | "vue" | "svelte" {
  if (!content) return "html";
  
  const lowerContent = content.toLowerCase();
  
  if (lowerContent.includes('import react') || lowerContent.includes('from "react"')) {
    return "react";
  }
  if (lowerContent.includes('<template>') && lowerContent.includes('<script>')) {
    return "vue";
  }
  if (lowerContent.includes('<script>') && lowerContent.includes('export default')) {
    return "svelte";
  }
  
  return "html";
}
