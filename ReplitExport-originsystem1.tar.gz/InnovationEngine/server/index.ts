import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import agentRoutes from './routes/agents.route';

const app = express();

// Enhanced request logging and metrics
interface ServerMetrics {
  startTime: Date;
  requestCount: number;
  errorCount: number;
  agentRequests: number;
  uptime: number;
}

const metrics: ServerMetrics = {
  startTime: new Date(),
  requestCount: 0,
  errorCount: 0,
  agentRequests: 0,
  uptime: 0,
};

// Basic middleware setup
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: false, limit: "50mb" }));

// Enhanced request tracking
app.use((req, res, next) => {
  const start = Date.now();
  metrics.requestCount++;
  
  // Track agent requests specifically
  if (req.path.startsWith("/api/agents")) {
    metrics.agentRequests++;
  }
  
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    
    // Track errors
    if (res.statusCode >= 400) {
      metrics.errorCount++;
    }
    
    if (req.path.startsWith("/api")) {
      let logLine = `${req.method} ${req.path} ${res.statusCode} in ${duration}ms`;
      
      if (capturedJsonResponse) {
        const responseStr = JSON.stringify(capturedJsonResponse);
        const preview = responseStr.length > 100 ? responseStr.slice(0, 100) + "..." : responseStr;
        logLine += ` :: ${preview}`;
      }

      if (logLine.length > 120) {
        logLine = logLine.slice(0, 119) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Health and metrics endpoints
app.get("/health", (req, res) => {
  const uptimeMs = Date.now() - metrics.startTime.getTime();
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    uptime: Math.floor(uptimeMs / 1000),
    version: process.env.npm_package_version || "1.0.0",
    environment: process.env.NODE_ENV || "development",
    agents: {
      status: "active",
      available: [
        "planner", "codeWriter", "dependency", "errorResolver", 
        "dbSchema", "deployment", "testWriter"
      ]
    },
  });
});

app.get("/metrics", (req, res) => {
  const uptimeSeconds = Math.floor((Date.now() - metrics.startTime.getTime()) / 1000);
  const memoryUsage = process.memoryUsage();
  
  res.json({
    ...metrics,
    uptime: uptimeSeconds,
    memory: {
      heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
      heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024), // MB
      rss: Math.round(memoryUsage.rss / 1024 / 1024), // MB
    },
    process: {
      pid: process.pid,
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
    },
  });
});

// API information endpoint
app.get("/api", (req, res) => {
  res.json({
    name: "InnoXAI Multi-Agent Development Platform",
    version: process.env.npm_package_version || "1.0.0",
    description: "Advanced AI-powered development platform with specialized agents",
    agents: {
      planner: {
        role: "Project planning and architecture design",
        endpoint: "/api/agents/planner",
      },
      codeWriter: {
        role: "Production-grade code generation",
        endpoint: "/api/agents/code-writer",
      },
      dependency: {
        role: "Package management and security",
        endpoint: "/api/agents/dependency",
      },
      errorResolver: {
        role: "Autonomous debugging and error resolution",
        endpoint: "/api/agents/error-resolver",
      },
      dbSchema: {
        role: "Database architecture design",
        endpoint: "/api/agents/db-schema",
      },
      deployment: {
        role: "Multi-platform deployment orchestration",
        endpoint: "/api/agents/deployment",
      },
      testWriter: {
        role: "Comprehensive testing and security analysis",
        endpoint: "/api/agents/test-writer",
      },
    },
    features: [
      "AI-powered code generation",
      "Advanced error resolution",
      "Comprehensive testing automation",
      "Multi-platform deployment",
      "Security vulnerability scanning",
      "Performance optimization",
      "Database schema design",
    ],
  });
});

// Add agent routes
app.use("/api", agentRoutes);

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    
    // Track error in metrics
    metrics.errorCount++;

    res.status(status).json({ 
      message,
      timestamp: new Date().toISOString(),
      ...(process.env.NODE_ENV === "development" && { stack: err.stack })
    });
  });

  // Setup Vite in development or serve static files in production
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Start metrics collection
  setInterval(() => {
    metrics.uptime = Math.floor((Date.now() - metrics.startTime.getTime()) / 1000);
  }, 30000);

  // ALWAYS serve the app on port 5000
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`🚀 InnoXAI Multi-Agent Development Platform`);
    log(`🌐 Server running on http://0.0.0.0:${port}`);
    log(`🤖 Enhanced AI Agents: Active`);
    log(`📊 Metrics: /metrics`);
    log(`🏥 Health: /health`);
    log(`📖 API Info: /api`);
    log(`🛠️  Environment: ${process.env.NODE_ENV || "development"}`);
  });
})();