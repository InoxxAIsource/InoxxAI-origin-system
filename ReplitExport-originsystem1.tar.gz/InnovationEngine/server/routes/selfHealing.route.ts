import express from "express";
import { selfHealingService } from "../services/selfHealing.service";

const router = express.Router();

// Simple validation middleware
const validatePrompt = (req: any, res: any, next: any) => {
  const { prompt } = req.body;
  
  if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
    return res.status(400).json({
      error: 'Invalid prompt',
      message: 'Prompt is required and must be a non-empty string'
    });
  }
  
  if (prompt.length > 10000) {
    return res.status(400).json({
      error: 'Prompt too long',
      message: 'Prompt must be less than 10,000 characters'
    });
  }
  
  next();
};

// Rate limiting middleware
const rateLimiter = (req: any, res: any, next: any) => {
  // Simple rate limiting - in production, use redis-based solution
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 10;
  
  // For demo purposes, just log and continue
  console.log(`Rate limit check for ${req.ip} at ${new Date(now).toISOString()}`);
  next();
};

// Async handler wrapper
const asyncHandler = (fn: any) => (req: any, res: any, next: any) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

router.post(
  "/autonomous-loop",
  rateLimiter,
  validatePrompt,
  asyncHandler(async (req: any, res: any) => {
    const { prompt, userId, options } = req.body;
    
    try {
      const result = await selfHealingService.runFullSelfHealingPipeline(
        prompt,
        userId,
        options
      );

      if (result.success) {
        res.status(202).json({
          status: "success",
          data: {
            message: "Autonomous build completed successfully",
            metrics: result.metrics,
            artifacts: result.artifacts,
            retries: result.retries
          }
        });
      } else {
        res.status(200).json({
          status: "partial_success",
          data: {
            message: "Build completed with some unresolved issues",
            metrics: result.metrics,
            warnings: result.error
          }
        });
      }
    } catch (error) {
      res.status(500).json({
        status: "error",
        message: "Failed to execute autonomous loop",
        error: (error as Error).message
      });
    }
  })
);

// Job status monitoring endpoint
router.get(
  "/status/:jobId",
  asyncHandler(async (req: any, res: any) => {
    const { jobId } = req.params;
    const status = await selfHealingService.getJobStatus(jobId);
    res.json(status);
  })
);

// Audit log endpoint
router.get(
  "/audit",
  asyncHandler(async (req: any, res: any) => {
    const auditLog = selfHealingService.getAuditLog();
    res.json({
      entries: auditLog,
      total: auditLog.length
    });
  })
);

// Active jobs endpoint
router.get(
  "/jobs",
  asyncHandler(async (req: any, res: any) => {
    const activeJobs = selfHealingService.getActiveJobs();
    res.json({
      jobs: activeJobs,
      total: activeJobs.length
    });
  })
);

export default router;