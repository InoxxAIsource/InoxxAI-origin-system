import express from "express";
import { runMultiAgentTask } from "../agents";
import { runAutonomousAgents } from "../agents/orchestrator";

const router = express.Router();

router.post("/multi-agent", async (req, res) => {
  try {
    const { prompt } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    console.log('Starting specialized multi-agent task:', prompt);
    const result = await runMultiAgentTask(prompt);
    
    res.json({ 
      success: true, 
      output: result,
      plan: result.plan,
      code: result.code,
      dependencies: result.dependencies,
      preview: result.preview
    });
  } catch (error) {
    console.error("Multi-agent API error:", error);
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : "Failed to execute multi-agent task"
    });
  }
});

router.post("/autonomous", async (req, res) => {
  try {
    const { prompt } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    console.log('Starting autonomous agent orchestration:', prompt);
    const result = await runAutonomousAgents(prompt);
    
    res.json({ 
      success: true, 
      output: result,
      iterations: result.iteration,
      qualityScore: result.qualityScore,
      plan: result.plan,
      code: result.code,
      dependencies: result.dependencies,
      validation: result.validation,
      preview: result.preview,
      tests: result.tests
    });
  } catch (error) {
    console.error("Autonomous agents API error:", error);
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : "Failed to execute autonomous agents"
    });
  }
});

export default router;