import { projects, files, aiGenerations, collaborators, type Project, type InsertProject, type File, type InsertFile, type AiGeneration, type InsertAiGeneration, type Collaborator, type InsertCollaborator } from "@shared/schema";

export interface IStorage {
  // Projects
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUser(userId: string): Promise<Project[]>;
  updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;

  // Files
  createFile(file: InsertFile): Promise<File>;
  getFile(id: number): Promise<File | undefined>;
  getFilesByProject(projectId: number): Promise<File[]>;
  getFileByPath(projectId: number, path: string): Promise<File | undefined>;
  updateFile(id: number, updates: Partial<InsertFile>): Promise<File | undefined>;
  deleteFile(id: number): Promise<boolean>;

  // AI Generations
  createAiGeneration(generation: InsertAiGeneration): Promise<AiGeneration>;
  getAiGenerationsByProject(projectId: number): Promise<AiGeneration[]>;

  // Collaborators
  addCollaborator(collaborator: InsertCollaborator): Promise<Collaborator>;
  getCollaboratorsByProject(projectId: number): Promise<Collaborator[]>;
  updateCollaboratorStatus(id: number, isActive: boolean): Promise<Collaborator | undefined>;
}

export class MemStorage implements IStorage {
  private projects: Map<number, Project>;
  private files: Map<number, File>;
  private aiGenerations: Map<number, AiGeneration>;
  private collaborators: Map<number, Collaborator>;
  private currentId: number;

  constructor() {
    this.projects = new Map();
    this.files = new Map();
    this.aiGenerations = new Map();
    this.collaborators = new Map();
    this.currentId = 1;

    // Initialize with a sample project
    this.initializeSampleProject();
  }

  private initializeSampleProject() {
    const sampleProject: Project = {
      id: 1,
      name: "my-react-app",
      description: "A sample React application",
      userId: "user1",
      files: {},
      dependencies: {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "axios": "^1.5.0"
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.projects.set(1, sampleProject);

    const sampleFiles: File[] = [
      {
        id: 1,
        projectId: 1,
        path: "src/App.jsx",
        content: `import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('Welcome to InnoXAI!');

  useEffect(() => {
    // Live preview updates happen here
    console.log('Component updated');
  }, [count, message]);

  return (
    <div className="app">
      <h1>{message}</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
}

export default App;`,
        language: "javascript",
        isOpen: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        projectId: 1,
        path: "src/App.css",
        content: `.app {
  text-align: center;
  padding: 2rem;
}

.app h1 {
  color: #2563eb;
  margin-bottom: 1rem;
}

.app button {
  background-color: #3b82f6;
  color: white;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 0.5rem;
  cursor: pointer;
  font-size: 1rem;
}

.app button:hover {
  background-color: #2563eb;
}`,
        language: "css",
        isOpen: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 3,
        projectId: 1,
        path: "src/index.js",
        content: `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);`,
        language: "javascript",
        isOpen: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 4,
        projectId: 1,
        path: "package.json",
        content: `{
  "name": "my-react-app",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.5.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  }
}`,
        language: "json",
        isOpen: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
    ];

    sampleFiles.forEach(file => this.files.set(file.id, file));
    this.currentId = 5;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.currentId++;
    const newProject: Project = {
      ...project,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByUser(userId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(p => p.userId === userId);
  }

  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject = { ...project, ...updates, updatedAt: new Date() };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async createFile(file: InsertFile): Promise<File> {
    const id = this.currentId++;
    const newFile: File = {
      ...file,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.files.set(id, newFile);
    return newFile;
  }

  async getFile(id: number): Promise<File | undefined> {
    return this.files.get(id);
  }

  async getFilesByProject(projectId: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(f => f.projectId === projectId);
  }

  async getFileByPath(projectId: number, path: string): Promise<File | undefined> {
    return Array.from(this.files.values()).find(f => f.projectId === projectId && f.path === path);
  }

  async updateFile(id: number, updates: Partial<InsertFile>): Promise<File | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;

    const updatedFile = { ...file, ...updates, updatedAt: new Date() };
    this.files.set(id, updatedFile);
    return updatedFile;
  }

  async deleteFile(id: number): Promise<boolean> {
    return this.files.delete(id);
  }

  async createAiGeneration(generation: InsertAiGeneration): Promise<AiGeneration> {
    const id = this.currentId++;
    const newGeneration: AiGeneration = {
      ...generation,
      id,
      createdAt: new Date(),
    };
    this.aiGenerations.set(id, newGeneration);
    return newGeneration;
  }

  async getAiGenerationsByProject(projectId: number): Promise<AiGeneration[]> {
    return Array.from(this.aiGenerations.values()).filter(g => g.projectId === projectId);
  }

  async addCollaborator(collaborator: InsertCollaborator): Promise<Collaborator> {
    const id = this.currentId++;
    const newCollaborator: Collaborator = {
      ...collaborator,
      id,
      lastSeen: new Date(),
    };
    this.collaborators.set(id, newCollaborator);
    return newCollaborator;
  }

  async getCollaboratorsByProject(projectId: number): Promise<Collaborator[]> {
    return Array.from(this.collaborators.values()).filter(c => c.projectId === projectId);
  }

  async updateCollaboratorStatus(id: number, isActive: boolean): Promise<Collaborator | undefined> {
    const collaborator = this.collaborators.get(id);
    if (!collaborator) return undefined;

    const updatedCollaborator = { ...collaborator, isActive, lastSeen: new Date() };
    this.collaborators.set(id, updatedCollaborator);
    return updatedCollaborator;
  }
}

export const storage = new MemStorage();
