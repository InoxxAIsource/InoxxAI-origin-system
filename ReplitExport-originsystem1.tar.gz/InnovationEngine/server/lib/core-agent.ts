import { aiService } from './ai-service.js';
import { codeGenerator } from './code-generator.js';
import { errorHandler } from './error-handler.js';

interface ProjectContext {
  projectType: string | null;
  framework: string;
  styling: string;
  dependencies: string[];
  structure: Array<{
    path: string;
    type: string;
    purpose: string;
  }>;
}

interface Component {
  name: string;
  path: string;
  type: 'frontend' | 'backend' | 'config';
  dependencies: string[];
  purpose: string;
}

interface Architecture {
  components: Component[];
  dependencies: string[];
  structure: string[];
}

interface GenerationResult {
  files: Array<{
    path: string;
    content: string;
    type: string;
  }>;
  dependencies: string[];
  fixes?: string[];
}

export class CoreAgent {
  private context: ProjectContext;

  constructor() {
    this.context = {
      projectType: null,
      framework: 'react',
      styling: 'tailwind',
      dependencies: [],
      structure: []
    };
  }

  async generate(prompt: string): Promise<GenerationResult> {
    try {
      // Check if this requires full-stack generation
      const isFullStackProject = this.isFullStackProject(prompt);
      
      if (isFullStackProject) {
        return this.generateFullStackProject(prompt);
      }
      
      // Phase 1: Analysis
      await this.analyzeRequirements(prompt);
      
      // Phase 2: Architecture Design
      const architecture = await this.designArchitecture();
      
      // Phase 3: Implementation
      const generationResult = await this.implement(architecture);
      
      // Phase 4: Finalization
      return this.finalize(generationResult);
    } catch (error) {
      console.error('Core agent generation error:', error);
      throw error;
    }
  }

  private isFullStackProject(prompt: string): boolean {
    const lowerPrompt = prompt.toLowerCase();
    return lowerPrompt.includes('full-stack') ||
           lowerPrompt.includes('fullstack') ||
           lowerPrompt.includes('backend') ||
           lowerPrompt.includes('api') ||
           lowerPrompt.includes('database') ||
           (lowerPrompt.includes('dashboard') && lowerPrompt.includes('data'));
  }

  private async generateFullStackProject(prompt: string): Promise<GenerationResult> {
    const fullStackResult = await codeGenerator.generateFullStack(prompt);
    
    const files: Array<{ path: string; content: string; type: string }> = [
      ...fullStackResult.frontend.files.map(f => ({ ...f, type: f.type })),
      ...fullStackResult.backend.files.map(f => ({ ...f, type: f.type }))
    ];

    return {
      files,
      dependencies: fullStackResult.dependencies
    };
  }

  private async analyzeRequirements(prompt: string): Promise<void> {
    // Determine project type and requirements
    const analysis = await aiService.analyzeCode(`
      Analyze this project request and determine:
      1. Project type (dashboard, landing-page, form, chart, etc.)
      2. Required components
      3. Suggested dependencies
      4. File structure

      Request: "${prompt}"
    `);

    // Extract project context from analysis
    this.context.projectType = this.extractProjectType(prompt);
    this.context.dependencies = this.extractDependencies(prompt);
  }

  private async designArchitecture(): Promise<Architecture> {
    const components: Component[] = [];
    const dependencies: string[] = [...this.context.dependencies];

    // Determine main component structure based on project type
    switch (this.context.projectType) {
      case 'dashboard':
        components.push(
          { name: 'Dashboard', path: 'src/Dashboard.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Main dashboard component' },
          { name: 'Sidebar', path: 'src/components/Sidebar.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Navigation sidebar' },
          { name: 'Chart', path: 'src/components/Chart.jsx', type: 'frontend', dependencies: ['react', 'chart.js'], purpose: 'Data visualization' }
        );
        dependencies.push('chart.js', 'react-chartjs-2');
        break;
      
      case 'landing-page':
        components.push(
          { name: 'LandingPage', path: 'src/LandingPage.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Main landing page' },
          { name: 'Header', path: 'src/components/Header.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Page header' },
          { name: 'Footer', path: 'src/components/Footer.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Page footer' }
        );
        break;

      default:
        components.push(
          { name: 'App', path: 'src/App.jsx', type: 'frontend', dependencies: ['react'], purpose: 'Main application component' }
        );
    }

    // Add common files
    components.push(
      { name: 'Package', path: 'package.json', type: 'config', dependencies: [], purpose: 'Project dependencies' },
      { name: 'Styles', path: 'src/App.css', type: 'frontend', dependencies: [], purpose: 'Application styles' }
    );

    return {
      components,
      dependencies: Array.from(new Set(dependencies)),
      structure: components.map(c => c.path)
    };
  }

  private async implement(architecture: Architecture): Promise<GenerationResult> {
    const files: Array<{ path: string; content: string; type: string }> = [];

    for (const component of architecture.components) {
      let content: string;

      if (component.path.endsWith('.json')) {
        content = this.generatePackageJson(architecture.dependencies);
      } else if (component.path.endsWith('.css')) {
        content = this.generateStyles();
      } else {
        // Generate React component
        content = await aiService.generateCode(
          `Create a ${component.name} component for ${component.purpose}. 
           Framework: ${this.context.framework}, Styling: ${this.context.styling}.
           Make it professional and functional.`,
          this.context.framework,
          this.context.styling
        );
      }

      files.push({
        path: component.path,
        content,
        type: component.type
      });
    }

    return {
      files,
      dependencies: architecture.dependencies
    };
  }

  private async finalize(result: GenerationResult): Promise<GenerationResult> {
    // Validate and fix common issues before finalizing
    const context = {
      dependencies: result.dependencies,
      files: result.files,
      framework: this.context.framework,
      projectType: this.context.projectType || 'general'
    };

    const validationResult = await errorHandler.validateAndFix(result.files, context);
    
    // Add additional files for better project setup
    const additionalFiles = [
      {
        path: 'README.md',
        content: this.generateReadme(),
        type: 'documentation'
      },
      {
        path: '.env.example',
        content: this.generateEnvExample(),
        type: 'config'
      }
    ];

    // Update package.json with corrected dependencies
    const packageJsonFile = validationResult.files.find(f => f.path === 'package.json');
    if (packageJsonFile) {
      packageJsonFile.content = this.generatePackageJson(validationResult.dependencies);
    } else {
      additionalFiles.push({
        path: 'package.json',
        content: this.generatePackageJson(validationResult.dependencies),
        type: 'config'
      });
    }

    const finalResult: GenerationResult = {
      files: [...validationResult.files, ...additionalFiles],
      dependencies: validationResult.dependencies
    };
    
    if (validationResult.fixes && validationResult.fixes.length > 0) {
      (finalResult as any).fixes = validationResult.fixes;
    }
    
    return finalResult;
  }

  private extractProjectType(prompt: string): string {
    const lowerPrompt = prompt.toLowerCase();
    
    if (lowerPrompt.includes('dashboard') || lowerPrompt.includes('admin')) return 'dashboard';
    if (lowerPrompt.includes('landing') || lowerPrompt.includes('homepage')) return 'landing-page';
    if (lowerPrompt.includes('form') || lowerPrompt.includes('signup') || lowerPrompt.includes('login')) return 'form';
    if (lowerPrompt.includes('chart') || lowerPrompt.includes('graph') || lowerPrompt.includes('analytics')) return 'chart';
    if (lowerPrompt.includes('chat') || lowerPrompt.includes('messaging')) return 'chat';
    
    return 'general';
  }

  private extractDependencies(prompt: string): string[] {
    const dependencies: string[] = ['react', 'react-dom'];
    const lowerPrompt = prompt.toLowerCase();

    if (lowerPrompt.includes('chart') || lowerPrompt.includes('graph')) {
      dependencies.push('chart.js', 'react-chartjs-2');
    }
    
    if (lowerPrompt.includes('form') || lowerPrompt.includes('validation')) {
      dependencies.push('react-hook-form', 'zod');
    }

    if (lowerPrompt.includes('animation') || lowerPrompt.includes('motion')) {
      dependencies.push('framer-motion');
    }

    return dependencies;
  }

  private generatePackageJson(dependencies: string[]): string {
    const packageData = {
      name: "generated-project",
      version: "1.0.0",
      description: "Generated by InnoXAI",
      main: "index.js",
      scripts: {
        start: "react-scripts start",
        build: "react-scripts build",
        test: "react-scripts test",
        eject: "react-scripts eject"
      },
      dependencies: {
        react: "^18.2.0",
        "react-dom": "^18.2.0",
        "react-scripts": "5.0.1",
        ...dependencies.reduce((acc, dep) => {
          acc[dep] = "latest";
          return acc;
        }, {} as Record<string, string>)
      },
      browserslist: {
        production: [">0.2%", "not dead", "not op_mini all"],
        development: ["last 1 chrome version", "last 1 firefox version", "last 1 safari version"]
      }
    };

    return JSON.stringify(packageData, null, 2);
  }

  private generateStyles(): string {
    return `/* Generated styles for InnoXAI project */
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

* {
  box-sizing: border-box;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

@media (max-width: 768px) {
  .container {
    padding: 0 0.5rem;
  }
}`;
  }

  private generateReadme(): string {
    return `# Generated Project

This project was generated by InnoXAI AI Development Platform.

## Getting Started

1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

2. Start the development server:
   \`\`\`bash
   npm start
   \`\`\`

3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Features

- React 18 with modern hooks
- Tailwind CSS for styling
- Responsive design
- Professional component structure

## Available Scripts

- \`npm start\` - Runs the app in development mode
- \`npm build\` - Builds the app for production
- \`npm test\` - Launches the test runner

## Generated by InnoXAI

This project was automatically generated using AI-powered code generation.
`;
  }

  private generateEnvExample(): string {
    return `# Environment Variables
# Copy this file to .env and fill in your values

# API Configuration
# REACT_APP_API_URL=http://localhost:3001
# REACT_APP_API_KEY=your_api_key_here

# Database (if needed)
# DATABASE_URL=your_database_url_here

# External Services
# OPENAI_API_KEY=your_openai_key_here
`;
  }
}

export const coreAgent = new CoreAgent();