import express, { Request, Response, Application } from 'express';
import { createServer, Server } from 'http';
import cors from 'cors';

interface RouteDefinition {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  handler: string;
  description?: string;
}

export class BackendPreviewManager {
  private app: Application;
  private server: Server | null = null;
  private port: number;
  private activeRoutes: Map<string, boolean> = new Map();

  constructor(port = 3001) {
    this.port = port;
    this.app = express();
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // Health check endpoint
    this.app.get('/health', (req: Request, res: Response) => {
      res.json({ status: 'healthy', timestamp: new Date().toISOString() });
    });

    // Error handling middleware
    this.app.use((err: any, req: Request, res: Response, next: any) => {
      console.error('Backend preview error:', err);
      res.status(500).json({
        error: 'Internal server error',
        message: err.message,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
      });
    });
  }

  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.server = this.app.listen(this.port, () => {
          console.log(`Backend preview server running on port ${this.port}`);
          resolve();
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  async updateRoutes(routes: RouteDefinition[]): Promise<void> {
    try {
      // Clear existing dynamic routes
      this.clearDynamicRoutes();

      // Add new routes
      for (const route of routes) {
        this.addRoute(route);
      }

      console.log(`Updated ${routes.length} routes in backend preview`);
    } catch (error) {
      console.error('Error updating routes:', error);
      throw error;
    }
  }

  private clearDynamicRoutes(): void {
    // Remove routes that were dynamically added
    this.activeRoutes.forEach((_, path) => {
      // Note: Express doesn't have a built-in way to remove routes
      // In a production environment, you'd want to restart the server
      // or use a more sophisticated routing system
    });
    this.activeRoutes.clear();
  }

  private addRoute(route: RouteDefinition): void {
    const { path, method, handler } = route;
    const expressMethod = method.toLowerCase() as 'get' | 'post' | 'put' | 'delete';

    try {
      this.app[expressMethod](path, (req: Request, res: Response) => {
        this.executeHandler(handler, req, res);
      });

      this.activeRoutes.set(`${method}:${path}`, true);
      console.log(`Added route: ${method} ${path}`);
    } catch (error) {
      console.error(`Error adding route ${method} ${path}:`, error);
    }
  }

  private executeHandler(handlerCode: string, req: Request, res: Response): void {
    try {
      // Create a safe execution context
      const context = {
        req,
        res,
        console: {
          log: (...args: any[]) => console.log('[Handler]', ...args),
          error: (...args: any[]) => console.error('[Handler]', ...args)
        },
        // Common utilities
        JSON,
        Date,
        Math,
        // Prevent access to dangerous globals
        process: undefined,
        require: undefined,
        module: undefined,
        global: undefined,
        Buffer: undefined
      };

      // Execute the handler in a controlled environment
      const handlerFunction = new Function(
        'req', 'res', 'console', 'JSON', 'Date', 'Math',
        `
        "use strict";
        ${handlerCode}
        `
      );

      const result = handlerFunction(
        context.req,
        context.res,
        context.console,
        context.JSON,
        context.Date,
        context.Math
      );

      // Handle async results
      if (result instanceof Promise) {
        result.catch(error => this.handleError(res, error));
      }
    } catch (error) {
      this.handleError(res, error);
    }
  }

  private handleError(res: Response, error: any): void {
    console.error('Handler execution error:', error);
    
    if (!res.headersSent) {
      res.status(500).json({
        error: 'Handler execution failed',
        message: error.message,
        type: error.name || 'Error'
      });
    }
  }

  async generateSampleRoutes(projectType: string): Promise<RouteDefinition[]> {
    const routes: RouteDefinition[] = [];

    switch (projectType) {
      case 'dashboard':
        routes.push(
          {
            path: '/api/dashboard/stats',
            method: 'GET',
            handler: `
              const stats = {
                users: Math.floor(Math.random() * 10000) + 1000,
                revenue: Math.floor(Math.random() * 100000) + 50000,
                orders: Math.floor(Math.random() * 500) + 100,
                growth: (Math.random() * 20 + 5).toFixed(1)
              };
              res.json(stats);
            `,
            description: 'Get dashboard statistics'
          },
          {
            path: '/api/dashboard/chart-data',
            method: 'GET',
            handler: `
              const chartData = {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                  label: 'Revenue',
                  data: Array.from({length: 6}, () => Math.floor(Math.random() * 10000) + 5000),
                  borderColor: 'rgb(75, 192, 192)',
                  backgroundColor: 'rgba(75, 192, 192, 0.2)'
                }]
              };
              res.json(chartData);
            `,
            description: 'Get chart data for dashboard'
          }
        );
        break;

      case 'form':
        routes.push(
          {
            path: '/api/submit',
            method: 'POST',
            handler: `
              const { name, email, message } = req.body;
              
              if (!name || !email) {
                return res.status(400).json({ error: 'Name and email are required' });
              }
              
              // Simulate processing
              const submissionId = 'sub_' + Date.now();
              
              res.json({
                success: true,
                message: 'Form submitted successfully',
                submissionId,
                data: { name, email, message }
              });
            `,
            description: 'Handle form submission'
          }
        );
        break;

      case 'api':
        routes.push(
          {
            path: '/api/users',
            method: 'GET',
            handler: `
              const users = Array.from({length: 10}, (_, i) => ({
                id: i + 1,
                name: 'User ' + (i + 1),
                email: 'user' + (i + 1) + '@example.com',
                status: Math.random() > 0.5 ? 'active' : 'inactive'
              }));
              res.json(users);
            `,
            description: 'Get list of users'
          },
          {
            path: '/api/users/:id',
            method: 'GET',
            handler: `
              const userId = parseInt(req.params.id);
              const user = {
                id: userId,
                name: 'User ' + userId,
                email: 'user' + userId + '@example.com',
                status: 'active',
                createdAt: new Date().toISOString()
              };
              res.json(user);
            `,
            description: 'Get user by ID'
          }
        );
        break;

      default:
        routes.push(
          {
            path: '/api/status',
            method: 'GET',
            handler: `
              res.json({
                status: 'running',
                timestamp: new Date().toISOString(),
                version: '1.0.0'
              });
            `,
            description: 'API status endpoint'
          }
        );
    }

    return routes;
  }

  getActiveRoutes(): string[] {
    return Array.from(this.activeRoutes.keys());
  }

  async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          console.log('Backend preview server stopped');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }

  getPreviewUrl(): string {
    return `http://localhost:${this.port}`;
  }
}

export const backendPreviewManager = new BackendPreviewManager();