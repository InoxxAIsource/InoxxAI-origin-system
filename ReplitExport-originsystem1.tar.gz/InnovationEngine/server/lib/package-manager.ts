import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

interface PackageInfo {
  name: string;
  version: string;
  description: string;
  downloads?: number;
}

interface InstallResult {
  success: boolean;
  packageName: string;
  version: string;
  message: string;
}

class PackageManager {
  async installPackage(packageName: string, projectId: number): Promise<InstallResult> {
    try {
      // Validate package name
      if (!this.isValidPackageName(packageName)) {
        throw new Error("Invalid package name");
      }

      // Get package info first
      const packageInfo = await this.getPackageInfo(packageName);
      
      // Simulate installation (in a real implementation, this would install to the project directory)
      console.log(`Installing ${packageName} for project ${projectId}`);
      
      return {
        success: true,
        packageName,
        version: packageInfo.version,
        message: `Successfully installed ${packageName}@${packageInfo.version}`,
      };
    } catch (error) {
      console.error("Package installation failed:", error);
      throw new Error(`Failed to install package: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async searchPackages(query: string): Promise<PackageInfo[]> {
    try {
      // In a real implementation, this would search npm registry
      // For now, return mock popular packages that match the query
      const mockPackages: PackageInfo[] = [
        { name: "react", version: "18.2.0", description: "A JavaScript library for building user interfaces", downloads: 20000000 },
        { name: "react-dom", version: "18.2.0", description: "React package for working with the DOM", downloads: 20000000 },
        { name: "axios", version: "1.5.0", description: "Promise based HTTP client for the browser and node.js", downloads: 25000000 },
        { name: "lodash", version: "4.17.21", description: "A modern JavaScript utility library", downloads: 30000000 },
        { name: "express", version: "4.18.2", description: "Fast, unopinionated, minimalist web framework", downloads: 25000000 },
        { name: "typescript", version: "5.2.2", description: "TypeScript is a language for application-scale JavaScript", downloads: 15000000 },
        { name: "tailwindcss", version: "3.3.3", description: "A utility-first CSS framework", downloads: 5000000 },
        { name: "next", version: "13.5.4", description: "The React Framework", downloads: 10000000 },
        { name: "vue", version: "3.3.4", description: "The progressive JavaScript framework", downloads: 8000000 },
        { name: "socket.io", version: "4.7.2", description: "Realtime application framework", downloads: 3000000 },
      ];

      return mockPackages.filter(pkg => 
        pkg.name.toLowerCase().includes(query.toLowerCase()) ||
        pkg.description.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 10);
    } catch (error) {
      console.error("Package search failed:", error);
      return [];
    }
  }

  async getPackageInfo(packageName: string): Promise<PackageInfo> {
    try {
      // Mock package info - in reality, this would fetch from npm registry
      const mockVersions: Record<string, string> = {
        "react": "18.2.0",
        "react-dom": "18.2.0",
        "axios": "1.5.0",
        "lodash": "4.17.21",
        "express": "4.18.2",
        "typescript": "5.2.2",
        "tailwindcss": "3.3.3",
        "next": "13.5.4",
        "vue": "3.3.4",
        "socket.io": "4.7.2",
      };

      return {
        name: packageName,
        version: mockVersions[packageName] || "1.0.0",
        description: `Package ${packageName}`,
      };
    } catch (error) {
      throw new Error(`Failed to get package info for ${packageName}`);
    }
  }

  async getInstalledPackages(projectId: number): Promise<Record<string, string>> {
    try {
      // In a real implementation, this would read package.json
      // For now, return mock dependencies
      return {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "axios": "^1.5.0",
      };
    } catch (error) {
      console.error("Failed to get installed packages:", error);
      return {};
    }
  }

  async uninstallPackage(packageName: string, projectId: number): Promise<boolean> {
    try {
      console.log(`Uninstalling ${packageName} from project ${projectId}`);
      // Simulate uninstallation
      return true;
    } catch (error) {
      console.error("Package uninstallation failed:", error);
      return false;
    }
  }

  private isValidPackageName(name: string): boolean {
    // Basic npm package name validation
    const npmNameRegex = /^(@[a-z0-9-~][a-z0-9-._~]*\/)?[a-z0-9-~][a-z0-9-._~]*$/;
    return npmNameRegex.test(name) && name.length <= 214;
  }
}

export const packageManager = new PackageManager();
