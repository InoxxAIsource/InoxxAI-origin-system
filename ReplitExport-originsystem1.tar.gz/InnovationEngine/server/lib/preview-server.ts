import { storage } from "../storage";
import * as fs from "fs";
import * as path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

class PreviewServer {
  private previewUrls: Map<number, string> = new Map();
  private previewPorts: Map<number, number> = new Map();
  private nextPort = 3001;

  async getPreviewUrl(projectId: number): Promise<string> {
    try {
      // Use our main server to serve preview content
      const url = `http://localhost:5000/preview/${projectId}`;
      this.previewUrls.set(projectId, url);
      return url;
    } catch (error) {
      console.error("Failed to get preview URL:", error);
      throw new Error("Failed to generate preview URL");
    }
  }

  async refreshPreview(projectId: number): Promise<void> {
    try {
      console.log(`Refreshing preview for project ${projectId}`);
      
      // In a real implementation, this would rebuild and restart the preview
      // For now, we'll just simulate the refresh
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log(`Preview refreshed for project ${projectId}`);
    } catch (error) {
      console.error("Failed to refresh preview:", error);
      throw new Error("Failed to refresh preview");
    }
  }

  private async startPreviewServer(projectId: number): Promise<void> {
    try {
      const project = await storage.getProject(projectId);
      if (!project) {
        throw new Error("Project not found");
      }

      const files = await storage.getFilesByProject(projectId);
      const port = this.previewPorts.get(projectId);
      
      if (!port) {
        throw new Error("No port assigned for project");
      }

      // Create project directory structure in memory
      const projectDir = `/tmp/project-${projectId}`;
      
      // Ensure directory exists
      await fs.promises.mkdir(projectDir, { recursive: true });
      
      // Write all files to the project directory
      for (const file of files) {
        const filePath = path.join(projectDir, file.path);
        const fileDir = path.dirname(filePath);
        
        // Create directory if it doesn't exist
        await fs.promises.mkdir(fileDir, { recursive: true });
        
        // Write file content
        await fs.promises.writeFile(filePath, file.content, 'utf8');
      }
      
      // Create a basic package.json if it doesn't exist
      const packageJsonPath = path.join(projectDir, 'package.json');
      if (!fs.existsSync(packageJsonPath)) {
        const defaultPackageJson = {
          name: project.name,
          version: "1.0.0",
          type: "module",
          scripts: {
            dev: "vite",
            build: "vite build",
            preview: "vite preview"
          },
          dependencies: project.dependencies || {
            "react": "^18.2.0",
            "react-dom": "^18.2.0"
          },
          devDependencies: {
            "@vitejs/plugin-react": "^4.0.0",
            "vite": "^4.4.0"
          }
        };
        await fs.promises.writeFile(packageJsonPath, JSON.stringify(defaultPackageJson, null, 2));
      }
      
      // Create vite.config.js if it doesn't exist
      const viteConfigPath = path.join(projectDir, 'vite.config.js');
      if (!fs.existsSync(viteConfigPath)) {
        const viteConfig = `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: ${port},
    host: '0.0.0.0'
  }
})`;
        await fs.promises.writeFile(viteConfigPath, viteConfig);
      }
      
      // Create index.html if it doesn't exist
      const indexHtmlPath = path.join(projectDir, 'index.html');
      if (!fs.existsSync(indexHtmlPath)) {
        const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${project.name}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/index.js"></script>
  </body>
</html>`;
        await fs.promises.writeFile(indexHtmlPath, indexHtml);
      }
      
      console.log(`Starting preview server for project: ${project.name}`);
      console.log(`Project files:`, files.map(f => f.path));
      console.log(`Project directory: ${projectDir}`);
      
      // Install dependencies and start Vite dev server
      try {
        // Change to project directory and install dependencies
        process.chdir(projectDir);
        console.log(`Installing dependencies for project ${projectId}...`);
        await execAsync('npm install', { cwd: projectDir });
        
        // Start Vite dev server in the background
        console.log(`Starting Vite dev server on port ${port}...`);
        const viteProcess = exec(`npx vite --port ${port} --host 0.0.0.0`, { 
          cwd: projectDir,
          env: { ...process.env, NODE_ENV: 'development' }
        });
        
        viteProcess.stdout?.on('data', (data) => {
          console.log(`[Vite ${projectId}]:`, data.toString());
        });
        
        viteProcess.stderr?.on('data', (data) => {
          console.error(`[Vite ${projectId} Error]:`, data.toString());
        });
        
        // Wait a bit for the server to start
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        console.log(`Preview server started for project ${projectId} on port ${port}`);
      } catch (error) {
        console.error(`Failed to start Vite server for project ${projectId}:`, error);
        // Fallback to serving static content
        this.startStaticServer(projectId, port, projectDir);
      }
      
    } catch (error) {
      console.error("Failed to start preview server:", error);
      throw error;
    }
  }

  private startStaticServer(projectId: number, port: number, projectDir: string): void {
    const express = require('express');
    const app = express();
    
    // Serve static files from project directory
    app.use(express.static(projectDir));
    
    // Fallback to index.html for SPA routing
    app.get('*', (req: any, res: any) => {
      res.sendFile(path.join(projectDir, 'index.html'));
    });
    
    app.listen(port, '0.0.0.0', () => {
      console.log(`Static server for project ${projectId} running on port ${port}`);
    });
  }

  async stopPreviewServer(projectId: number): Promise<void> {
    try {
      console.log(`Stopping preview server for project ${projectId}`);
      this.previewUrls.delete(projectId);
    } catch (error) {
      console.error("Failed to stop preview server:", error);
    }
  }

  async getPreviewContent(projectId: number): Promise<string> {
    try {
      const files = await storage.getFilesByProject(projectId);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return "<html><body><h1>Project not found</h1></body></html>";
      }

      // Find the main component files
      const appFile = files.find(f => f.path === "src/App.jsx");
      const cssFile = files.find(f => f.path === "src/App.css");
      const indexFile = files.find(f => f.path === "src/index.js");
      
      // Extract CSS content
      const cssContent = cssFile ? cssFile.content : `
        .app {
          text-align: center;
          padding: 2rem;
        }
        .app h1 {
          color: #2563eb;
          margin-bottom: 1rem;
        }
        .app button {
          background-color: #3b82f6;
          color: white;
          padding: 0.5rem 1rem;
          border: none;
          border-radius: 0.5rem;
          cursor: pointer;
          font-size: 1rem;
        }
        .app button:hover {
          background-color: #2563eb;
        }
      `;

      // Generate preview HTML with actual component content
      return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Preview - ${project.name}</title>
    <style>
        ${cssContent}
        
        /* Live preview styles */
        body {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
        
        .live-preview-indicator {
            position: fixed;
            top: 10px;
            right: 10px;
            background: #10b981;
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .live-dot {
            width: 6px;
            height: 6px;
            background: white;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 50% { opacity: 1; }
            25%, 75% { opacity: 0.5; }
        }
    </style>
    
    <!-- React CDN -->
    <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    
    <div class="live-preview-indicator">
        <div class="live-dot"></div>
        Live
    </div>
    
    <script type="text/babel">
        const { useState, useEffect } = React;
        
        ${appFile ? this.transformJSXForBrowser(appFile.content) : `
        function App() {
          const [count, setCount] = useState(0);
          const [message, setMessage] = useState('Welcome to InnoXAI!');

          useEffect(() => {
            console.log('Component updated');
          }, [count, message]);

          return React.createElement('div', { className: 'app' },
            React.createElement('h1', null, message),
            React.createElement('p', null, 'Count: ' + count),
            React.createElement('button', { 
              onClick: () => setCount(count + 1) 
            }, 'Increment')
          );
        }
        `}
        
        // Render the app
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(React.createElement(App));
        
        // Auto-refresh functionality
        let lastUpdate = Date.now();
        setInterval(() => {
            // Check for updates every 2 seconds
            fetch('/api/projects/${projectId}/files')
                .then(res => res.json())
                .then(files => {
                    const latestUpdate = Math.max(...files.map(f => new Date(f.updatedAt).getTime()));
                    if (latestUpdate > lastUpdate) {
                        lastUpdate = latestUpdate;
                        // Reload the page to get the latest content
                        setTimeout(() => window.location.reload(), 500);
                    }
                })
                .catch(err => console.log('Preview sync error:', err));
        }, 2000);
    </script>
</body>
</html>`;
    } catch (error) {
      console.error("Failed to get preview content:", error);
      return `
<!DOCTYPE html>
<html>
<head>
    <title>Preview Error</title>
    <style>
        body { 
            font-family: system-ui; 
            text-align: center; 
            padding: 40px; 
            background: #f5f5f5; 
        }
        .error { 
            background: white; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
        }
    </style>
</head>
<body>
    <div class="error">
        <h1>Preview Error</h1>
        <p>Unable to load project preview</p>
    </div>
</body>
</html>`;
    }
  }

  private transformJSXForBrowser(jsxContent: string): string {
    // Simple JSX to React.createElement transformation for browser compatibility
    let transformed = jsxContent;
    
    // Remove import statements
    transformed = transformed.replace(/import.*from.*['"`];?/g, '');
    transformed = transformed.replace(/export\s+default\s+/g, '');
    
    // Basic JSX transformation - this is simplified for demo purposes
    // In production, you'd use Babel or a proper JSX transformer
    transformed = transformed.replace(/<(\w+)([^>]*)>/g, (match, tagName, props) => {
      if (props.trim()) {
        return `React.createElement('${tagName}', {${props.replace(/(\w+)=/g, '$1:')}`;
      }
      return `React.createElement('${tagName}', null`;
    });
    
    transformed = transformed.replace(/<\/\w+>/g, ')');
    
    return transformed;
  }
}

export const previewServer = new PreviewServer();
