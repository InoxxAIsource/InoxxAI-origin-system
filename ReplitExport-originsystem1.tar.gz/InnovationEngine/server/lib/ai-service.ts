import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

class AIService {
  async generateCode(prompt: string, framework: string = "react", styling: string = "tailwind"): Promise<string> {
    try {
      // Check if API key is available
      if (!process.env.OPENAI_API_KEY) {
        throw new Error("OpenAI API key is not configured. Please provide your OPENAI_API_KEY.");
      }

      console.log("Starting AI code generation for:", prompt.substring(0, 50) + "...");
      console.log("Using framework:", framework, "styling:", styling);
      const systemPrompt = `You are an expert full-stack developer. Generate clean, production-ready code based on the user's requirements. 

Framework: ${framework}
Styling: ${styling}

IMPORTANT: Return ONLY the raw code without any markdown formatting, explanations, or additional text. Do not use \`\`\` code blocks or any markdown syntax.

Guidelines:
- Write modern, clean, and maintainable code
- Include proper TypeScript types when applicable
- Use best practices for the chosen framework
- Ensure the code is functional and complete
- For React components, use functional components with hooks
- For styling, use ${styling} classes appropriately
- Make the code responsive and accessible

Return the code directly without any formatting or explanations.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ],
        max_tokens: 2000,
        temperature: 0.7,
      });

      let generatedCode = response.choices[0].message.content || "// Error generating code";
      
      // Clean up the response - remove markdown formatting
      generatedCode = generatedCode.replace(/```typescript\n?/g, '').replace(/```jsx?\n?/g, '').replace(/```\n?/g, '');
      
      // Remove extra instructions and comments that aren't part of the code
      generatedCode = generatedCode.replace(/### Additional Steps[\s\S]*$/, '');
      generatedCode = generatedCode.replace(/^\s*\/\/ Additional Steps[\s\S]*$/, '');
      
      return generatedCode.trim();
    } catch (error) {
      console.error("AI generation error:", error);
      
      // If it's an API key issue, provide helpful error message
      if (error.message?.includes("API key") || error.code === 'invalid_api_key') {
        throw new Error("OpenAI API key is invalid or not configured. Please provide a valid API key.");
      }
      
      // If it's a quota issue
      if (error.code === 'insufficient_quota') {
        throw new Error("OpenAI API quota exceeded. Please check your billing.");
      }
      
      // For timeout or network issues, provide a helpful message
      if (error.message?.includes("timeout") || error.code === 'ECONNRESET') {
        throw new Error("OpenAI API request timed out. Please check your API key and try again.");
      }
      
      throw new Error(`AI generation failed: ${error.message}`);
    }
  }

  async analyzeCode(code: string): Promise<{
    suggestions: string[];
    errors: string[];
    quality: number;
  }> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a code review expert. Analyze the provided code and return suggestions for improvement, potential errors, and a quality score (1-10). Respond with JSON in this format: { 'suggestions': string[], 'errors': string[], 'quality': number }",
          },
          {
            role: "user",
            content: `Please analyze this code:\n\n${code}`,
          },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        suggestions: result.suggestions || [],
        errors: result.errors || [],
        quality: Math.max(1, Math.min(10, result.quality || 5)),
      };
    } catch (error) {
      console.error("Code analysis error:", error);
      return {
        suggestions: ["Unable to analyze code at this time"],
        errors: [],
        quality: 5,
      };
    }
  }

  async explainCode(code: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a programming tutor. Explain the provided code in a clear, educational way. Break down what the code does, how it works, and any important concepts it demonstrates.",
          },
          {
            role: "user",
            content: `Please explain this code:\n\n${code}`,
          },
        ],
        max_tokens: 1000,
      });

      return response.choices[0].message.content || "Unable to explain this code.";
    } catch (error) {
      console.error("Code explanation error:", error);
      throw new Error("Failed to explain code");
    }
  }

  async optimizeCode(code: string, language: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are a code optimization expert. Optimize the provided ${language} code for better performance, readability, and maintainability. Return only the optimized code.`,
          },
          {
            role: "user",
            content: code,
          },
        ],
        max_tokens: 2000,
      });

      return response.choices[0].message.content || code;
    } catch (error) {
      console.error("Code optimization error:", error);
      return code;
    }
  }
}

export const aiService = new AIService();
