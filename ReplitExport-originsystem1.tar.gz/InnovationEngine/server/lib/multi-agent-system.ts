import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { RunnableSequence } from "@langchain/core/runnables";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const llm = new ChatOpenAI({
  model: "gpt-4o",
  temperature: 0.7,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

interface AgentTask {
  id: string;
  type: 'analysis' | 'architecture' | 'implementation' | 'testing' | 'optimization';
  description: string;
  input: any;
  priority: number;
}

interface AgentResult {
  agentId: string;
  taskId: string;
  result: any;
  confidence: number;
  suggestions?: string[];
}

export class ArchitectAgent {
  private chain: RunnableSequence;

  constructor() {
    const prompt = `You are an expert software architect. Your role is to:
1. Analyze project requirements and determine the best architecture
2. Choose appropriate frameworks, libraries, and design patterns
3. Define component structure and data flow
4. Ensure scalability and maintainability

Always respond with a structured JSON object containing:
- architecture: detailed system design
- technologies: recommended tech stack
- components: list of components to build
- dataFlow: how data moves through the system
- recommendations: best practices to follow`;

    this.chain = RunnableSequence.from([
      {
        messages: (input: { prompt: string }) => [
          new SystemMessage(prompt),
          new HumanMessage(input.prompt)
        ]
      },
      llm,
      new StringOutputParser()
    ]);
  }

  async analyze(projectPrompt: string): Promise<any> {
    try {
      const result = await this.chain.invoke({ prompt: projectPrompt });
      return JSON.parse(result);
    } catch (error) {
      console.error('ArchitectAgent error:', error);
      return {
        architecture: 'React component-based architecture',
        technologies: ['React', 'TypeScript', 'Tailwind CSS'],
        components: ['MainComponent'],
        dataFlow: 'Props down, events up',
        recommendations: ['Use functional components', 'Implement proper error handling']
      };
    }
  }
}

export class DeveloperAgent {
  private chain: RunnableSequence;

  constructor() {
    const prompt = `You are an expert frontend developer. Your role is to:
1. Implement React components based on architectural specifications
2. Write clean, maintainable, and accessible code
3. Follow modern React best practices
4. Ensure responsive design and user experience

Always generate production-ready React code with:
- Proper TypeScript types (when applicable)
- Accessible HTML elements
- Responsive Tailwind CSS classes
- Error handling and loading states
- Clean component structure`;

    this.chain = RunnableSequence.from([
      {
        messages: (input: { specification: string }) => [
          new SystemMessage(prompt),
          new HumanMessage(`Generate React component based on: ${input.specification}`)
        ]
      },
      llm,
      new StringOutputParser()
    ]);
  }

  async implement(specification: string): Promise<string> {
    try {
      const result = await this.chain.invoke({ specification });
      // Extract code from the response if it's wrapped in markdown
      const codeMatch = result.match(/```(?:jsx?|typescript|tsx?)?\n([\s\S]*?)\n```/);
      return codeMatch ? codeMatch[1] : result;
    } catch (error) {
      console.error('DeveloperAgent error:', error);
      return `// Error generating code
export default function Component() {
  return <div className="p-4">Component implementation error</div>;
}`;
    }
  }
}

export class QualityAgent {
  private chain: RunnableSequence;

  constructor() {
    const prompt = `You are a code quality specialist. Your role is to:
1. Review code for bugs, performance issues, and best practices
2. Suggest improvements and optimizations
3. Ensure accessibility and security standards
4. Validate component functionality

Provide feedback as a JSON object with:
- issues: array of problems found
- suggestions: array of improvement recommendations
- score: quality score from 1-10
- optimizations: performance improvements`;

    this.chain = RunnableSequence.from([
      {
        messages: (input: { code: string }) => [
          new SystemMessage(prompt),
          new HumanMessage(`Review this code: ${input.code}`)
        ]
      },
      llm,
      new StringOutputParser()
    ]);
  }

  async review(code: string): Promise<any> {
    try {
      const result = await this.chain.invoke({ code });
      return JSON.parse(result);
    } catch (error) {
      console.error('QualityAgent error:', error);
      return {
        issues: [],
        suggestions: ['Add error handling', 'Improve accessibility'],
        score: 7,
        optimizations: ['Use React.memo for performance']
      };
    }
  }
}

export class MultiAgentCoordinator {
  private architectAgent: ArchitectAgent;
  private developerAgent: DeveloperAgent;
  private qualityAgent: QualityAgent;
  private taskQueue: AgentTask[] = [];

  constructor() {
    this.architectAgent = new ArchitectAgent();
    this.developerAgent = new DeveloperAgent();
    this.qualityAgent = new QualityAgent();
  }

  async processProject(prompt: string): Promise<{
    architecture: any;
    code: string;
    quality: any;
    iterations: number;
  }> {
    let iterations = 0;
    const maxIterations = 3;

    // Step 1: Architecture Analysis
    console.log('🏗️ Architecture Agent: Analyzing project requirements...');
    const architecture = await this.architectAgent.analyze(prompt);

    // Step 2: Initial Implementation
    console.log('👨‍💻 Developer Agent: Implementing solution...');
    let code = await this.developerAgent.implement(
      `${prompt}\n\nArchitecture: ${JSON.stringify(architecture)}`
    );

    // Step 3: Quality Review and Iteration
    let quality;
    while (iterations < maxIterations) {
      console.log(`🔍 Quality Agent: Reviewing code (iteration ${iterations + 1})...`);
      quality = await this.qualityAgent.review(code);

      if (quality.score >= 8 || iterations === maxIterations - 1) {
        break;
      }

      // If quality is low, ask developer to improve
      console.log('🔄 Developer Agent: Improving code based on feedback...');
      const improvements = quality.suggestions.join(', ');
      code = await this.developerAgent.implement(
        `Improve this code: ${code}\n\nFeedback: ${improvements}`
      );

      iterations++;
    }

    return {
      architecture,
      code,
      quality: quality || { score: 7, issues: [], suggestions: [] },
      iterations: iterations + 1
    };
  }

  async generateFullStack(prompt: string): Promise<{
    frontend: { code: string; architecture: any };
    backend: { routes: any[]; architecture: any };
    quality: any;
  }> {
    // Analyze if this needs full-stack
    const architecture = await this.architectAgent.analyze(
      `${prompt}\n\nDetermine if this needs backend API and database. If so, design both frontend and backend architecture.`
    );

    // Generate frontend
    const frontendCode = await this.developerAgent.implement(
      `Frontend: ${prompt}\n\nArchitecture: ${JSON.stringify(architecture)}`
    );

    // Generate backend if needed
    let backendRoutes = [];
    if (architecture.needsBackend || prompt.toLowerCase().includes('backend') || 
        prompt.toLowerCase().includes('api') || prompt.toLowerCase().includes('database')) {
      
      const backendSpec = `Generate Express.js API routes for: ${prompt}`;
      const backendCode = await this.developerAgent.implement(backendSpec);
      
      // Extract routes from backend code
      backendRoutes = this.extractRoutesFromCode(backendCode);
    }

    const quality = await this.qualityAgent.review(frontendCode);

    return {
      frontend: { code: frontendCode, architecture },
      backend: { routes: backendRoutes, architecture },
      quality
    };
  }

  private extractRoutesFromCode(code: string): any[] {
    const routes = [];
    const routeMatches = code.match(/(app\.(get|post|put|delete)\(['"`]([^'"]+)['"`])/g) || [];
    
    routeMatches.forEach((match, index) => {
      const [, , method, path] = match.match(/(get|post|put|delete)\(['"`]([^'"]+)['"`]/) || [];
      if (method && path) {
        routes.push({
          method: method.toUpperCase(),
          path,
          handler: `// Handler for ${method.toUpperCase()} ${path}`,
          description: `Auto-generated ${method} endpoint`
        });
      }
    });

    return routes;
  }
}

export const multiAgentSystem = new MultiAgentCoordinator();