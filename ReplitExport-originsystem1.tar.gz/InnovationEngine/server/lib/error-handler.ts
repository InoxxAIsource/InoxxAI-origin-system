interface ErrorContext {
  dependencies: string[];
  files: Array<{ path: string; content: string; type: string }>;
  framework: string;
  projectType: string;
}

interface ErrorSolution {
  solution: string;
  action: (error: Error, context: ErrorContext) => {
    files?: Array<{ path: string; content: string }>;
    dependencies?: string[];
    instructions?: string;
    message: string;
  };
}

interface ErrorHandlingResult {
  files?: Array<{ path: string; content: string }>;
  dependencies?: string[];
  instructions?: string;
  message: string;
  originalError: string;
  needsManualFix?: boolean;
}

export class ErrorHandler {
  private commonErrors: Record<string, ErrorSolution>;

  constructor() {
    this.commonErrors = {
      'express is not defined': {
        solution: 'Add Express.js to dependencies and import it properly',
        action: (error: Error, context: ErrorContext) => {
          if (!context.dependencies.includes('express')) {
            context.dependencies.push('express', '@types/express');
          }
          
          return {
            dependencies: context.dependencies,
            files: [{
              path: 'package.json',
              content: this.updatePackageJson(context.dependencies, context.framework)
            }],
            instructions: 'Run: npm install express @types/express',
            message: 'Added Express.js dependency and updated package.json'
          };
        }
      },

      'Cannot find module': {
        solution: 'Install missing dependency',
        action: (error: Error, context: ErrorContext) => {
          const moduleMatch = error.message.match(/Cannot find module '([^']+)'/);
          const moduleName = moduleMatch ? moduleMatch[1] : 'unknown-module';
          
          if (!context.dependencies.includes(moduleName)) {
            context.dependencies.push(moduleName);
          }
          
          return {
            dependencies: context.dependencies,
            files: [{
              path: 'package.json',
              content: this.updatePackageJson(context.dependencies, context.framework)
            }],
            instructions: `Run: npm install ${moduleName}`,
            message: `Added missing dependency: ${moduleName}`
          };
        }
      },

      'React is not defined': {
        solution: 'Add React import statement',
        action: (error: Error, context: ErrorContext) => {
          const reactFiles = context.files.filter(f => 
            f.path.endsWith('.jsx') || f.path.endsWith('.tsx')
          );
          
          const updatedFiles = reactFiles.map(file => ({
            path: file.path,
            content: this.addReactImport(file.content)
          }));
          
          return {
            files: updatedFiles,
            message: 'Added React import statements to component files'
          };
        }
      },

      'useState is not defined': {
        solution: 'Import useState from React',
        action: (error: Error, context: ErrorContext) => {
          const reactFiles = context.files.filter(f => 
            f.path.endsWith('.jsx') || f.path.endsWith('.tsx')
          );
          
          const updatedFiles = reactFiles.map(file => ({
            path: file.path,
            content: this.addReactHookImports(file.content)
          }));
          
          return {
            files: updatedFiles,
            message: 'Added React hooks imports (useState, useEffect, etc.)'
          };
        }
      },

      'cors is not defined': {
        solution: 'Add CORS middleware to Express server',
        action: (error: Error, context: ErrorContext) => {
          if (!context.dependencies.includes('cors')) {
            context.dependencies.push('cors', '@types/cors');
          }
          
          const serverFile = context.files.find(f => f.path.includes('server.js') || f.path.includes('index.js'));
          const updatedFiles = [];
          
          if (serverFile) {
            updatedFiles.push({
              path: serverFile.path,
              content: this.addCorsMiddleware(serverFile.content)
            });
          }
          
          return {
            dependencies: context.dependencies,
            files: [
              ...updatedFiles,
              {
                path: 'package.json',
                content: this.updatePackageJson(context.dependencies, context.framework)
              }
            ],
            instructions: 'Run: npm install cors @types/cors',
            message: 'Added CORS middleware and dependency'
          };
        }
      },

      'bodyParser is not defined': {
        solution: 'Add body-parser middleware or use Express built-in parser',
        action: (error: Error, context: ErrorContext) => {
          const serverFile = context.files.find(f => f.path.includes('server.js') || f.path.includes('index.js'));
          const updatedFiles = [];
          
          if (serverFile) {
            updatedFiles.push({
              path: serverFile.path,
              content: this.addBodyParserMiddleware(serverFile.content)
            });
          }
          
          return {
            files: updatedFiles,
            message: 'Added Express built-in body parsing middleware'
          };
        }
      },

      'Chart is not defined': {
        solution: 'Add Chart.js and react-chartjs-2 dependencies',
        action: (error: Error, context: ErrorContext) => {
          const chartDependencies = ['chart.js', 'react-chartjs-2'];
          chartDependencies.forEach(dep => {
            if (!context.dependencies.includes(dep)) {
              context.dependencies.push(dep);
            }
          });
          
          return {
            dependencies: context.dependencies,
            files: [{
              path: 'package.json',
              content: this.updatePackageJson(context.dependencies, context.framework)
            }],
            instructions: 'Run: npm install chart.js react-chartjs-2',
            message: 'Added Chart.js dependencies for data visualization'
          };
        }
      },

      'Tailwind CSS not working': {
        solution: 'Configure Tailwind CSS properly',
        action: (error: Error, context: ErrorContext) => {
          if (!context.dependencies.includes('tailwindcss')) {
            context.dependencies.push('tailwindcss', 'postcss', 'autoprefixer');
          }
          
          return {
            dependencies: context.dependencies,
            files: [
              {
                path: 'tailwind.config.js',
                content: this.generateTailwindConfig()
              },
              {
                path: 'postcss.config.js',
                content: this.generatePostCSSConfig()
              },
              {
                path: 'src/index.css',
                content: this.generateTailwindCSS()
              }
            ],
            instructions: 'Run: npm install -D tailwindcss postcss autoprefixer',
            message: 'Configured Tailwind CSS with proper setup files'
          };
        }
      }
    };
  }

  async handle(error: Error, context: ErrorContext): Promise<ErrorHandlingResult> {
    const errorMessage = error.message;
    
    // Find matching error pattern
    const errorType = Object.keys(this.commonErrors).find(pattern => 
      errorMessage.includes(pattern) || errorMessage.toLowerCase().includes(pattern.toLowerCase())
    );
    
    if (errorType) {
      const handler = this.commonErrors[errorType];
      const result = handler.action(error, context);
      
      return {
        ...result,
        originalError: errorMessage
      };
    }
    
    // Handle unknown errors with intelligent suggestions
    return this.handleUnknownError(error, context);
  }

  private handleUnknownError(error: Error, context: ErrorContext): ErrorHandlingResult {
    const errorMessage = error.message.toLowerCase();
    
    // Analyze error patterns and suggest fixes
    if (errorMessage.includes('module not found') || errorMessage.includes('cannot resolve')) {
      return {
        message: 'Missing dependency detected. Please check if all required packages are installed.',
        instructions: 'Run: npm install to ensure all dependencies are available',
        originalError: error.message,
        needsManualFix: true
      };
    }
    
    if (errorMessage.includes('syntax error') || errorMessage.includes('unexpected token')) {
      return {
        message: 'Syntax error detected in generated code. Please review the code structure.',
        instructions: 'Check for missing semicolons, brackets, or invalid JSX syntax',
        originalError: error.message,
        needsManualFix: true
      };
    }
    
    if (errorMessage.includes('port') && errorMessage.includes('already in use')) {
      return {
        message: 'Port conflict detected. Another service is using the same port.',
        instructions: 'Try changing the port number in your server configuration or stop the conflicting service',
        originalError: error.message,
        needsManualFix: true
      };
    }
    
    return {
      message: 'An unknown error occurred. Manual review required.',
      originalError: error.message,
      needsManualFix: true
    };
  }

  private updatePackageJson(dependencies: string[], framework: string): string {
    const packageData = {
      name: "generated-project",
      version: "1.0.0",
      description: "Generated by InnoXAI with automatic error correction",
      main: framework === 'react' ? "src/index.js" : "server.js",
      scripts: framework === 'react' ? {
        start: "react-scripts start",
        build: "react-scripts build",
        test: "react-scripts test",
        eject: "react-scripts eject"
      } : {
        start: "node server.js",
        dev: "nodemon server.js",
        build: "tsc"
      },
      dependencies: dependencies.reduce((acc, dep) => {
        // Set appropriate versions for common packages
        const versions: Record<string, string> = {
          'react': '^18.2.0',
          'react-dom': '^18.2.0',
          'react-scripts': '5.0.1',
          'express': '^4.18.2',
          'cors': '^2.8.5',
          'chart.js': '^4.4.0',
          'react-chartjs-2': '^5.2.0',
          'tailwindcss': '^3.3.0',
          'typescript': '^5.0.0'
        };
        
        acc[dep] = versions[dep] || 'latest';
        return acc;
      }, {} as Record<string, string>),
      browserslist: framework === 'react' ? {
        production: [">0.2%", "not dead", "not op_mini all"],
        development: ["last 1 chrome version", "last 1 firefox version", "last 1 safari version"]
      } : undefined
    };

    return JSON.stringify(packageData, null, 2);
  }

  private addReactImport(content: string): string {
    if (!content.includes('import React')) {
      return `import React from 'react';\n${content}`;
    }
    return content;
  }

  private addReactHookImports(content: string): string {
    const hooks = ['useState', 'useEffect', 'useRef', 'useCallback', 'useMemo'];
    const usedHooks = hooks.filter(hook => content.includes(hook));
    
    if (usedHooks.length > 0 && !content.includes('import {')) {
      const importStatement = `import React, { ${usedHooks.join(', ')} } from 'react';\n`;
      return content.replace(/import React from 'react';\n?/, importStatement);
    }
    
    return content;
  }

  private addCorsMiddleware(serverContent: string): string {
    if (!serverContent.includes('cors')) {
      const corsImport = "const cors = require('cors');\n";
      const corsMiddleware = "app.use(cors());\n";
      
      let updatedContent = serverContent;
      
      // Add import after express import
      if (serverContent.includes("require('express')")) {
        updatedContent = updatedContent.replace(
          /const express = require\('express'\);/,
          `const express = require('express');\n${corsImport.trim()}`
        );
      }
      
      // Add middleware after app creation
      if (updatedContent.includes('const app = express()')) {
        updatedContent = updatedContent.replace(
          /const app = express\(\);/,
          `const app = express();\n${corsMiddleware.trim()}`
        );
      }
      
      return updatedContent;
    }
    
    return serverContent;
  }

  private addBodyParserMiddleware(serverContent: string): string {
    if (!serverContent.includes('express.json()')) {
      const middleware = `
app.use(express.json());
app.use(express.urlencoded({ extended: true }));`;
      
      return serverContent.replace(
        /const app = express\(\);/,
        `const app = express();${middleware}`
      );
    }
    
    return serverContent;
  }

  private generateTailwindConfig(): string {
    return `/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}`;
  }

  private generatePostCSSConfig(): string {
    return `module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}`;
  }

  private generateTailwindCSS(): string {
    return `@tailwind base;
@tailwind components;
@tailwind utilities;

/* Custom styles can be added here */`;
  }

  async validateAndFix(files: Array<{ path: string; content: string; type: string }>, context: ErrorContext): Promise<{
    files: Array<{ path: string; content: string; type: string }>;
    dependencies: string[];
    fixes: string[];
  }> {
    const fixes: string[] = [];
    let updatedFiles = [...files];
    let updatedDependencies = [...context.dependencies];

    // Check for common issues and fix them proactively
    for (const file of files) {
      if (file.path.endsWith('.jsx') || file.path.endsWith('.tsx')) {
        // Fix React imports
        if (file.content.includes('React.') && !file.content.includes('import React')) {
          const fixedContent = this.addReactImport(file.content);
          updatedFiles = updatedFiles.map(f => 
            f.path === file.path ? { ...f, content: fixedContent } : f
          );
          fixes.push(`Added React import to ${file.path}`);
        }

        // Fix hook imports
        const hooks = ['useState', 'useEffect', 'useRef'];
        const usedHooks = hooks.filter(hook => file.content.includes(hook));
        if (usedHooks.length > 0 && !file.content.includes(`{ ${usedHooks.join(', ')} }`)) {
          const fixedContent = this.addReactHookImports(file.content);
          updatedFiles = updatedFiles.map(f => 
            f.path === file.path ? { ...f, content: fixedContent } : f
          );
          fixes.push(`Added React hooks import to ${file.path}`);
        }
      }

      // Check for missing dependencies
      if (file.content.includes('Chart') && !updatedDependencies.includes('chart.js')) {
        updatedDependencies.push('chart.js', 'react-chartjs-2');
        fixes.push('Added Chart.js dependencies');
      }

      if (file.content.includes('express') && !updatedDependencies.includes('express')) {
        updatedDependencies.push('express');
        fixes.push('Added Express.js dependency');
      }
    }

    return {
      files: updatedFiles,
      dependencies: updatedDependencies,
      fixes
    };
  }
}

export const errorHandler = new ErrorHandler();