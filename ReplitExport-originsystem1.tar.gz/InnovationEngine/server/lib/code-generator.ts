import { aiService } from './ai-service.js';

interface ProjectType {
  isFullStack: boolean;
  framework: string;
  styling: string;
  requiresDatabase: boolean;
  projectCategory: string;
}

interface Route {
  path: string;
  method: string;
  handler: string;
  description: string;
}

interface GeneratedFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'config' | 'documentation';
}

interface FullStackResult {
  frontend: {
    files: GeneratedFile[];
    dependencies: string[];
  };
  backend: {
    files: GeneratedFile[];
    dependencies: string[];
    routes: Route[];
    baseUrl: string;
  };
  database: string | null;
  dependencies: string[];
}

export class CodeGenerator {
  async generateFullStack(prompt: string): Promise<FullStackResult> {
    // Analyze the prompt to determine project requirements
    const projectType = this.analyzePrompt(prompt);
    
    const result: FullStackResult = {
      frontend: { files: [], dependencies: [] },
      backend: { files: [], dependencies: [], routes: [], baseUrl: 'http://localhost:3001' },
      database: null,
      dependencies: []
    };

    // Generate frontend components
    result.frontend = await this.generateFrontend(prompt, projectType.framework, projectType.styling);
    
    // Generate backend if needed
    if (projectType.isFullStack) {
      result.backend = await this.generateBackend(prompt, projectType);
      result.database = projectType.requiresDatabase ? this.determineDatabase(prompt) : null;
      
      // Add API service to frontend for backend communication
      result.frontend.files.push(
        this.generateApiService(result.backend.baseUrl)
      );
    }

    // Combine dependencies
    result.dependencies = [
      ...result.frontend.dependencies,
      ...result.backend.dependencies
    ];

    return result;
  }

  private analyzePrompt(prompt: string): ProjectType {
    const lowerPrompt = prompt.toLowerCase();
    
    // Determine if full-stack is needed
    const isFullStack = lowerPrompt.includes('api') || 
                       lowerPrompt.includes('backend') || 
                       lowerPrompt.includes('database') ||
                       lowerPrompt.includes('server') ||
                       lowerPrompt.includes('auth') ||
                       lowerPrompt.includes('login') ||
                       lowerPrompt.includes('dashboard');

    // Determine database requirement
    const requiresDatabase = lowerPrompt.includes('database') ||
                            lowerPrompt.includes('storage') ||
                            lowerPrompt.includes('persist') ||
                            lowerPrompt.includes('user') ||
                            lowerPrompt.includes('auth');

    // Determine project category
    let projectCategory = 'general';
    if (lowerPrompt.includes('dashboard') || lowerPrompt.includes('admin')) projectCategory = 'dashboard';
    else if (lowerPrompt.includes('landing') || lowerPrompt.includes('marketing')) projectCategory = 'landing';
    else if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop')) projectCategory = 'ecommerce';
    else if (lowerPrompt.includes('blog') || lowerPrompt.includes('cms')) projectCategory = 'blog';
    else if (lowerPrompt.includes('chat') || lowerPrompt.includes('messaging')) projectCategory = 'chat';

    return {
      isFullStack,
      framework: 'react',
      styling: 'tailwind',
      requiresDatabase,
      projectCategory
    };
  }

  private async generateFrontend(prompt: string, framework: string, styling: string) {
    const mainComponent = await aiService.generateCode(prompt, framework, styling);
    
    const files: GeneratedFile[] = [
      {
        path: 'src/App.jsx',
        content: mainComponent,
        type: 'frontend'
      },
      {
        path: 'src/App.css',
        content: this.generateBaseCSS(),
        type: 'frontend'
      },
      {
        path: 'src/index.js',
        content: this.generateReactIndex(),
        type: 'frontend'
      },
      {
        path: 'public/index.html',
        content: this.generateIndexHTML(),
        type: 'frontend'
      }
    ];

    const dependencies = [
      'react',
      'react-dom',
      'react-scripts'
    ];

    return { files, dependencies };
  }

  private async generateBackend(prompt: string, projectType: ProjectType): Promise<{
    files: GeneratedFile[];
    dependencies: string[];
    routes: Route[];
    baseUrl: string;
  }> {
    const routes = await this.determineRoutes(prompt, projectType);
    
    const files: GeneratedFile[] = [
      {
        path: 'server.js',
        content: this.generateExpressServer(routes),
        type: 'backend'
      },
      {
        path: 'package.json',
        content: this.generateBackendPackageJson(),
        type: 'config'
      },
      ...routes.map(route => ({
        path: `routes${route.path.replace(/:/g, '_').replace(/\//g, '-')}.js`,
        content: this.generateRouteHandler(route),
        type: 'backend' as const
      }))
    ];

    if (projectType.requiresDatabase) {
      files.push({
        path: 'models/index.js',
        content: this.generateDatabaseModels(projectType),
        type: 'backend'
      });
    }

    const dependencies = [
      'express',
      'cors',
      'body-parser',
      'dotenv'
    ];

    if (projectType.requiresDatabase) {
      dependencies.push('mongoose'); // Default to MongoDB
    }

    return {
      files,
      dependencies,
      routes,
      baseUrl: 'http://localhost:3001'
    };
  }

  private async determineRoutes(prompt: string, projectType: ProjectType): Promise<Route[]> {
    const routes: Route[] = [];
    
    // Basic health check
    routes.push({
      path: '/health',
      method: 'GET',
      handler: 'res.json({ status: "healthy", timestamp: new Date().toISOString() });',
      description: 'Health check endpoint'
    });

    // Add routes based on project type
    switch (projectType.projectCategory) {
      case 'dashboard':
        routes.push(
          {
            path: '/api/stats',
            method: 'GET',
            handler: `
              const stats = {
                users: Math.floor(Math.random() * 10000) + 1000,
                revenue: Math.floor(Math.random() * 100000) + 50000,
                orders: Math.floor(Math.random() * 500) + 100,
                growth: (Math.random() * 20 + 5).toFixed(1)
              };
              res.json(stats);
            `,
            description: 'Get dashboard statistics'
          },
          {
            path: '/api/chart-data',
            method: 'GET',
            handler: `
              const chartData = {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                  label: 'Revenue',
                  data: Array.from({length: 6}, () => Math.floor(Math.random() * 10000) + 5000),
                  backgroundColor: 'rgba(59, 130, 246, 0.5)',
                  borderColor: 'rgb(59, 130, 246)'
                }]
              };
              res.json(chartData);
            `,
            description: 'Get chart data'
          }
        );
        break;

      case 'ecommerce':
        routes.push(
          {
            path: '/api/products',
            method: 'GET',
            handler: `
              const products = Array.from({length: 12}, (_, i) => ({
                id: i + 1,
                name: 'Product ' + (i + 1),
                price: Math.floor(Math.random() * 200) + 20,
                image: 'https://via.placeholder.com/300x200',
                category: ['Electronics', 'Clothing', 'Books'][Math.floor(Math.random() * 3)]
              }));
              res.json(products);
            `,
            description: 'Get products list'
          },
          {
            path: '/api/cart',
            method: 'POST',
            handler: `
              const { productId, quantity = 1 } = req.body;
              res.json({ 
                success: true, 
                message: 'Item added to cart',
                cartId: 'cart_' + Date.now(),
                item: { productId, quantity }
              });
            `,
            description: 'Add item to cart'
          }
        );
        break;

      case 'blog':
        routes.push(
          {
            path: '/api/posts',
            method: 'GET',
            handler: `
              const posts = Array.from({length: 10}, (_, i) => ({
                id: i + 1,
                title: 'Blog Post ' + (i + 1),
                excerpt: 'This is a sample excerpt for blog post ' + (i + 1),
                content: 'Full content of the blog post...',
                author: 'Author ' + (i % 3 + 1),
                publishedAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
                tags: ['react', 'javascript', 'web-development'][Math.floor(Math.random() * 3)]
              }));
              res.json(posts);
            `,
            description: 'Get blog posts'
          }
        );
        break;

      default:
        routes.push(
          {
            path: '/api/data',
            method: 'GET',
            handler: `
              const data = {
                message: 'Hello from the backend!',
                timestamp: new Date().toISOString(),
                randomValue: Math.floor(Math.random() * 1000)
              };
              res.json(data);
            `,
            description: 'Get sample data'
          }
        );
    }

    return routes;
  }

  private generateApiService(baseUrl: string): GeneratedFile {
    return {
      path: 'src/services/api.js',
      content: `const API_BASE_URL = '${baseUrl}';

export const api = {
  get: async (endpoint) => {
    try {
      const response = await fetch(\`\${API_BASE_URL}\${endpoint}\`);
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('API GET error:', error);
      throw error;
    }
  },

  post: async (endpoint, data) => {
    try {
      const response = await fetch(\`\${API_BASE_URL}\${endpoint}\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('API POST error:', error);
      throw error;
    }
  },

  put: async (endpoint, data) => {
    try {
      const response = await fetch(\`\${API_BASE_URL}\${endpoint}\`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('API PUT error:', error);
      throw error;
    }
  },

  delete: async (endpoint) => {
    try {
      const response = await fetch(\`\${API_BASE_URL}\${endpoint}\`, {
        method: 'DELETE'
      });
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('API DELETE error:', error);
      throw error;
    }
  }
};

export default api;`,
      type: 'frontend'
    };
  }

  private generateExpressServer(routes: Route[]): string {
    const routeHandlers = routes.map((route, index) => `
// ${route.description}
app.${route.method.toLowerCase()}('${route.path}', (req, res) => {
  try {
    ${route.handler}
  } catch (error) {
    console.error('Route error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});`).join('\n');

    return `const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
${routeHandlers}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Something went wrong!' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});`;
  }

  private generateRouteHandler(route: Route): string {
    return `// ${route.description}
module.exports = (req, res) => {
  try {
    ${route.handler}
  } catch (error) {
    console.error('Route handler error:', error);
    res.status(500).json({ error: 'Route handler failed' });
  }
};`;
  }

  private generateBaseCSS(): string {
    return `/* Base styles for generated application */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  line-height: 1.6;
  color: #333;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

@media (max-width: 768px) {
  .container {
    padding: 0 0.5rem;
  }
}`;
  }

  private generateReactIndex(): string {
    return `import React from 'react';
import ReactDOM from 'react-dom/client';
import './App.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`;
  }

  private generateIndexHTML(): string {
    return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="icon" href="%PUBLIC_URL%/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Generated by InnoXAI" />
    <title>InnoXAI Generated App</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>`;
  }

  private generateBackendPackageJson(): string {
    return JSON.stringify({
      name: "generated-backend",
      version: "1.0.0",
      description: "Generated backend by InnoXAI",
      main: "server.js",
      scripts: {
        start: "node server.js",
        dev: "nodemon server.js"
      },
      dependencies: {
        express: "^4.18.2",
        cors: "^2.8.5",
        "body-parser": "^1.20.2",
        dotenv: "^16.0.3"
      },
      devDependencies: {
        nodemon: "^2.0.22"
      }
    }, null, 2);
  }

  private generateDatabaseModels(projectType: ProjectType): string {
    return `const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27017/generated_app', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// User model (common for most apps)
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

module.exports = {
  User,
  mongoose
};`;
  }

  private determineDatabase(prompt: string): string {
    const lowerPrompt = prompt.toLowerCase();
    
    if (lowerPrompt.includes('mongodb') || lowerPrompt.includes('mongo')) {
      return 'mongodb';
    } else if (lowerPrompt.includes('postgresql') || lowerPrompt.includes('postgres')) {
      return 'postgresql';
    } else if (lowerPrompt.includes('mysql')) {
      return 'mysql';
    } else {
      return 'mongodb'; // Default
    }
  }

  private getSharedDependencies(isFullStack: boolean): string[] {
    const dependencies = ['dotenv'];
    
    if (isFullStack) {
      dependencies.push('concurrently'); // To run frontend and backend together
    }
    
    return dependencies;
  }
}

export const codeGenerator = new CodeGenerator();