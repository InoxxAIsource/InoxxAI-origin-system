import path from "path";
import { storage } from "../storage";

interface FolderStructure {
  name: string;
  type: "file" | "folder";
  path: string;
  children?: FolderStructure[];
}

class FileSystem {
  async createFolder(folderPath: string, projectId: number): Promise<{ success: boolean; path: string }> {
    try {
      // Validate path
      if (!this.isValidPath(folderPath)) {
        throw new Error("Invalid folder path");
      }

      // In a real implementation, this would create actual directories
      console.log(`Creating folder: ${folderPath} in project ${projectId}`);
      
      return {
        success: true,
        path: folderPath,
      };
    } catch (error) {
      console.error("Folder creation failed:", error);
      throw new Error(`Failed to create folder: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteFolder(folderPath: string, projectId: number): Promise<boolean> {
    try {
      console.log(`Deleting folder: ${folderPath} in project ${projectId}`);
      
      // Delete all files in the folder
      const files = await storage.getFilesByProject(projectId);
      const filesToDelete = files.filter(file => file.path.startsWith(folderPath + "/"));
      
      for (const file of filesToDelete) {
        await storage.deleteFile(file.id);
      }
      
      return true;
    } catch (error) {
      console.error("Folder deletion failed:", error);
      return false;
    }
  }

  async moveFile(oldPath: string, newPath: string, projectId: number): Promise<boolean> {
    try {
      const file = await storage.getFileByPath(projectId, oldPath);
      if (!file) {
        throw new Error("File not found");
      }

      await storage.updateFile(file.id, { path: newPath });
      return true;
    } catch (error) {
      console.error("File move failed:", error);
      return false;
    }
  }

  async copyFile(sourcePath: string, targetPath: string, projectId: number): Promise<boolean> {
    try {
      const sourceFile = await storage.getFileByPath(projectId, sourcePath);
      if (!sourceFile) {
        throw new Error("Source file not found");
      }

      await storage.createFile({
        projectId,
        path: targetPath,
        content: sourceFile.content,
        language: sourceFile.language,
        isOpen: false,
      });

      return true;
    } catch (error) {
      console.error("File copy failed:", error);
      return false;
    }
  }

  async getFolderStructure(projectId: number): Promise<FolderStructure[]> {
    try {
      const files = await storage.getFilesByProject(projectId);
      const structure: FolderStructure[] = [];
      const folderMap = new Map<string, FolderStructure>();

      // Create root folders
      const rootFolders = new Set<string>();
      files.forEach(file => {
        const parts = file.path.split("/");
        if (parts.length > 1) {
          rootFolders.add(parts[0]);
        }
      });

      rootFolders.forEach(folderName => {
        const folder: FolderStructure = {
          name: folderName,
          type: "folder",
          path: folderName,
          children: [],
        };
        structure.push(folder);
        folderMap.set(folderName, folder);
      });

      // Add files to structure
      files.forEach(file => {
        const parts = file.path.split("/");
        const fileName = parts[parts.length - 1];
        
        if (parts.length === 1) {
          // Root level file
          structure.push({
            name: fileName,
            type: "file",
            path: file.path,
          });
        } else {
          // File in folder
          const folderName = parts[0];
          const folder = folderMap.get(folderName);
          if (folder && folder.children) {
            folder.children.push({
              name: fileName,
              type: "file",
              path: file.path,
            });
          }
        }
      });

      return structure;
    } catch (error) {
      console.error("Failed to get folder structure:", error);
      return [];
    }
  }

  private isValidPath(filePath: string): boolean {
    // Basic path validation
    if (!filePath || filePath.includes("..") || filePath.startsWith("/")) {
      return false;
    }
    return true;
  }

  getFileLanguage(filePath: string): string {
    const ext = path.extname(filePath).toLowerCase();
    const languageMap: Record<string, string> = {
      ".js": "javascript",
      ".jsx": "javascript",
      ".ts": "typescript",
      ".tsx": "typescript",
      ".css": "css",
      ".scss": "scss",
      ".html": "html",
      ".json": "json",
      ".md": "markdown",
      ".py": "python",
      ".java": "java",
      ".cpp": "cpp",
      ".c": "c",
      ".php": "php",
      ".rb": "ruby",
      ".go": "go",
      ".rs": "rust",
    };
    
    return languageMap[ext] || "plaintext";
  }

  getFileIcon(filePath: string): string {
    const ext = path.extname(filePath).toLowerCase();
    const iconMap: Record<string, string> = {
      ".js": "fab fa-js-square",
      ".jsx": "fab fa-react",
      ".ts": "fas fa-code",
      ".tsx": "fab fa-react",
      ".css": "fab fa-css3-alt",
      ".scss": "fab fa-sass",
      ".html": "fab fa-html5",
      ".json": "fas fa-cube",
      ".md": "fab fa-markdown",
      ".py": "fab fa-python",
      ".java": "fab fa-java",
      ".php": "fab fa-php",
      ".rb": "fas fa-gem",
      ".go": "fas fa-code",
    };
    
    return iconMap[ext] || "fas fa-file-alt";
  }
}

export const fileSystem = new FileSystem();
